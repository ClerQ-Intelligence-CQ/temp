ClerQ checkpoint 1: specs
specs/01-HQ-AND-SITE-SPEC.md  full HQ feature spec, roles, site spec, acceptance checkpoints, repo findings.
Same content as the Claude Doc. Feed this file to your coding agent as the source of truth.
