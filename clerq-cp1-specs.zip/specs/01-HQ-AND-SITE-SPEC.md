# ClerQ HQ and Website: Full Feature Spec
Version 1, 30 Oct 2026. For Emmanuel Chesco Mwalongo, ClerQ Intelligence.

## 1. Ground rules
- Dominant theme pure white (#FFFFFF), off-white (#F8F9FA), hairlines (#E5E5E5), text (#0A0A0A), muted (#6B6B6B). One accent color per product.
- No emojis. Icons are SVG (Scalable Vector Graphics) only.
- No fake data. Empty states are honest ("0 events recorded").
- Copy says "offline-capable". Nia is assistive, grounded in the Tanzania STG (Standard Treatment Guidelines) 2026. Clinicians keep clinical responsibility.
- HQ (Headquarters console) is a product, not a page. Everything the public site shows is controlled from HQ.
- Every HQ write goes to the audit log: actor, role, before, after, time, IP (Internet Protocol) address.
- Bilingual EN/SW wherever a user reads text.
- Standard: staged rollout, kill switch, observability, least privilege, reviewable changes, tested restores.

## 2. Roles
MA Master Admin (everything, role management) | RM Release Manager (stages, builds, rollout, kill switch) | CE Content Editor (drafts) | CS Clinical Safety Reviewer (approves clinical copy) | BO Beta Operator (queue, keys) | SU Support (tickets, masked lookup) | SE Security Officer (sessions, audit, rotation, data requests) | NM Network and Maintenance (fleet, health, jobs) | FN Finance (costs).
Rules: least privilege; MFA (multi-factor authentication) for all staff. Two-person approval for: publishing a clinical product page, kill switch with data wipe, role changes, bulk key revoke. Break-glass needs a reason and fires an alert.

## 3. HQ modules (ID, feature, roles)
### A. Command Center
- A1 Live overview: products by stage, active devices, pending applications, open incidents, last release. Real data only. (all, filtered)
- A2 Needs-attention queue: expiring keys, failed jobs, stale devices, unreviewed copy. (all)
- A3 Global search (Ctrl/Cmd+K) across products, users, applications, notices, audit. (all)
- A4 Activity feed from the audit log. (MA, SE)
- A5 Permanent environment badge: staging or production. (all)
### B. Product Studio
- B1 Catalog list, filters by stage, owner, health. (RM, CE)
- B2 Create-product wizard: slug, names EN/SW, tagline, SVG logo, accent, platforms. (RM)
- B3 Stage manager: Concept, Alpha, Closed Beta, Open Beta, GA (General Availability), Deprecated. Validated transitions (no GA without a signed build and CS approval). Scheduled changes. (RM)
- B4 Access mode: public, waitlist, invite key, account only. (RM, BO)
- B5 Orbit settings: show in orbit, order, glow color, container style. (RM, CE)
- B6 Scroll arrangement: grid, staggered, rail; card order and size. (RM, CE)
- B7 Page builder with block library: hero, stat strip, feature grid, screenshot carousel, video, 3D viewport presets, FAQ, safety statement, CTA, partners strip, changelog feed, download card. (CE)
- B8 Block inspector: text EN/SW, media, alignment, spacing, animation preset, visibility by stage. (CE)
- B9 Live preview in phone, tablet, desktop frames; language toggle; stage toggle. (CE, RM)
- B10 Draft, review, publish, scheduled publish, version history, diff, rollback. (CE, RM, CS)
- B11 Copy linter: banned phrases ("offline-native", "offline-only"), required safety statement, claim flags, Swahili medical glossary. (CE, CS)
- B12 Media library: upload, auto-optimize (WebP, AVIF), alt text required, usage tracking. (CE)
- B13 CTA wiring: join beta, enter key, download, request demo, contact; each bound to a beta program or release. (RM, CE)
- B14 Templates: save and duplicate page layouts. (CE)
- B15 Autosave, undo/redo, keyboard shortcuts. (CE)
### C. Release Manager
- C1 Builds: upload, SHA-256, size, minimum OS, signing check, release notes EN/SW. (RM)
- C2 Channels per product: alpha, beta, stable. (RM)
- C3 Staged rollout 1, 5, 25, 50, 100 percent; auto-halt on crash threshold. (RM)
- C4 Minimum supported version, lock message, offline grace days. (RM)
- C5 Kill switch with optional data wipe: reason, countdown, two-person approval. (RM, MA)
- C6 Model artifact registry (Lucy model, voice model): URL, hash, bytes, version compatibility. (RM)
- C7 Release calendar and freeze windows. (RM)
- C8 One-click rollback. (RM)
- C9 Download portal: signed, expiring URLs bound to a key. (RM, BO)
### D. Beta and Access
- D1 Beta programs per product: open or closed, capacity, form builder, regions. (BO, RM)
- D2 Application queue with dossier: cadre, facility, MCT (Medical Council of Tanganyika) number, documents, SLA (service level agreement) timer. (BO)
- D3 Verification helpers: checklist, duplicate and fraud flags. (BO)
- D4 Decisions: accept and issue key, reject with reason, request more information. (BO)
- D5 Keys: single use, expiry, bound to email, revoke, reissue, bulk issue, redemption state. (BO, SE)
- D6 Invite email: EN/SW template, preview, copy, send, delivery status. Replaces the "Personal Email Dispatch Package". (BO)
- D7 Waitlist: position and batch invites. (BO)
- D8 Cohorts: group testers, target builds, surveys. (BO, RM)
- D9 Tester feedback inbox. (BO, SU)
### E. Users and Accounts
- E1 Accounts directory, masked PII (personally identifiable information). (SU, SE, MA)
- E2 Staff management: invite, role, enforce MFA, deactivate. (MA)
- E3 Session manager. (SE)
- E4 Facility directory: facilities, cadres, device counts. (BO, NM)
- E5 Data-subject requests under the PDPA (Personal Data Protection Act): export, erase, deadlines. (SE)
### F. Telemetry and Fleet
- F1 Device fleet: version, OS, last check-in, lock state, offline grace. (NM, RM)
- F2 Usage events explorer, privacy-safe aggregates only. (NM)
- F3 Crash and error reports, grouped. (RM, NM)
- F4 Aggregate facility activity map, no patient data. (NM)
- F5 Version adoption chart. (RM)
- F6 Alerts: stale fleet, crash spike, failed sync. (NM)
- F7 Remote config per app version. (RM)
### G. Content
- G1 Research stream (merges blog and research): Paper, Engineering note, Update. EN/SW, authors, tags, cover, citations. (CE)
- G2 Review flow: draft, clinical review, publish, schedule. (CE, CS)
- G3 In-app notices: audience, severity, expiry. (CE, RM)
- G4 Newsletter composer and subscribers. (CE)
- G5 Press kit and brand vault. (CE)
- G6 Team and partners editors. (CE)
- G7 Legal pages with versioned acceptance records. (MA, SE)
### H. Site Control
- H1 Intro animation: enable, duration cap, skip, once per session, live orbit count. (RM, CE)
- H2 Navigation editor. (CE)
- H3 Hero editor: headline, subline, beta pill text and rule. (CE)
- H4 Theme tokens with WCAG (Web Content Accessibility Guidelines) AA contrast checks. (CE)
- H5 SEO manager: titles, descriptions, social images, sitemap, robots, redirects. (CE)
- H6 Announcement bar and maintenance mode. (RM, CE)
- H7 Feature flags. (RM)
- H8 Performance budgets and Lighthouse history. (NM)
### I. Communications
- I1 Email templates: invite, rejection, more information, welcome, release notice (EN/SW, variables). (BO, CE)
- I2 Sending-domain health: SPF, DKIM, DMARC. (NM)
- I3 SMS templates. (BO)
- I4 Delivery logs. (BO, SU)
- I5 Contact-form routing. (SU)
### J. Security and Compliance
- J1 Audit log viewer: filters, export, tamper evidence (hash chain). (SE, MA)
- J2 MFA enforcement, IP allowlist for HQ, session timeout. (SE)
- J3 Key and secret rotation tracker. (SE)
- J4 Monthly access review. (SE, MA)
- J5 Break-glass access. (MA)
- J6 Policy documents and acceptance records. (SE)
- J7 Scheduled RLS (Row Level Security) and RPC (Remote Procedure Call) health checks proving anonymous users cannot read protected tables. (SE, NM)
- J8 Abuse controls: rate limits, blocklists, CAPTCHA on public forms. (SE)
### K. Support
- K1 Ticket inbox. (SU)  K2 Masked user lookup, reveal with logged reason. (SU)  K3 Canned replies EN/SW. (SU)  K4 Escalation to RM or CS. (SU)
### L. Partners and Facilities CRM (Customer Relationship Management)
- L1 Pipeline: ministry, hospital networks, research, funders. (MA)  L2 MOU (memorandum of understanding) tracking with expiry alerts. (MA)  L3 Pilot sites with onboarding checklist. (MA, NM)
### M. Analytics
- M1 Privacy-first site analytics, no third-party trackers; funnel visit, product view, apply, approved, install, active. (MA, CE)  M2 Beta conversion and time to decision. (BO)  M3 Content performance. (CE)  M4 Exportable reports. (MA)
### N. Settings and Integrations
- N1 Environments and config. (MA)  N2 Webhooks and scoped API keys. (MA)  N3 Backup and restore status, restore drill log. (NM)  N4 Integration health: email, SMS, Supabase, storage. (NM)  N5 Cost monitor. (FN, MA)
### O. Incident Center
- O1 Declare incident, severity, owner. (all staff)  O2 Status page publishing. (RM, MA)  O3 One-click mitigations: lock version, pause rollout, maintenance mode. (RM)  O4 Post-incident review template. (MA)

## 4. Public site
Pages: Home, Products, Product page (from catalog), Research, About, Partners, Contact, Legal, Status, Verified Install portal, Beta status.
- Intro (3 s max): white screen, revolving shiny coin with the full black ClerQ logotype, N black comets from all directions settle on a ring, coin centers, "N products live" below, product logos glow-fade into circular containers. Skip button, once per session, static for reduced motion, 2D canvas on low-end phones.
- Scroll: containers follow, then rearrange (FLIP, First Last Invert Play) into cards per the studio arrangement; cards and details animate in sequence; click expands into the product page.
- Beta pill: top right, fades in after the intro, "Join our beta", opens one modal ("I have a key" / "Request access"). Shows only when a product has an open beta program.
- Performance: LCP (Largest Contentful Paint) under 2.5 s on a mid-range Android over 4G, CLS (Cumulative Layout Shift) under 0.1, first-load JavaScript under 250 KB, Three.js lazy-loaded.
- Accessibility: WCAG 2.2 AA, keyboard use, reduced motion, required alt text.
- Language: EN/SW toggle remembered; Swahili copy clinician-reviewed.

## 5. Checkpoints and acceptance
1. CP1 Lockdown and catalog: public /hq/ removed, HQ on its own subdomain behind MFA, products table and public catalog call live. Accept: anonymous requests cannot read any protected table (J7 passes).
2. CP2 Studio core: B1-B6, B10, B13, C1-C5. Accept: a new product goes Concept to Closed Beta and appears on the site with no redeploy.
3. CP3 Site render and choreography: intro, scroll rearrangement, pill, catalog-rendered product pages. Accept: performance budget met on a real low-end Android.
4. CP4 Beta pipeline hardening: server-only reference codes, rate limits, key expiry, D1-D9. Accept: guessing references or keys is blocked and logged.
5. CP5 Operations: E, F, G, I, J, K, M, N, O. Accept: every audit-log action is searchable and exportable.

## 6. Findings from the existing repo (fix in CP1)
- Public /hq/ page exposes the master email, Supabase project ref and console port; its "ONLINE" badge is hardcoded; its iframe targets localhost.
- Catalog hardcoded in product/index.html and js/product-scene.js; no products table or stage.
- Beta reference generated twice (client Math.random, server gen_random_bytes); no rate limiting seen on status lookup or key verification.
- "Dispatches" names three different things; merge blog and research into one Research stream.
