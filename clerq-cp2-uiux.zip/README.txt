ClerQ checkpoint 2: UI/UX prototype
Open ui/index.html in a browser (needs internet only for the General Sans font; falls back to system-ui).
Site view: revolving coin, black comets, orbit chips, beta pill, orbit-to-card scroll rearrangement.
HQ Studio view: catalog stage/access/orbit controls, arrangement picker, page builder, copy linter, two-person publish, audit log.
Changes made in HQ update the site view live. Replay intro re-runs the sequence.
Product logos are letter placeholders; swap in real SVGs. Data is prototype-only.
