# ClerQ Backend Brief: Product Studio and HQ foundation
Version 1, 30 Oct 2026. Read with the CP1 spec zip. Migration: backend/schema/0005_product_studio.sql (not yet run on a database).

## Decisions
- Stay on Supabase and the existing token-RPC pattern (SECURITY DEFINER functions, RLS on, no table policies). One new migration, no new infrastructure.
- The static site stays static. At load it calls `cq_get_catalog(lang)`, renders from the result, and keeps the last good response as a cached JSON fallback so the site works if Supabase is down.
- The catalog returns published data only, with no internal ids. Concept products are hidden. Swahili falls back to English per field and per page.
- Roles are extended, not replaced: existing master, product_manager, content_editor, analyst, support, clinician stay. New: release_manager, clinical_safety, beta_operator, security, network_maint, finance. One role per account for now; move to a role-grants table if people need several.
- Publishing a clinical product page needs three distinct people: requester, clinical_safety approver (master cannot self-approve), then a release_manager or product_manager publishes. Editing a page resets approval.
- GA requires a clinical approval on record and a live stable release with a SHA-256. Closed or Open Beta requires a beta program row. Stage moves one step at a time, except to Deprecated.
- cq_audit becomes append-only with a hash chain (prev_hash, row_hash). TRUNCATE is not blocked by the trigger: restrict it by privilege.

## Changes needed outside SQL (CP1 and CP3)
1. Delete the public /hq/ gateway page. Serve HQ from its own subdomain behind login and MFA (multi-factor authentication). Remove the master email, project ref and localhost references from every public file. Consider making the staging repo private.
2. product/index.html: drop the hardcoded product object and the Math.random reference. Use only the ref the server returns. Render tabs, cards and CTAs from `cq_get_catalog`.
3. js/product-scene.js: map scene presets by a `preset` field in page JSON, not an if/else on product ids.
4. Beta status page: the lookup no longer returns name, facility or cadre. Show status and date only.
5. `cq_submit_beta_application`: add one line at the top of its body, `if not cq_rl('sub:ip:' || cq_client_ip(), 5, interval '1 day') then return jsonb_build_object('ok', false, 'error', 'rate_limited'); end if;` (its body was not rewritten here to avoid breaking named-argument callers).
6. HQ console: replace the Clinicians-only view with the Product Studio, Beta Queue, Audit and Fleet screens listed in the spec, calling the cq_hq_* functions.

## Page JSON contract (draft column)
`{"blocks":[{"type":"hero|stat_strip|feature_grid|screenshots|video|viewport_3d|faq|safety_statement|cta|changelog|download","props":{...}}]}`
Clinical products must contain a `safety_statement` block. Copy matching "offline-native" or "offline-only" is rejected server-side.

## Checkpoint backend tasks
- CP1: run 0005 on staging, run tests/anon_access_check.sh (it must pass), remove /hq/ gateway, enable MFA for staff.
- CP2: releases RPCs (create build, set channel, rollout %, halt, rollback, kill switch with two-person approval), storage bucket for builds with signed expiring URLs.
- CP3: catalog fetch plus cached fallback, scene preset field, scroll arrangement from `settings.arrangement`.
- CP4: wrap submit with rate limit, key expiry column and revoke RPC, waitlist table, tester feedback table, email delivery log.
- CP5: fleet and telemetry views, notices audience, SE access review report, backup restore drill log, cost monitor.

## Not verified
The SQL has not been run. I did not read the body of cq_verify_beta_key or cq_session_account, the existing RLS policies, or the live database, and the constraint name cq_accounts_role_check is assumed. Run on staging and fix forward before production.
