ClerQ checkpoint 3: backend
BACKEND-BRIEF.md  decisions, required non-SQL changes, checkpoint tasks, what is unverified.
backend/schema/0005_product_studio.sql  migration (staging first).
backend/tests/anon_access_check.sh  proves anonymous users cannot read protected tables and that rate limits work.
