-- 0005_product_studio.sql
-- Product Studio, roles, append-only audit chain, rate limiting, hardened beta lookups.
-- Assumes 0001-0004 applied. NOT executed against a database yet: run on staging first.
-- Assumption: the role check constraint on cq_accounts uses the default name cq_accounts_role_check.
begin;

-- 1. Staff roles (extends the existing check) ------------------------------------------
alter table cq_accounts drop constraint if exists cq_accounts_role_check;
alter table cq_accounts add constraint cq_accounts_role_check check (role in (
  'master','product_manager','content_editor','analyst','support','clinician',
  'release_manager','clinical_safety','beta_operator','security','network_maint','finance'));

-- 2. Audit: append-only hash chain -----------------------------------------------------
alter table cq_audit add column if not exists role text, add column if not exists prev_hash text, add column if not exists row_hash text;
create or replace function cq_audit_chain() returns trigger language plpgsql set search_path = public, extensions as $$
declare ph text;
begin
  perform pg_advisory_xact_lock(730501);
  select row_hash into ph from cq_audit where row_hash is not null order by id desc limit 1;
  new.prev_hash := ph;
  new.row_hash := encode(digest(coalesce(ph,'') || new.id::text || coalesce(new.actor::text,'') || coalesce(new.action,'')
                    || coalesce(new.detail::text,'') || new.at::text, 'sha256'), 'hex');
  return new;
end $$;
drop trigger if exists trg_cq_audit_chain on cq_audit;
create trigger trg_cq_audit_chain before insert on cq_audit for each row execute function cq_audit_chain();
create or replace function cq_audit_immutable() returns trigger language plpgsql as $$
begin raise exception 'cq_audit is append-only'; end $$;
drop trigger if exists trg_cq_audit_immutable on cq_audit;
create trigger trg_cq_audit_immutable before update or delete on cq_audit for each row execute function cq_audit_immutable();

-- 3. Helpers (internal only) -----------------------------------------------------------
create or replace function cq_client_ip() returns text language sql stable as $$
  select coalesce(nullif(split_part(coalesce(nullif(current_setting('request.headers', true), '')::json ->> 'x-forwarded-for', ''), ',', 1), ''), 'unknown') $$;

create table if not exists cq_rate_limit (k text primary key, n int not null default 0, window_start timestamptz not null default now());
alter table cq_rate_limit enable row level security;
create or replace function cq_rl(p_key text, p_max int, p_window interval) returns boolean
language plpgsql security definer set search_path = public as $$
declare r cq_rate_limit;
begin
  insert into cq_rate_limit(k, n, window_start) values (p_key, 1, now())
  on conflict (k) do update set
    n = case when cq_rate_limit.window_start < now() - p_window then 1 else cq_rate_limit.n + 1 end,
    window_start = case when cq_rate_limit.window_start < now() - p_window then now() else cq_rate_limit.window_start end
  returning * into r;
  return r.n <= p_max;
end $$;

create or replace function cq_staff(p_token text, p_roles text[], p_master boolean default true) returns cq_accounts
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts;
begin
  a := cq_session_account(p_token);
  if a.id is null or a.status <> 'verified' then return null; end if;
  if a.role = any(p_roles) or (p_master and a.role = 'master') then return a; end if;
  return null;
end $$;

create or replace function cq_log(a cq_accounts, p_action text, p_detail jsonb) returns void
language sql security definer set search_path = public, extensions as $$
  insert into cq_audit(actor, role, action, detail) values (a.id, a.role, p_action, p_detail) $$;

-- 4. Product Studio tables (RLS on, no policies: access only through the RPCs below) ----
create table if not exists cq_products (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null check (slug ~ '^[a-z0-9-]{2,40}$'),
  name_en text not null, name_sw text, tagline_en text, tagline_sw text,
  logo_path text, accent text check (accent ~ '^#[0-9a-fA-F]{6}$'),
  clinical boolean not null default true,
  stage text not null default 'concept' check (stage in ('concept','alpha','closed_beta','open_beta','ga','deprecated')),
  access_mode text not null default 'invite_key' check (access_mode in ('public','waitlist','invite_key','account_only')),
  show_in_orbit boolean not null default false, orbit_order int not null default 0, card_order int not null default 0,
  platforms text[] not null default '{}',
  updated_by uuid references cq_accounts(id), updated_at timestamptz not null default now()
);
create table if not exists cq_site_settings (key text primary key, value jsonb not null, updated_by uuid references cq_accounts(id), updated_at timestamptz not null default now());
create table if not exists cq_product_pages (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references cq_products(id) on delete cascade,
  lang text not null check (lang in ('en','sw')),
  draft jsonb not null default '{"blocks":[]}', published jsonb, version int not null default 0,
  status text not null default 'draft' check (status in ('draft','in_review','approved','published')),
  requested_by uuid references cq_accounts(id), clinical_approved_by uuid references cq_accounts(id),
  published_by uuid references cq_accounts(id), published_at timestamptz, updated_at timestamptz not null default now(),
  unique (product_id, lang)
);
create table if not exists cq_page_versions (
  id bigint generated always as identity primary key, page_id uuid not null references cq_product_pages(id) on delete cascade,
  version int not null, content jsonb not null, published_by uuid references cq_accounts(id),
  clinical_approved_by uuid references cq_accounts(id), published_at timestamptz not null default now()
);
create table if not exists cq_product_releases (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references cq_products(id) on delete cascade,
  channel text not null check (channel in ('alpha','beta','stable')),
  version_name text not null, platform text not null default 'android',
  file_path text, sha256 text, size_bytes bigint, min_os text, notes_en text, notes_sw text,
  rollout_pct int not null default 0 check (rollout_pct between 0 and 100),
  status text not null default 'draft' check (status in ('draft','live','halted','rolled_back')),
  created_by uuid references cq_accounts(id), created_at timestamptz not null default now()
);
create table if not exists cq_beta_programs (
  id uuid primary key default gen_random_uuid(),
  product_id uuid unique not null references cq_products(id) on delete cascade,
  is_open boolean not null default false, capacity int, form_schema jsonb not null default '{}', regions text[] not null default '{}',
  updated_at timestamptz not null default now()
);
do $$ declare t text; begin
  foreach t in array array['cq_products','cq_site_settings','cq_product_pages','cq_page_versions','cq_product_releases','cq_beta_programs'] loop
    execute format('alter table %I enable row level security', t);
  end loop; end $$;
insert into cq_site_settings(key, value) values
  ('arrangement', '"grid"'), ('intro', '{"enabled":true,"max_ms":3000,"once_per_session":true}'),
  ('pill', '{"text_en":"Join our beta","text_sw":null}')
on conflict (key) do nothing;

-- 5. Public catalog: published data only, no internal ids ------------------------------
create or replace function cq_get_catalog(p_lang text default 'en') returns jsonb
language sql stable security definer set search_path = public as $$
select jsonb_build_object(
  'settings', coalesce((select jsonb_object_agg(key, value) from cq_site_settings), '{}'::jsonb),
  'beta_open', exists(select 1 from cq_beta_programs b join cq_products p on p.id = b.product_id
                      where b.is_open and p.stage in ('closed_beta','open_beta')),
  'products', coalesce((select jsonb_agg(jsonb_build_object(
      'slug', p.slug,
      'name', case when p_lang = 'sw' then coalesce(p.name_sw, p.name_en) else p.name_en end,
      'tagline', case when p_lang = 'sw' then coalesce(p.tagline_sw, p.tagline_en) else p.tagline_en end,
      'accent', p.accent, 'logo', p.logo_path, 'stage', p.stage, 'access', p.access_mode,
      'orbit', p.show_in_orbit, 'orbit_order', p.orbit_order, 'card_order', p.card_order,
      'page', coalesce(
        (select pg.published from cq_product_pages pg where pg.product_id = p.id and pg.lang = case when p_lang = 'sw' then 'sw' else 'en' end),
        (select pg.published from cq_product_pages pg where pg.product_id = p.id and pg.lang = 'en'))
    ) order by p.card_order) from cq_products p where p.stage <> 'concept'), '[]'::jsonb)
) $$;

-- 6. HQ RPCs ---------------------------------------------------------------------------
create or replace function cq_hq_list_products(p_token text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; r jsonb;
begin
  a := cq_staff(p_token, array['product_manager','release_manager','content_editor','beta_operator','clinical_safety','security']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  select coalesce(jsonb_agg(to_jsonb(p) || jsonb_build_object(
      'pages', (select coalesce(jsonb_agg(jsonb_build_object('lang', pg.lang, 'status', pg.status, 'version', pg.version, 'updated_at', pg.updated_at)), '[]'::jsonb) from cq_product_pages pg where pg.product_id = p.id),
      'beta', (select to_jsonb(b) from cq_beta_programs b where b.product_id = p.id)) order by p.card_order), '[]'::jsonb)
    into r from cq_products p;
  return jsonb_build_object('ok', true, 'products', r);
end $$;

create or replace function cq_hq_upsert_product(p_token text, p_slug text, p_patch jsonb) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts;
begin
  a := cq_staff(p_token, array['product_manager','release_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  insert into cq_products(slug, name_en) values (p_slug, coalesce(p_patch->>'name_en', p_slug)) on conflict (slug) do nothing;
  update cq_products set
    name_en = coalesce(p_patch->>'name_en', name_en), name_sw = coalesce(p_patch->>'name_sw', name_sw),
    tagline_en = coalesce(p_patch->>'tagline_en', tagline_en), tagline_sw = coalesce(p_patch->>'tagline_sw', tagline_sw),
    logo_path = coalesce(p_patch->>'logo_path', logo_path), accent = coalesce(p_patch->>'accent', accent),
    clinical = coalesce((p_patch->>'clinical')::boolean, clinical),
    access_mode = coalesce(p_patch->>'access_mode', access_mode),
    show_in_orbit = coalesce((p_patch->>'show_in_orbit')::boolean, show_in_orbit),
    orbit_order = coalesce((p_patch->>'orbit_order')::int, orbit_order), card_order = coalesce((p_patch->>'card_order')::int, card_order),
    platforms = case when p_patch ? 'platforms' then array(select jsonb_array_elements_text(p_patch->'platforms')) else platforms end,
    updated_by = a.id, updated_at = now()
  where slug = p_slug;
  perform cq_log(a, 'product_upsert', jsonb_build_object('slug', p_slug, 'patch', p_patch));
  return jsonb_build_object('ok', true);
end $$;

create or replace function cq_hq_set_stage(p_token text, p_slug text, p_stage text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; prod cq_products; ord text[] := array['concept','alpha','closed_beta','open_beta','ga','deprecated']; i_old int; i_new int;
begin
  a := cq_staff(p_token, array['release_manager','product_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  select * into prod from cq_products where slug = p_slug for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  if not (p_stage = any(ord)) then return jsonb_build_object('ok', false, 'error', 'bad_stage'); end if;
  i_old := array_position(ord, prod.stage); i_new := array_position(ord, p_stage);
  if p_stage <> 'deprecated' and abs(i_new - i_old) > 1 then return jsonb_build_object('ok', false, 'error', 'skip_not_allowed'); end if;
  if p_stage in ('closed_beta','open_beta') and not exists (select 1 from cq_beta_programs where product_id = prod.id) then
    return jsonb_build_object('ok', false, 'error', 'needs_beta_program'); end if;
  if p_stage = 'ga' then
    if prod.clinical and not exists (select 1 from cq_page_versions v join cq_product_pages pg on pg.id = v.page_id
         where pg.product_id = prod.id and pg.lang = 'en' and v.clinical_approved_by is not null) then
      return jsonb_build_object('ok', false, 'error', 'needs_clinical_approval'); end if;
    if not exists (select 1 from cq_product_releases where product_id = prod.id and channel = 'stable' and status = 'live' and sha256 is not null) then
      return jsonb_build_object('ok', false, 'error', 'needs_signed_stable_build'); end if;
  end if;
  update cq_products set stage = p_stage, updated_by = a.id, updated_at = now() where id = prod.id;
  perform cq_log(a, 'set_stage', jsonb_build_object('slug', p_slug, 'from', prod.stage, 'to', p_stage));
  return jsonb_build_object('ok', true);
end $$;

create or replace function cq_hq_save_page_draft(p_token text, p_slug text, p_lang text, p_draft jsonb) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; prod cq_products;
begin
  a := cq_staff(p_token, array['content_editor','product_manager','release_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  if p_lang not in ('en','sw') then return jsonb_build_object('ok', false, 'error', 'bad_lang'); end if;
  select * into prod from cq_products where slug = p_slug;
  if not found then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  if coalesce(jsonb_typeof(p_draft->'blocks'), '') <> 'array' then return jsonb_build_object('ok', false, 'error', 'bad_draft'); end if;
  if p_draft::text ~* 'offline[- ](native|only)' then return jsonb_build_object('ok', false, 'error', 'copy_lint_failed'); end if;
  if prod.clinical and not exists (select 1 from jsonb_array_elements(p_draft->'blocks') b where b->>'type' = 'safety_statement') then
    return jsonb_build_object('ok', false, 'error', 'safety_statement_required'); end if;
  insert into cq_product_pages(product_id, lang, draft, status) values (prod.id, p_lang, p_draft, 'draft')
  on conflict (product_id, lang) do update set draft = excluded.draft, status = 'draft', requested_by = null, clinical_approved_by = null, updated_at = now();
  perform cq_log(a, 'page_draft_saved', jsonb_build_object('slug', p_slug, 'lang', p_lang));
  return jsonb_build_object('ok', true);
end $$;

create or replace function cq_hq_request_publish(p_token text, p_slug text, p_lang text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; n int;
begin
  a := cq_staff(p_token, array['content_editor','product_manager','release_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  update cq_product_pages pg set status = 'in_review', requested_by = a.id, clinical_approved_by = null, updated_at = now()
    from cq_products p where p.id = pg.product_id and p.slug = p_slug and pg.lang = p_lang and pg.status = 'draft';
  get diagnostics n = row_count;
  if n = 0 then return jsonb_build_object('ok', false, 'error', 'not_draft'); end if;
  perform cq_log(a, 'publish_requested', jsonb_build_object('slug', p_slug, 'lang', p_lang));
  return jsonb_build_object('ok', true);
end $$;

create or replace function cq_hq_approve_page(p_token text, p_slug text, p_lang text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; n int;
begin
  a := cq_staff(p_token, array['clinical_safety'], false);   -- master cannot self-approve clinical copy
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  update cq_product_pages pg set status = 'approved', clinical_approved_by = a.id, updated_at = now()
    from cq_products p where p.id = pg.product_id and p.slug = p_slug and pg.lang = p_lang
      and pg.status = 'in_review' and pg.requested_by is not null and pg.requested_by <> a.id;
  get diagnostics n = row_count;
  if n = 0 then return jsonb_build_object('ok', false, 'error', 'not_in_review_or_self_approval'); end if;
  perform cq_log(a, 'page_approved', jsonb_build_object('slug', p_slug, 'lang', p_lang));
  return jsonb_build_object('ok', true);
end $$;

create or replace function cq_hq_publish_page(p_token text, p_slug text, p_lang text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; prod cq_products; pg cq_product_pages; v int;
begin
  a := cq_staff(p_token, array['release_manager','product_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  select * into prod from cq_products where slug = p_slug;
  if not found then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  select * into pg from cq_product_pages where product_id = prod.id and lang = p_lang for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'no_page'); end if;
  if prod.clinical then
    if pg.status <> 'approved' or pg.clinical_approved_by is null or pg.clinical_approved_by = pg.requested_by then
      return jsonb_build_object('ok', false, 'error', 'needs_clinical_approval'); end if;
  elsif pg.status not in ('in_review','approved') then
    return jsonb_build_object('ok', false, 'error', 'not_requested');
  end if;
  update cq_product_pages set published = draft, version = version + 1, status = 'published', published_by = a.id, published_at = now()
    where id = pg.id returning version into v;
  insert into cq_page_versions(page_id, version, content, published_by, clinical_approved_by) values (pg.id, v, pg.draft, a.id, pg.clinical_approved_by);
  perform cq_log(a, 'page_published', jsonb_build_object('slug', p_slug, 'lang', p_lang, 'version', v));
  return jsonb_build_object('ok', true, 'version', v);
end $$;

create or replace function cq_hq_rollback_page(p_token text, p_slug text, p_lang text, p_version int) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; pg cq_product_pages; c jsonb; ap uuid; v int;
begin
  a := cq_staff(p_token, array['release_manager','product_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  select g.* into pg from cq_product_pages g join cq_products p on p.id = g.product_id where p.slug = p_slug and g.lang = p_lang for update of g;
  if not found then return jsonb_build_object('ok', false, 'error', 'no_page'); end if;
  select content, clinical_approved_by into c, ap from cq_page_versions where page_id = pg.id and version = p_version;
  if not found then return jsonb_build_object('ok', false, 'error', 'no_such_version'); end if;
  update cq_product_pages set published = c, draft = c, version = version + 1, status = 'published', published_by = a.id, published_at = now()
    where id = pg.id returning version into v;
  insert into cq_page_versions(page_id, version, content, published_by, clinical_approved_by) values (pg.id, v, c, a.id, ap);
  perform cq_log(a, 'page_rollback', jsonb_build_object('slug', p_slug, 'lang', p_lang, 'to_version', p_version, 'new_version', v));
  return jsonb_build_object('ok', true, 'version', v);
end $$;

create or replace function cq_hq_set_site_setting(p_token text, p_key text, p_value jsonb) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts;
begin
  a := cq_staff(p_token, array['content_editor','product_manager','release_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  if p_key not in ('arrangement','intro','pill') then return jsonb_build_object('ok', false, 'error', 'bad_key'); end if;
  if p_key = 'arrangement' and p_value not in ('"grid"','"stagger"','"rail"') then return jsonb_build_object('ok', false, 'error', 'bad_value'); end if;
  insert into cq_site_settings(key, value, updated_by) values (p_key, p_value, a.id)
    on conflict (key) do update set value = excluded.value, updated_by = a.id, updated_at = now();
  perform cq_log(a, 'site_setting', jsonb_build_object('key', p_key, 'value', p_value));
  return jsonb_build_object('ok', true);
end $$;

create or replace function cq_hq_set_beta_program(p_token text, p_slug text, p_open boolean, p_capacity int) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; pid uuid;
begin
  a := cq_staff(p_token, array['beta_operator','release_manager','product_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  select id into pid from cq_products where slug = p_slug;
  if pid is null then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  insert into cq_beta_programs(product_id, is_open, capacity) values (pid, p_open, p_capacity)
    on conflict (product_id) do update set is_open = excluded.is_open, capacity = excluded.capacity, updated_at = now();
  perform cq_log(a, 'beta_program', jsonb_build_object('slug', p_slug, 'open', p_open, 'capacity', p_capacity));
  return jsonb_build_object('ok', true);
end $$;

create or replace function cq_hq_list_audit(p_token text, p_limit int default 100) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts;
begin
  a := cq_staff(p_token, array['security']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  return jsonb_build_object('ok', true, 'rows', (select coalesce(jsonb_agg(to_jsonb(x)), '[]'::jsonb)
    from (select id, actor, role, action, detail, at, prev_hash, row_hash from cq_audit order by id desc limit least(greatest(p_limit, 1), 500)) x));
end $$;

-- 7. Beta endpoint hardening -----------------------------------------------------------
-- Status lookup: no personal data, rate limited per IP and per reference.
create or replace function cq_check_beta_status(p_ref text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare app cq_beta_applications; ref text := upper(trim(p_ref));
begin
  if not cq_rl('bs:ip:' || cq_client_ip(), 20, interval '1 hour') or not cq_rl('bs:ref:' || ref, 30, interval '1 hour') then
    return jsonb_build_object('ok', false, 'error', 'rate_limited'); end if;
  select * into app from cq_beta_applications where ref_code = ref;
  if not found then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  return jsonb_build_object('ok', true, 'ref_code', app.ref_code, 'status', app.status, 'created_at', app.created_at);
end $$;

-- Key verification: wrap the existing function (body not reviewed here) with rate limits.
do $$ begin
  if not exists (select 1 from pg_proc where proname = 'cq_verify_beta_key_core') then
    alter function cq_verify_beta_key(text, text) rename to cq_verify_beta_key_core;
  end if;
end $$;
create or replace function cq_verify_beta_key(p_email text, p_key text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
begin
  if not cq_rl('vk:ip:' || cq_client_ip(), 10, interval '1 hour') or not cq_rl('vk:em:' || lower(trim(p_email)), 5, interval '1 hour') then
    return jsonb_build_object('ok', false, 'error', 'rate_limited'); end if;
  return cq_verify_beta_key_core(p_email, p_key);
end $$;

-- 8. Grants ----------------------------------------------------------------------------
do $$ declare f record; begin
  for f in select p.oid::regprocedure as sig from pg_proc p join pg_namespace n on n.oid = p.pronamespace
           where n.nspname = 'public' and p.proname in ('cq_staff','cq_rl','cq_log','cq_client_ip','cq_verify_beta_key_core','cq_audit_chain','cq_audit_immutable')
  loop execute format('revoke all on function %s from public, anon, authenticated', f.sig); end loop;
end $$;
grant execute on function cq_get_catalog(text), cq_check_beta_status(text), cq_verify_beta_key(text, text) to anon, authenticated;
grant execute on function cq_hq_list_products(text), cq_hq_upsert_product(text, text, jsonb), cq_hq_set_stage(text, text, text),
  cq_hq_save_page_draft(text, text, text, jsonb), cq_hq_request_publish(text, text, text), cq_hq_approve_page(text, text, text),
  cq_hq_publish_page(text, text, text), cq_hq_rollback_page(text, text, text, int), cq_hq_set_site_setting(text, text, jsonb),
  cq_hq_set_beta_program(text, text, boolean, int), cq_hq_list_audit(text, int) to anon, authenticated;

commit;
