#!/usr/bin/env bash
# J7 check: with only the anon key, protected tables must return nothing and protected RPCs must refuse.
# Usage: SUPABASE_URL=https://xxxx.supabase.co SUPABASE_ANON_KEY=... ./anon_access_check.sh
set -u; fail=0
for t in cq_accounts cq_invites cq_sessions cq_credentials cq_usage_events cq_release_config cq_notices cq_audit cq_beta_applications \
         cq_products cq_site_settings cq_product_pages cq_page_versions cq_product_releases cq_beta_programs cq_rate_limit; do
  out=$(curl -s "$SUPABASE_URL/rest/v1/$t?select=*&limit=1" -H "apikey: $SUPABASE_ANON_KEY" -H "Authorization: Bearer $SUPABASE_ANON_KEY")
  if [ "$out" = "[]" ] || echo "$out" | grep -qiE "permission denied|not found|PGRST"; then echo "ok    $t"; else echo "FAIL  $t returned data"; fail=1; fi
done
out=$(curl -s -X POST "$SUPABASE_URL/rest/v1/rpc/cq_hq_list_audit" -H "apikey: $SUPABASE_ANON_KEY" -H "Content-Type: application/json" -d '{"p_token":"x"}')
echo "$out" | grep -q forbidden && echo "ok    cq_hq_list_audit refuses a bad token" || { echo "FAIL  cq_hq_list_audit: $out"; fail=1; }
for i in $(seq 1 25); do out=$(curl -s -X POST "$SUPABASE_URL/rest/v1/rpc/cq_check_beta_status" -H "apikey: $SUPABASE_ANON_KEY" -H "Content-Type: application/json" -d '{"p_ref":"CQ-BETA-000000"}'); done
echo "$out" | grep -q rate_limited && echo "ok    status lookup rate limited" || { echo "FAIL  no rate limit after 25 calls: $out"; fail=1; }
exit $fail
