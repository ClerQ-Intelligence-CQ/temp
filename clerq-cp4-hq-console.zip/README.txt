ClerQ checkpoint 4: HQ console Product Studio, wired to the CP3 backend

Drop-in files (copy over hq-console/, same paths):
  src/pages/ProductStudio.tsx   rewritten studio: details, stage, page builder with draft/review/approve/publish/rollback, beta program
  src/lib/studioApi.ts          typed wrappers for the cq_hq_* RPCs with readable error messages
  src/lib/supabase.ts           URL and anon key now come from env only (the old file had them hardcoded)
  src/lib/api.ts                role union extended with the six new roles
  src/vite-env.d.ts             fixes the import.meta.env type error
  src/pages/Clinicians.tsx      fixes a crash: the invite-email modal referenced dispatchedClinician, which no longer exists
  src/data/clinicalRules.ts     fixes a malformed investigations entry that failed the typecheck
  .env.example                  VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY
  hq-console-src.diff           full diff against your uploaded repo, to review before copying

Database: run schema/0006_hq_get_page.sql after 0005_product_studio.sql (staging first).

Checked: npx tsc --noEmit passes, npx vite build succeeds.
Not checked: nothing here was run against a real Supabase database or opened in a browser.
Rotate the anon key if the old hardcoded one was ever committed to a public repo.
