import { supabase } from './supabase';

export type Stage = 'concept' | 'alpha' | 'closed_beta' | 'open_beta' | 'ga' | 'deprecated';
export type Access = 'public' | 'waitlist' | 'invite_key' | 'account_only';
export type BlockType =
  | 'hero' | 'stat_strip' | 'feature_grid' | 'screenshots' | 'video' | 'viewport_3d'
  | 'faq' | 'safety_statement' | 'cta' | 'changelog' | 'download';
export interface Block { type: BlockType; props: { title?: string; body?: string } }

export interface StudioProduct {
  slug: string;
  name_en: string;
  name_sw: string | null;
  tagline_en: string | null;
  tagline_sw: string | null;
  accent: string | null;
  clinical: boolean;
  stage: Stage;
  access_mode: Access;
  show_in_orbit: boolean;
  orbit_order: number;
  card_order: number;
  updated_at: string;
  pages: Array<{ lang: 'en' | 'sw'; status: string; version: number; updated_at: string }>;
  beta: { is_open: boolean; capacity: number | null } | null;
}

export type PageStatus = 'draft' | 'in_review' | 'approved' | 'published';
export interface PageState {
  page: null | {
    draft: { blocks: Block[] };
    published: { blocks: Block[] } | null;
    status: PageStatus;
    version: number;
    requested_by_me: boolean;
  };
  versions: Array<{ version: number; published_at: string }>;
}

const MESSAGES: Record<string, string> = {
  forbidden: 'Your role cannot do this.',
  not_found: 'Product not found.',
  bad_stage: 'Unknown stage.',
  skip_not_allowed: 'Stages move one step at a time.',
  needs_beta_program: 'Create a beta program on the Beta tab before moving to a beta stage.',
  needs_clinical_approval: 'A clinical safety approval from a different person is required first.',
  needs_signed_stable_build: 'General availability needs a live stable release with a SHA-256 hash.',
  bad_lang: 'Unknown language.',
  bad_draft: 'The page draft is malformed.',
  copy_lint_failed: 'The copy contains a banned phrase. Use "offline-capable".',
  safety_statement_required: 'Clinical products must keep a safety statement block.',
  not_draft: 'Save a draft before requesting publish.',
  not_in_review_or_self_approval: 'Nothing to approve, or you requested this publish yourself.',
  no_page: 'No page exists yet. Save a draft first.',
  not_requested: 'Request publish first.',
  no_such_version: 'That version does not exist.',
  bad_key: 'Unknown setting.',
  bad_value: 'Invalid value for this setting.',
};

export class StudioError extends Error {
  code: string;
  constructor(code: string) {
    super(MESSAGES[code] ?? `Request failed (${code})`);
    this.code = code;
  }
}

async function call<T>(fn: string, args: Record<string, unknown>): Promise<T> {
  const { data, error } = await supabase.rpc(fn, args);
  if (error) throw new Error(error.message);
  if (!data || data.ok !== true) throw new StudioError(String(data?.error ?? 'unknown'));
  return data as T;
}

export async function listProducts(token: string): Promise<StudioProduct[]> {
  return (await call<{ products: StudioProduct[] }>('cq_hq_list_products', { p_token: token })).products;
}
export async function upsertProduct(token: string, slug: string, patch: Record<string, unknown>) {
  await call('cq_hq_upsert_product', { p_token: token, p_slug: slug, p_patch: patch });
}
export async function setStage(token: string, slug: string, stage: Stage) {
  await call('cq_hq_set_stage', { p_token: token, p_slug: slug, p_stage: stage });
}
export async function getPage(token: string, slug: string, lang: 'en' | 'sw'): Promise<PageState> {
  return call<PageState>('cq_hq_get_page', { p_token: token, p_slug: slug, p_lang: lang });
}
export async function saveDraft(token: string, slug: string, lang: 'en' | 'sw', blocks: Block[]) {
  await call('cq_hq_save_page_draft', { p_token: token, p_slug: slug, p_lang: lang, p_draft: { blocks } });
}
export async function requestPublish(token: string, slug: string, lang: 'en' | 'sw') {
  await call('cq_hq_request_publish', { p_token: token, p_slug: slug, p_lang: lang });
}
export async function approvePage(token: string, slug: string, lang: 'en' | 'sw') {
  await call('cq_hq_approve_page', { p_token: token, p_slug: slug, p_lang: lang });
}
export async function publishPage(token: string, slug: string, lang: 'en' | 'sw') {
  await call('cq_hq_publish_page', { p_token: token, p_slug: slug, p_lang: lang });
}
export async function rollbackPage(token: string, slug: string, lang: 'en' | 'sw', version: number) {
  await call('cq_hq_rollback_page', { p_token: token, p_slug: slug, p_lang: lang, p_version: version });
}
export async function setSiteSetting(token: string, key: 'arrangement' | 'intro' | 'pill', value: unknown) {
  await call('cq_hq_set_site_setting', { p_token: token, p_key: key, p_value: value });
}
export async function setBetaProgram(token: string, slug: string, open: boolean, capacity: number | null) {
  await call('cq_hq_set_beta_program', { p_token: token, p_slug: slug, p_open: open, p_capacity: capacity });
}
export async function getSiteSettings(): Promise<{ arrangement?: string }> {
  const { data, error } = await supabase.rpc('cq_get_catalog', { p_lang: 'en' });
  if (error) throw new Error(error.message);
  return (data?.settings ?? {}) as { arrangement?: string };
}
