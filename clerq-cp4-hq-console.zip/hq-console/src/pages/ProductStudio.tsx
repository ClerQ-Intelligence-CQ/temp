import React, { useCallback, useEffect, useState } from 'react';
import { Box, Save, Plus, Trash2, CheckCircle, RefreshCw, ShieldCheck, Layers } from 'lucide-react';
import { useAuth } from '../lib/auth';
import * as S from '../lib/studioApi';

const STAGES: Array<{ id: S.Stage; label: string }> = [
  { id: 'concept', label: 'Concept' },
  { id: 'alpha', label: 'Alpha' },
  { id: 'closed_beta', label: 'Closed beta' },
  { id: 'open_beta', label: 'Open beta' },
  { id: 'ga', label: 'General availability' },
  { id: 'deprecated', label: 'Deprecated' },
];
const BLOCK_TYPES: S.BlockType[] = [
  'hero', 'stat_strip', 'feature_grid', 'screenshots', 'video', 'viewport_3d', 'faq', 'safety_statement', 'cta', 'changelog', 'download',
];
const ACCESS: Array<{ id: S.Access; label: string }> = [
  { id: 'public', label: 'Public' },
  { id: 'waitlist', label: 'Waitlist' },
  { id: 'invite_key', label: 'Invite key' },
  { id: 'account_only', label: 'Account only' },
];
const BANNED = /offline[- ](native|only)/i;
const label = (t: string) => t.replace(/_/g, ' ');
const safetyText = (name: string) =>
  `${name} is an assistive clinical decision guidance tool grounded in the Tanzania National Standard Treatment Guidelines (STG 2026). Attending clinicians retain ultimate clinical responsibility.`;

const card: React.CSSProperties = {
  background: 'var(--bg-surface)', border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-md)', padding: 16,
};
const field: React.CSSProperties = {
  width: '100%', padding: '8px 10px', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-sm)',
  background: 'var(--bg-surface)', color: 'var(--text-primary)', fontSize: 13, boxSizing: 'border-box',
};
const cap: React.CSSProperties = { fontSize: 12, color: 'var(--text-muted)', margin: '12px 0 4px', display: 'block' };

type Tab = 'details' | 'stage' | 'page' | 'beta';
type Lang = 'en' | 'sw';

export const ProductStudio: React.FC = () => {
  const { token, user } = useAuth();
  const role = user?.role ?? 'clinician';
  const canProduct = ['master', 'product_manager', 'release_manager'].includes(role);
  const canPage = canProduct || role === 'content_editor';
  const canApprove = role === 'clinical_safety';
  const canBeta = canProduct || role === 'beta_operator';

  const [products, setProducts] = useState<S.StudioProduct[]>([]);
  const [slug, setSlug] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>('details');
  const [lang, setLang] = useState<Lang>('en');
  const [msg, setMsg] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState<Partial<S.StudioProduct>>({});
  const [pageState, setPageState] = useState<S.PageState | null>(null);
  const [blocks, setBlocks] = useState<S.Block[]>([]);
  const [dirty, setDirty] = useState(false);
  const [arrangement, setArrangement] = useState('grid');
  const [newSlug, setNewSlug] = useState('');
  const [newName, setNewName] = useState('');
  const [capacity, setCapacity] = useState('');

  const prod = products.find(p => p.slug === slug) ?? null;

  const run = async (fn: () => Promise<unknown>, ok: string) => {
    setBusy(true);
    try { await fn(); setMsg({ kind: 'ok', text: ok }); }
    catch (e) { setMsg({ kind: 'err', text: e instanceof Error ? e.message : 'Request failed' }); }
    finally { setBusy(false); }
  };

  const refresh = useCallback(async () => {
    if (!token) return;
    try {
      const list = await S.listProducts(token);
      setProducts(list);
      setSlug(cur => cur ?? list[0]?.slug ?? null);
    } catch (e) { setMsg({ kind: 'err', text: e instanceof Error ? e.message : 'Could not load products' }); }
  }, [token]);

  const loadPage = useCallback(async () => {
    if (!token || !slug) return;
    try {
      const st = await S.getPage(token, slug, lang);
      setPageState(st);
      const p = products.find(x => x.slug === slug);
      const start: S.Block[] = st.page
        ? st.page.draft.blocks
        : [{ type: 'hero', props: { title: p?.name_en ?? '', body: p?.tagline_en ?? '' } },
           ...(p?.clinical ? [{ type: 'safety_statement' as const, props: { body: safetyText(p.name_en) } }] : [])];
      setBlocks(start);
      setDirty(!st.page);
    } catch (e) { setMsg({ kind: 'err', text: e instanceof Error ? e.message : 'Could not load page' }); }
  }, [token, slug, lang, products]);

  useEffect(() => { void refresh(); S.getSiteSettings().then(s => setArrangement(s.arrangement ?? 'grid')).catch(() => undefined); }, [refresh]);
  useEffect(() => { if (prod) { setForm(prod); setCapacity(prod.beta?.capacity?.toString() ?? ''); } }, [prod]);
  useEffect(() => { if (tab === 'page') void loadPage(); }, [tab, slug, lang]); // eslint-disable-line react-hooks/exhaustive-deps

  const lintHit = BANNED.test(blocks.map(b => `${b.props.title ?? ''} ${b.props.body ?? ''}`).join(' '));
  const status = pageState?.page?.status ?? null;
  const touch = (next: S.Block[]) => { setBlocks(next); setDirty(true); };
  const patchBlock = (i: number, patch: Partial<S.Block['props']>) =>
    touch(blocks.map((b, j) => (j === i ? { ...b, props: { ...b.props, ...patch } } : b)));
  const move = (i: number, d: number) => {
    const j = i + d;
    if (j < 0 || j >= blocks.length) return;
    const next = [...blocks];
    [next[i], next[j]] = [next[j], next[i]];
    touch(next);
  };

  if (!token) return null;
  const t = token;

  const saveDetails = () => prod && run(async () => {
    await S.upsertProduct(t, prod.slug, {
      name_en: form.name_en, name_sw: form.name_sw, tagline_en: form.tagline_en, tagline_sw: form.tagline_sw,
      accent: form.accent, clinical: form.clinical, access_mode: form.access_mode, show_in_orbit: form.show_in_orbit,
      orbit_order: form.orbit_order, card_order: form.card_order,
    });
    await refresh();
  }, 'Product saved');

  const reloadAll = async () => { await refresh(); await loadPage(); };

  return (
    <div className="animate-fade-in" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Box size={22} />
            <h1 style={{ fontSize: 24, fontWeight: 700, letterSpacing: '-0.02em' }}>Product Studio</h1>
          </div>
          <p style={{ fontSize: 14, color: 'var(--text-secondary)', marginTop: 4 }}>
            Everything the public site shows about a product is set here. Changes go live only when published.
          </p>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>Scroll arrangement</span>
          <select style={{ ...field, width: 140 }} value={arrangement} disabled={!canPage || busy}
            onChange={e => { const v = e.target.value; setArrangement(v); void run(() => S.setSiteSetting(t, 'arrangement', v), 'Arrangement saved'); }}>
            <option value="grid">Grid</option><option value="stagger">Staggered</option><option value="rail">Rail</option>
          </select>
          <button className="btn-secondary" onClick={() => void reloadAll()}><RefreshCw size={14} /><span>Refresh</span></button>
        </div>
      </div>

      {msg && (
        <div role="status" style={{ ...card, padding: '10px 14px', fontSize: 13,
          borderColor: msg.kind === 'err' ? 'var(--danger-border)' : 'var(--border-default)',
          background: msg.kind === 'err' ? 'var(--danger-bg)' : 'var(--success-bg)' }}>{msg.text}</div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(220px, 280px) 1fr', gap: 20, alignItems: 'start' }}>
        <div style={{ ...card, display: 'flex', flexDirection: 'column', gap: 6 }}>
          {products.length === 0 && <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>No products yet. Create the first one below.</p>}
          {products.map(p => (
            <button key={p.slug} onClick={() => setSlug(p.slug)} style={{ textAlign: 'left', padding: '10px 12px', cursor: 'pointer',
              borderRadius: 'var(--radius-sm)', border: `1px solid ${p.slug === slug ? 'var(--text-primary)' : 'var(--border-subtle)'}`,
              background: 'var(--bg-surface)', color: 'var(--text-primary)' }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: 8, fontWeight: 600, fontSize: 14 }}>
                <i style={{ width: 10, height: 10, borderRadius: '50%', background: p.accent ?? 'var(--border-strong)' }} />{p.name_en}
              </span>
              <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{label(p.stage)} - {label(p.access_mode)}</span>
            </button>
          ))}
          {canProduct && (
            <div style={{ borderTop: '1px solid var(--border-subtle)', marginTop: 8, paddingTop: 10 }}>
              <span style={{ ...cap, margin: '0 0 4px' }}>New product</span>
              <input style={field} placeholder="slug (lowercase, hyphens)" value={newSlug} onChange={e => setNewSlug(e.target.value)} />
              <input style={{ ...field, marginTop: 6 }} placeholder="Name" value={newName} onChange={e => setNewName(e.target.value)} />
              <button className="btn-primary" style={{ marginTop: 8, width: '100%' }} disabled={busy || !newSlug || !newName}
                onClick={() => void run(async () => { await S.upsertProduct(t, newSlug, { name_en: newName }); setSlug(newSlug); setNewSlug(''); setNewName(''); await refresh(); }, 'Product created at Concept stage')}>
                <Plus size={14} /><span>Create</span>
              </button>
            </div>
          )}
        </div>

        {prod && (
          <div style={card}>
            <div style={{ display: 'flex', gap: 6, marginBottom: 14, flexWrap: 'wrap' }}>
              {(['details', 'stage', 'page', 'beta'] as Tab[]).map(k => (
                <button key={k} onClick={() => setTab(k)} className={tab === k ? 'btn-primary' : 'btn-secondary'}>{label(k)}</button>
              ))}
            </div>

            {tab === 'details' && (
              <div>
                <span style={cap}>Name (English)</span><input style={field} disabled={!canProduct} value={form.name_en ?? ''} onChange={e => setForm({ ...form, name_en: e.target.value })} />
                <span style={cap}>Name (Swahili)</span><input style={field} disabled={!canProduct} value={form.name_sw ?? ''} onChange={e => setForm({ ...form, name_sw: e.target.value })} />
                <span style={cap}>Tagline (English)</span><input style={field} disabled={!canProduct} value={form.tagline_en ?? ''} onChange={e => setForm({ ...form, tagline_en: e.target.value })} />
                <span style={cap}>Tagline (Swahili)</span><input style={field} disabled={!canProduct} value={form.tagline_sw ?? ''} onChange={e => setForm({ ...form, tagline_sw: e.target.value })} />
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: 10 }}>
                  <div><span style={cap}>Accent color</span><input style={field} disabled={!canProduct} placeholder="#00d09c" value={form.accent ?? ''} onChange={e => setForm({ ...form, accent: e.target.value })} /></div>
                  <div><span style={cap}>Access</span>
                    <select style={field} disabled={!canProduct} value={form.access_mode ?? 'invite_key'} onChange={e => setForm({ ...form, access_mode: e.target.value as S.Access })}>
                      {ACCESS.map(a => <option key={a.id} value={a.id}>{a.label}</option>)}
                    </select></div>
                  <div><span style={cap}>Orbit order</span><input style={field} type="number" disabled={!canProduct} value={form.orbit_order ?? 0} onChange={e => setForm({ ...form, orbit_order: Number(e.target.value) })} /></div>
                  <div><span style={cap}>Card order</span><input style={field} type="number" disabled={!canProduct} value={form.card_order ?? 0} onChange={e => setForm({ ...form, card_order: Number(e.target.value) })} /></div>
                </div>
                <label style={{ display: 'flex', gap: 8, marginTop: 14, fontSize: 13 }}>
                  <input type="checkbox" disabled={!canProduct} checked={!!form.show_in_orbit} onChange={e => setForm({ ...form, show_in_orbit: e.target.checked })} />
                  Show in the homepage orbit (counts toward "products live")
                </label>
                <label style={{ display: 'flex', gap: 8, marginTop: 8, fontSize: 13 }}>
                  <input type="checkbox" disabled={!canProduct} checked={!!form.clinical} onChange={e => setForm({ ...form, clinical: e.target.checked })} />
                  Clinical product (requires a safety statement and clinical safety approval to publish)
                </label>
                {canProduct && <button className="btn-primary" style={{ marginTop: 16 }} disabled={busy} onClick={() => void saveDetails()}><Save size={14} /><span>Save details</span></button>}
              </div>
            )}

            {tab === 'stage' && (
              <div>
                <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginBottom: 12 }}>
                  Current stage: <strong>{label(prod.stage)}</strong>. Stages move one step at a time. Beta stages need a beta program. General availability needs clinical approval and a live stable release.
                </p>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {STAGES.map(s => (
                    <button key={s.id} disabled={!canProduct || busy || s.id === prod.stage}
                      className={s.id === prod.stage ? 'btn-primary' : 'btn-secondary'} style={{ justifyContent: 'flex-start' }}
                      onClick={() => void run(async () => { await S.setStage(t, prod.slug, s.id); await refresh(); }, `Moved to ${s.label}`)}>
                      {s.id === prod.stage ? <CheckCircle size={14} /> : <Layers size={14} />}<span>{s.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {tab === 'page' && (
              <div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', marginBottom: 10 }}>
                  <select style={{ ...field, width: 110 }} value={lang} onChange={e => setLang(e.target.value as Lang)}>
                    <option value="en">English</option><option value="sw">Swahili</option>
                  </select>
                  <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>
                    {status ? `Status: ${label(status)}, published version ${pageState?.page?.version ?? 0}` : 'No saved draft yet'}
                    {dirty ? ' - unsaved changes' : ''}
                  </span>
                </div>
                {lintHit && <p style={{ fontSize: 13, color: 'var(--danger)', marginBottom: 8 }}>Use "offline-capable" instead of "offline-native" or "offline-only".</p>}
                {lang === 'sw' && <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 8 }}>Swahili copy should be reviewed by a clinician before publishing. Missing Swahili falls back to English.</p>}

                {blocks.map((b, i) => (
                  <div key={i} style={{ ...card, padding: 12, marginBottom: 8 }}>
                    <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                      <select style={{ ...field, width: 170 }} disabled={!canPage || b.type === 'safety_statement'} value={b.type}
                        onChange={e => touch(blocks.map((x, j) => (j === i ? { ...x, type: e.target.value as S.BlockType } : x)))}>
                        {BLOCK_TYPES.map(bt => <option key={bt} value={bt}>{label(bt)}</option>)}
                      </select>
                      <span style={{ flex: 1 }} />
                      <button className="btn-secondary" disabled={!canPage || i === 0} onClick={() => move(i, -1)}>Up</button>
                      <button className="btn-secondary" disabled={!canPage || i === blocks.length - 1} onClick={() => move(i, 1)}>Down</button>
                      {b.type === 'safety_statement' && prod.clinical
                        ? <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>Required</span>
                        : <button className="btn-danger" disabled={!canPage} onClick={() => touch(blocks.filter((_, j) => j !== i))} aria-label="Remove block"><Trash2 size={14} /></button>}
                    </div>
                    <input style={{ ...field, marginTop: 8 }} disabled={!canPage} placeholder="Title" value={b.props.title ?? ''} onChange={e => patchBlock(i, { title: e.target.value })} />
                    <textarea style={{ ...field, marginTop: 6, minHeight: 56 }} disabled={!canPage} placeholder="Text" value={b.props.body ?? ''} onChange={e => patchBlock(i, { body: e.target.value })} />
                  </div>
                ))}
                {canPage && (
                  <select style={{ ...field, width: 200 }} value="" onChange={e => { if (e.target.value) touch([...blocks, { type: e.target.value as S.BlockType, props: {} }]); }}>
                    <option value="">Add block...</option>{BLOCK_TYPES.map(bt => <option key={bt} value={bt}>{label(bt)}</option>)}
                  </select>
                )}

                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 14 }}>
                  {canPage && <button className="btn-primary" disabled={busy || lintHit || !dirty}
                    onClick={() => void run(async () => { await S.saveDraft(t, prod.slug, lang, blocks); await loadPage(); await refresh(); }, 'Draft saved')}><Save size={14} /><span>Save draft</span></button>}
                  {canPage && <button className="btn-secondary" disabled={busy || dirty || status !== 'draft'}
                    onClick={() => void run(async () => { await S.requestPublish(t, prod.slug, lang); await loadPage(); }, 'Publish requested')}><span>Request publish</span></button>}
                  {canApprove && <button className="btn-secondary" disabled={busy || status !== 'in_review' || !!pageState?.page?.requested_by_me}
                    onClick={() => void run(async () => { await S.approvePage(t, prod.slug, lang); await loadPage(); }, 'Approved for publishing')}><ShieldCheck size={14} /><span>Approve as clinical safety</span></button>}
                  {canProduct && <button className="btn-primary" disabled={busy || dirty || (prod.clinical ? status !== 'approved' : status !== 'in_review' && status !== 'approved')}
                    onClick={() => { if (window.confirm(`Publish this ${lang.toUpperCase()} page to the public site?`)) void run(async () => { await S.publishPage(t, prod.slug, lang); await loadPage(); await refresh(); }, 'Published'); }}><span>Publish</span></button>}
                </div>

                {canProduct && (pageState?.versions.length ?? 0) > 0 && (
                  <div style={{ marginTop: 16 }}>
                    <span style={cap}>Roll back to a published version</span>
                    <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                      {pageState?.versions.map(v => (
                        <button key={v.version} className="btn-secondary" disabled={busy}
                          onClick={() => { if (window.confirm(`Roll back to version ${v.version}? It goes live immediately.`)) void run(async () => { await S.rollbackPage(t, prod.slug, lang, v.version); await loadPage(); }, `Rolled back to version ${v.version}`); }}>
                          v{v.version} - {new Date(v.published_at).toLocaleDateString()}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {tab === 'beta' && (
              <div>
                <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginBottom: 10 }}>
                  {prod.beta ? `Beta program is ${prod.beta.is_open ? 'open' : 'closed'}.` : 'No beta program yet.'} The homepage "Join our beta" pill shows only while a product is in a beta stage with an open program.
                </p>
                <span style={cap}>Capacity (leave empty for no limit)</span>
                <input style={{ ...field, width: 160 }} type="number" disabled={!canBeta} value={capacity} onChange={e => setCapacity(e.target.value)} />
                {canBeta && (
                  <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
                    <button className="btn-primary" disabled={busy}
                      onClick={() => void run(async () => { await S.setBetaProgram(t, prod.slug, true, capacity ? Number(capacity) : null); await refresh(); }, 'Beta program open')}>Open program</button>
                    <button className="btn-secondary" disabled={busy || !prod.beta}
                      onClick={() => void run(async () => { await S.setBetaProgram(t, prod.slug, false, capacity ? Number(capacity) : null); await refresh(); }, 'Beta program closed')}>Close program</button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductStudio;
