-- 0006_hq_get_page.sql: lets the Product Studio load a page draft, its status and its version history.
-- Run after 0005_product_studio.sql. Not executed against a database yet: run on staging first.
create or replace function cq_hq_get_page(p_token text, p_slug text, p_lang text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; pg cq_product_pages;
begin
  a := cq_staff(p_token, array['product_manager','release_manager','content_editor','clinical_safety','beta_operator']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  select g.* into pg from cq_product_pages g join cq_products p on p.id = g.product_id where p.slug = p_slug and g.lang = p_lang;
  if not found then return jsonb_build_object('ok', true, 'page', null, 'versions', '[]'::jsonb); end if;
  return jsonb_build_object('ok', true,
    'page', jsonb_build_object('draft', pg.draft, 'published', pg.published, 'status', pg.status, 'version', pg.version,
                               'requested_by_me', pg.requested_by = a.id),
    'versions', (select coalesce(jsonb_agg(jsonb_build_object('version', v.version, 'published_at', v.published_at) order by v.version desc), '[]'::jsonb)
                 from cq_page_versions v where v.page_id = pg.id));
end $$;
grant execute on function cq_hq_get_page(text, text, text) to anon, authenticated;
