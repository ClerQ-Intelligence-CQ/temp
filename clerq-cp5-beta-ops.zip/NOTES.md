# CP5 notes

## What was verified
- Migrations 0001 to 0007 apply cleanly, in order, on a scratch PostgreSQL 16 (this is the first time 0005 and 0006 have been run at all).
- tests/smoke_0007.sql: all 41 assertions plus the grant, rate-limit and append-only checks pass. They cover who may call what, email masking by role, tester counts, stale devices, the support thread lifecycle, other clinicians being unable to read a thread, suspended testers losing their session, audit search, hash-chain verification, rate limits and append-only audit.
- The built HQ console was driven in a real browser against those functions (support and security roles): the dashboard, tester detail, a support reply, audit verify and the fleet page all worked with no app errors.
- nia-app/lib/supportApi.ts ran against the same functions: open, send, list, read, ownership and validation.

## What was not verified
- Nothing ran on Supabase itself (PostgREST, its default privileges, its time zone). Run on staging first.
- No Nia screen was built. I do not have the ClerQApp repo. Send app/(tabs) and lib/cqApi.ts and I will add a Support tab with an unread badge using supportApi.ts.
- Integrity events: the fleet and tester pages read events whose feature is "tamper" or "integrity", or whose action contains "tamper". I could not see what Nia actually emits. Export a few real events from a test phone and adjust the two filters in 0007 if the names differ. Until then these panels may show 0 even when a phone has tripped a check.
- Model install state and per-tester download progress are not shown: Nia does not send them. Emit an event like feature "setup", action "gemma_installed" and I will add the column.

## Security findings
1. Secrets in the Nia doc you shared. It contains a live Expo build token (EXPO_TOKEN) and the Android keystore password, which is also short and guessable. Treat both as exposed: revoke and reissue the Expo token, and change the keystore and key passwords. A release key cannot be replaced once users have the app, so protect the keystore file and keep an offline backup. Keep these out of docs, chats and repos.
2. 0005 left cq_log, cq_rl and cq_staff callable by anyone through the API. cq_log would let a stranger write forged audit rows naming any actor; cq_rl would let them burn another user's rate-limit window. 0007 revokes public execute on them (the smoke test proves it). Run 0007 before 0005 reaches production.
3. cq_session_account is also callable and returns the full account row, including pw_hash, to whoever holds a valid token (their own row). I left it alone because I cannot see whether Nia calls it directly. If it does not, revoke execute from anon and authenticated.
4. Issued invite keys sit in plain text in cq_beta_applications.otp_key after approval. 0007 adds a "Clear used keys" action (and clears the key when an invite is revoked). Better still: schedule cq_hq_scrub_keys, or stop storing the raw key after it has been shown once.
5. The audit log is append-only and cq_audit.actor references cq_accounts, so a staff account that has ever acted can never be deleted. That conflicts with erasure requests. Plan to anonymise the account row (blank name and email, set status suspended) instead of deleting it.
6. The Nia doc says the beta status lookup returns name, facility and cadre. That was the hole 0005 closed; the doc is out of date.
7. The HQ header says "ClerQ Production (CQ Cloud)" whatever environment it is on. Make that come from config so staging cannot be mistaken for production.
8. Support messages are free text. HQ shows a standing warning and staff can redact a message (audited). Nia should show the same warning above its message box.

## Roles at a glance
Beta Dashboard: beta_operator, support, product_manager, analyst, release_manager. Suspend or reinstate: beta_operator, product_manager. Invite revoke, extend and key clearing: beta_operator.
Support Desk: support, beta_operator, product_manager, release_manager, clinical_safety. Redact and edit saved replies: support, beta_operator, product_manager.
Fleet: network_maint, release_manager, analyst, security, product_manager, beta_operator. Audit Log: security. Master can do everything.
Support, analyst and others see masked emails where noted in the functions; beta_operator, support and master see full emails.
