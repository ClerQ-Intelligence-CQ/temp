ClerQ checkpoint 5: Beta Dashboard, Support Desk (real chat), Device Fleet, Audit Log

Apply on top of checkpoint 4 (the CP4 zip must already be in your hq-console).

backend/schema/0007_beta_ops_support.sql   run after 0005 and 0006, staging first
backend/tests/smoke_0007.sql               behaviour tests (scratch database only, never production)
hq-console/src/lib/opsApi.ts               typed wrappers for the new functions
hq-console/src/components/ui.tsx           shared table, banner and bar-chart helpers
hq-console/src/pages/BetaDashboard.tsx     funnel, testers, tester detail, invites, suspend and reinstate
hq-console/src/pages/Support.tsx           REPLACES the old Support.tsx, which was a hardcoded fake conversation
hq-console/src/pages/Fleet.tsx             devices, version adoption, stale phones, integrity events
hq-console/src/pages/AuditLog.tsx          search, CSV export, hash-chain verification
hq-console/src/App.tsx, components/Layout.tsx   routes and role-aware navigation (diffs included)
nia-app/lib/supportApi.ts                  phone-side client for support chat (plain fetch, no new packages)
NOTES.md                                   what was verified, what was not, and security findings. Read this first.
