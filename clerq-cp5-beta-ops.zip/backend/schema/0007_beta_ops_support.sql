-- 0007_beta_ops_support.sql
-- Beta operations dashboard, tester management, support desk (clinician <-> staff chat), device fleet, audit search.
-- Run after 0005 and 0006. Applied cleanly and smoke-tested on a scratch PostgreSQL 16 (see tests/smoke_0007.sql);
-- NOT yet run on Supabase itself. Run on staging first.
-- Privacy: no patient data is stored or read here. Support text is free text typed by clinicians, so HQ shows a
-- standing warning and staff can redact a message (audited).
begin;

-- 0. Close a hole in 0005: internal helpers were executable by anon through the API ------------------------
-- cq_log(a, ...) lets any caller write an audit row naming any actor; cq_rl(key,...) lets any caller burn another
-- user's rate-limit window; cq_staff returns the full account row. They are only ever called from other
-- SECURITY DEFINER functions, which run as the owner, so revoking public execute does not break them.
revoke execute on function cq_log(cq_accounts, text, jsonb) from public, anon, authenticated;
revoke execute on function cq_rl(text, int, interval) from public, anon, authenticated;
revoke execute on function cq_staff(text, text[], boolean) from public, anon, authenticated;
revoke execute on function cq_client_ip() from public, anon, authenticated;

-- 1. Helpers (internal only) ---------------------------------------------------------------------------
create or replace function cq_ver_num(v text) returns int[] language sql immutable as $$
  select coalesce(array(select coalesce(nullif(x, ''), '0')::int
                        from unnest(string_to_array(regexp_replace(coalesce(v, ''), '[^0-9.]', '', 'g'), '.')) x), '{}'::int[]) $$;
create or replace function cq_mask_email(e text) returns text language sql immutable as $$
  select case when e is null or position('@' in e) < 2 then e
              else left(e, 1) || repeat('*', greatest(length(split_part(e, '@', 1)) - 1, 1)) || '@' || split_part(e, '@', 2) end $$;
revoke execute on function cq_ver_num(text), cq_mask_email(text) from public, anon, authenticated;

-- 2. Support desk tables --------------------------------------------------------------------------------
create table if not exists cq_support_threads (
  id uuid primary key default gen_random_uuid(),
  account_id uuid not null references cq_accounts(id) on delete cascade,
  subject text not null check (char_length(subject) between 3 and 120),
  category text not null default 'other' check (category in ('install','model_download','login','clinical_content','crash','feedback','other')),
  status text not null default 'open' check (status in ('open','pending','resolved')),
  priority text not null default 'normal' check (priority in ('low','normal','high','urgent')),
  assigned_to uuid references cq_accounts(id) on delete set null,
  device_id text, app_version text,
  created_at timestamptz not null default now(),
  last_message_at timestamptz not null default now(),
  last_sender text not null default 'clinician' check (last_sender in ('clinician','staff')),
  clinician_seen_at timestamptz
);
create index if not exists cq_support_threads_acct on cq_support_threads(account_id);
create index if not exists cq_support_threads_status on cq_support_threads(status, last_message_at desc);
create table if not exists cq_support_messages (
  id bigint generated always as identity primary key,
  thread_id uuid not null references cq_support_threads(id) on delete cascade,
  sender_kind text not null check (sender_kind in ('clinician','staff')),
  sender_id uuid references cq_accounts(id) on delete set null,
  body text not null check (char_length(body) between 1 and 2000),
  redacted boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists cq_support_messages_thread on cq_support_messages(thread_id, id);
create table if not exists cq_support_canned (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 2 and 80),
  body_en text not null check (char_length(body_en) <= 2000),
  body_sw text check (body_sw is null or char_length(body_sw) <= 2000),
  created_by uuid references cq_accounts(id) on delete set null,
  created_at timestamptz not null default now()
);
alter table cq_support_threads enable row level security;
alter table cq_support_messages enable row level security;
alter table cq_support_canned enable row level security;

-- Starter replies (English only: Swahili copy needs clinician review before it is added in HQ).
insert into cq_support_canned(title, body_en)
select t, b from (values
  ('Model download stalled', 'The model download resumes from where it stopped. Open Setup, tap Retry, and keep the app open on Wi-Fi if you can.'),
  ('Do not send patient details', 'Please do not include patient names or identifiers in support messages. Describe the problem without them and we will help from there.'),
  ('Key or login problem', 'Please confirm the email address your invite key was sent to and enter the key exactly as shown. If it still fails, tell us the time you tried and we will check it.')
) v(t, b)
where not exists (select 1 from cq_support_canned);

-- 3. Support: clinician side (any verified account, own threads only) ------------------------------------
create or replace function cq_support_open(p_token text, p_subject text, p_category text, p_body text, p_device_id text default null, p_app_version text default null) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; tid uuid;
begin
  a := cq_session_account(p_token);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'unauthorized'); end if;
  if not cq_rl('sup:open:' || a.id, 5, interval '1 day') then return jsonb_build_object('ok', false, 'error', 'rate_limited'); end if;
  if char_length(trim(coalesce(p_subject, ''))) < 3 or char_length(p_subject) > 120 then return jsonb_build_object('ok', false, 'error', 'bad_subject'); end if;
  if char_length(trim(coalesce(p_body, ''))) < 1 or char_length(p_body) > 2000 then return jsonb_build_object('ok', false, 'error', 'bad_body'); end if;
  if p_category is null or p_category not in ('install','model_download','login','clinical_content','crash','feedback','other') then p_category := 'other'; end if;
  insert into cq_support_threads(account_id, subject, category, device_id, app_version)
    values (a.id, trim(p_subject), p_category, left(p_device_id, 64), left(p_app_version, 20)) returning id into tid;
  insert into cq_support_messages(thread_id, sender_kind, sender_id, body) values (tid, 'clinician', a.id, trim(p_body));
  return jsonb_build_object('ok', true, 'thread_id', tid);
end $$;

create or replace function cq_support_send(p_token text, p_thread_id uuid, p_body text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; t cq_support_threads;
begin
  a := cq_session_account(p_token);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'unauthorized'); end if;
  if not cq_rl('sup:send:' || a.id, 30, interval '1 hour') then return jsonb_build_object('ok', false, 'error', 'rate_limited'); end if;
  select * into t from cq_support_threads where id = p_thread_id and account_id = a.id;
  if not found then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  if char_length(trim(coalesce(p_body, ''))) < 1 or char_length(p_body) > 2000 then return jsonb_build_object('ok', false, 'error', 'bad_body'); end if;
  insert into cq_support_messages(thread_id, sender_kind, sender_id, body) values (t.id, 'clinician', a.id, trim(p_body));
  update cq_support_threads set status = 'open', last_message_at = now(), last_sender = 'clinician', clinician_seen_at = now() where id = t.id;
  return jsonb_build_object('ok', true);
end $$;

create or replace function cq_support_my_threads(p_token text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts;
begin
  a := cq_session_account(p_token);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'unauthorized'); end if;
  return jsonb_build_object('ok', true, 'threads', (
    select coalesce(jsonb_agg(jsonb_build_object('id', t.id, 'subject', t.subject, 'category', t.category, 'status', t.status,
      'last_message_at', t.last_message_at,
      'unread', t.last_sender = 'staff' and (t.clinician_seen_at is null or t.clinician_seen_at < t.last_message_at)) order by t.last_message_at desc), '[]'::jsonb)
    from cq_support_threads t where t.account_id = a.id));
end $$;

create or replace function cq_support_thread(p_token text, p_thread_id uuid) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; t cq_support_threads;
begin
  a := cq_session_account(p_token);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'unauthorized'); end if;
  select * into t from cq_support_threads where id = p_thread_id and account_id = a.id;
  if not found then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  update cq_support_threads set clinician_seen_at = now() where id = t.id;
  return jsonb_build_object('ok', true,
    'thread', jsonb_build_object('id', t.id, 'subject', t.subject, 'category', t.category, 'status', t.status),
    'messages', (select coalesce(jsonb_agg(jsonb_build_object('id', m.id, 'from', m.sender_kind, 'body', m.body, 'at', m.created_at) order by m.id), '[]'::jsonb)
                 from cq_support_messages m where m.thread_id = t.id));
end $$;

-- 4. Support: staff side ------------------------------------------------------------------------------------
create or replace function cq_hq_support_list(p_token text, p_status text default null) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; full_pii boolean;
begin
  a := cq_staff(p_token, array['support','beta_operator','product_manager','release_manager','clinical_safety']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  full_pii := a.role in ('master','beta_operator','support');
  return jsonb_build_object('ok', true,
    'counts', (select jsonb_build_object('open', count(*) filter (where status = 'open'), 'pending', count(*) filter (where status = 'pending'),
                 'resolved', count(*) filter (where status = 'resolved'), 'urgent', count(*) filter (where priority = 'urgent' and status <> 'resolved'))
               from cq_support_threads),
    'threads', (select coalesce(jsonb_agg(x order by x.rank, x.last_message_at desc), '[]'::jsonb) from (
      select t.id, t.subject, t.category, t.status, t.priority, t.last_message_at, t.last_sender, t.created_at,
             t.app_version, t.assigned_to, ass.name as assigned_name,
             c.name as clinician_name, c.facility, c.cadre,
             case when full_pii then c.email else cq_mask_email(c.email) end as clinician_email,
             (select count(*) from cq_support_messages m where m.thread_id = t.id) as messages,
             case t.priority when 'urgent' then 0 when 'high' then 1 when 'normal' then 2 else 3 end as rank
      from cq_support_threads t join cq_accounts c on c.id = t.account_id left join cq_accounts ass on ass.id = t.assigned_to
      where (p_status is null or t.status = p_status)
      order by t.last_message_at desc limit 300) x));
end $$;

create or replace function cq_hq_support_thread(p_token text, p_thread_id uuid) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; t cq_support_threads; c cq_accounts; full_pii boolean;
begin
  a := cq_staff(p_token, array['support','beta_operator','product_manager','release_manager','clinical_safety']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  full_pii := a.role in ('master','beta_operator','support');
  select * into t from cq_support_threads where id = p_thread_id;
  if not found then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  select * into c from cq_accounts where id = t.account_id;
  return jsonb_build_object('ok', true,
    'thread', jsonb_build_object('id', t.id, 'subject', t.subject, 'category', t.category, 'status', t.status, 'priority', t.priority,
      'assigned_to', t.assigned_to, 'device_id', t.device_id, 'app_version', t.app_version, 'created_at', t.created_at),
    'clinician', jsonb_build_object('account_id', c.id, 'name', c.name, 'facility', c.facility, 'cadre', c.cadre, 'status', c.status,
      'email', case when full_pii then c.email else cq_mask_email(c.email) end, 'last_login', c.last_login),
    'messages', (select coalesce(jsonb_agg(jsonb_build_object('id', m.id, 'from', m.sender_kind, 'body', m.body, 'redacted', m.redacted, 'at', m.created_at,
                   'sender', case when m.sender_kind = 'staff' then coalesce(s.name, 'ClerQ Support') else c.name end) order by m.id), '[]'::jsonb)
                 from cq_support_messages m left join cq_accounts s on s.id = m.sender_id where m.thread_id = t.id));
end $$;

create or replace function cq_hq_support_reply(p_token text, p_thread_id uuid, p_body text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; t cq_support_threads;
begin
  a := cq_staff(p_token, array['support','beta_operator','product_manager','release_manager','clinical_safety']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  select * into t from cq_support_threads where id = p_thread_id;
  if not found then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  if char_length(trim(coalesce(p_body, ''))) < 1 or char_length(p_body) > 2000 then return jsonb_build_object('ok', false, 'error', 'bad_body'); end if;
  insert into cq_support_messages(thread_id, sender_kind, sender_id, body) values (t.id, 'staff', a.id, trim(p_body));
  update cq_support_threads set status = 'pending', last_message_at = now(), last_sender = 'staff', assigned_to = coalesce(assigned_to, a.id) where id = t.id;
  perform cq_log(a, 'support_reply', jsonb_build_object('thread_id', t.id));
  return jsonb_build_object('ok', true);
end $$;

create or replace function cq_hq_support_update(p_token text, p_thread_id uuid, p_patch jsonb) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; t cq_support_threads; k text;
begin
  a := cq_staff(p_token, array['support','beta_operator','product_manager','release_manager','clinical_safety']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  select * into t from cq_support_threads where id = p_thread_id;
  if not found then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  for k in select jsonb_object_keys(p_patch) loop
    if k not in ('status','priority','assign_to_me','unassign') then return jsonb_build_object('ok', false, 'error', 'bad_key'); end if;
  end loop;
  if p_patch ? 'status' and (p_patch->>'status') not in ('open','pending','resolved') then return jsonb_build_object('ok', false, 'error', 'bad_value'); end if;
  if p_patch ? 'priority' and (p_patch->>'priority') not in ('low','normal','high','urgent') then return jsonb_build_object('ok', false, 'error', 'bad_value'); end if;
  update cq_support_threads set
    status = coalesce(p_patch->>'status', status),
    priority = coalesce(p_patch->>'priority', priority),
    assigned_to = case when (p_patch->>'assign_to_me')::boolean is true then a.id when (p_patch->>'unassign')::boolean is true then null else assigned_to end
  where id = t.id;
  perform cq_log(a, 'support_update', jsonb_build_object('thread_id', t.id, 'patch', p_patch));
  return jsonb_build_object('ok', true);
end $$;

create or replace function cq_hq_support_redact(p_token text, p_message_id bigint) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; n int;
begin
  a := cq_staff(p_token, array['support','beta_operator','product_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  update cq_support_messages set body = '[removed by staff: may have contained personal or patient information]', redacted = true where id = p_message_id and not redacted;
  get diagnostics n = row_count;
  if n = 0 then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  perform cq_log(a, 'support_redact', jsonb_build_object('message_id', p_message_id));
  return jsonb_build_object('ok', true);
end $$;

create or replace function cq_hq_canned_list(p_token text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts;
begin
  a := cq_staff(p_token, array['support','beta_operator','product_manager','release_manager','clinical_safety']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  return jsonb_build_object('ok', true, 'replies', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'title', title, 'body_en', body_en, 'body_sw', body_sw) order by title), '[]'::jsonb) from cq_support_canned));
end $$;

create or replace function cq_hq_canned_save(p_token text, p_id uuid, p_title text, p_body_en text, p_body_sw text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; rid uuid;
begin
  a := cq_staff(p_token, array['support','beta_operator','product_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  if char_length(trim(coalesce(p_title, ''))) < 2 or char_length(trim(coalesce(p_body_en, ''))) < 1 then return jsonb_build_object('ok', false, 'error', 'bad_value'); end if;
  if p_id is null then
    insert into cq_support_canned(title, body_en, body_sw, created_by) values (trim(p_title), trim(p_body_en), nullif(trim(coalesce(p_body_sw, '')), ''), a.id) returning id into rid;
  else
    update cq_support_canned set title = trim(p_title), body_en = trim(p_body_en), body_sw = nullif(trim(coalesce(p_body_sw, '')), '') where id = p_id returning id into rid;
    if rid is null then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  end if;
  perform cq_log(a, 'canned_save', jsonb_build_object('id', rid));
  return jsonb_build_object('ok', true, 'id', rid);
end $$;

create or replace function cq_hq_canned_delete(p_token text, p_id uuid) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts;
begin
  a := cq_staff(p_token, array['support','beta_operator','product_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  delete from cq_support_canned where id = p_id;
  perform cq_log(a, 'canned_delete', jsonb_build_object('id', p_id));
  return jsonb_build_object('ok', true);
end $$;

-- 5. Beta operations dashboard -------------------------------------------------------------------------------
create or replace function cq_hq_beta_overview(p_token text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts;
begin
  a := cq_staff(p_token, array['beta_operator','support','product_manager','analyst','release_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  return jsonb_build_object('ok', true,
    'applications', (select jsonb_build_object('pending', count(*) filter (where status = 'pending'), 'approved', count(*) filter (where status = 'approved'),
                       'rejected', count(*) filter (where status = 'rejected'),
                       'oldest_pending_at', min(created_at) filter (where status = 'pending'),
                       'median_decision_hours', round((percentile_cont(0.5) within group (order by extract(epoch from reviewed_at - created_at) / 3600)
                                                      filter (where reviewed_at is not null))::numeric, 1))
                     from cq_beta_applications),
    'invites', (select jsonb_build_object('issued', count(*), 'redeemed', count(*) filter (where used_at is not null),
                  'expired_unused', count(*) filter (where used_at is null and expires_at <= now()),
                  'open', count(*) filter (where used_at is null and expires_at > now())) from cq_invites),
    'testers', (select jsonb_build_object('total', count(*), 'verified', count(*) filter (where status = 'verified'),
                  'suspended', count(*) filter (where status = 'suspended'), 'pending', count(*) filter (where status = 'pending'),
                  'active_7d', count(*) filter (where exists (select 1 from cq_usage_events e where e.account_id = c.id and e.ts > now() - interval '7 days')),
                  'never_opened', count(*) filter (where status = 'verified' and not exists (select 1 from cq_usage_events e where e.account_id = c.id)))
                from cq_accounts c where c.role = 'clinician'),
    'outcomes_30d', (select jsonb_build_object('followed', count(*) filter (where outcome = 'followed'), 'overruled', count(*) filter (where outcome = 'overruled'),
                       'doubt', count(*) filter (where outcome = 'doubt')) from cq_usage_events where ts > now() - interval '30 days'),
    'versions', (select coalesce(jsonb_agg(v order by v.devices desc), '[]'::jsonb) from (
        select app_version, count(distinct device_id) as devices, count(distinct account_id) as accounts from cq_usage_events
        where ts > now() - interval '30 days' and app_version is not null group by app_version) v),
    'by_cadre', (select coalesce(jsonb_agg(x order by x.n desc), '[]'::jsonb) from (select coalesce(cadre, 'unknown') as cadre, count(*) as n from cq_accounts where role = 'clinician' group by 1) x),
    'by_facility', (select coalesce(jsonb_agg(x order by x.n desc), '[]'::jsonb) from (select coalesce(facility, 'unknown') as facility, count(*) as n from cq_accounts where role = 'clinician' group by 1 order by 2 desc limit 10) x),
    'daily_14d', (select coalesce(jsonb_agg(d order by d.day), '[]'::jsonb) from (
        select (ts at time zone 'UTC')::date as day, count(distinct account_id) as accounts, count(*) as events from cq_usage_events
        where ts > now() - interval '14 days' group by 1) d),
    'support', (select jsonb_build_object('open', count(*) filter (where status = 'open'), 'pending', count(*) filter (where status = 'pending'),
                  'urgent', count(*) filter (where priority = 'urgent' and status <> 'resolved')) from cq_support_threads));
end $$;

create or replace function cq_hq_beta_testers(p_token text, p_search text default null, p_limit int default 200) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; full_pii boolean;
begin
  a := cq_staff(p_token, array['beta_operator','support','product_manager','analyst','release_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  full_pii := a.role in ('master','beta_operator','support');
  return jsonb_build_object('ok', true, 'testers', (
    select coalesce(jsonb_agg(to_jsonb(x) order by x.last_event_at desc nulls last, x.created_at desc), '[]'::jsonb) from (
      select c.id, c.name, case when full_pii then c.email else cq_mask_email(c.email) end as email, c.facility, c.cadre, c.status, c.created_at, c.last_login,
             u.last_event_at, u.app_version, coalesce(u.devices, 0) as devices, coalesce(u.events_7d, 0) as events_7d, coalesce(u.events_total, 0) as events_total,
             coalesce(u.followed, 0) as followed, coalesce(u.overruled, 0) as overruled, coalesce(u.doubt, 0) as doubt, coalesce(u.tamper, 0) as tamper_events,
             (select count(*) from cq_support_threads t where t.account_id = c.id and t.status <> 'resolved') as open_tickets
      from cq_accounts c
      left join lateral (
        select max(e.ts) as last_event_at, (array_agg(e.app_version order by e.ts desc) filter (where e.app_version is not null))[1] as app_version,
               count(distinct e.device_id) as devices, count(*) filter (where e.ts > now() - interval '7 days') as events_7d, count(*) as events_total,
               count(*) filter (where e.outcome = 'followed') as followed, count(*) filter (where e.outcome = 'overruled') as overruled, count(*) filter (where e.outcome = 'doubt') as doubt,
               count(*) filter (where e.feature in ('tamper','integrity') or e.action ilike '%tamper%') as tamper
        from cq_usage_events e where e.account_id = c.id) u on true
      where c.role = 'clinician'
        and (p_search is null or p_search = '' or c.name ilike '%' || p_search || '%' or c.email ilike '%' || p_search || '%' or c.facility ilike '%' || p_search || '%')
      order by u.last_event_at desc nulls last, c.created_at desc
      limit least(greatest(p_limit, 1), 500)) x));
end $$;

create or replace function cq_hq_beta_tester_detail(p_token text, p_account_id uuid) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; c cq_accounts; full_pii boolean; app cq_beta_applications;
begin
  a := cq_staff(p_token, array['beta_operator','support','product_manager','analyst','release_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  full_pii := a.role in ('master','beta_operator','support');
  select * into c from cq_accounts where id = p_account_id and role = 'clinician';
  if not found then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  select * into app from cq_beta_applications where lower(email) = lower(c.email) order by created_at desc limit 1;
  return jsonb_build_object('ok', true,
    'account', jsonb_build_object('id', c.id, 'name', c.name, 'email', case when full_pii then c.email else cq_mask_email(c.email) end,
       'facility', c.facility, 'cadre', c.cadre, 'status', c.status, 'created_at', c.created_at, 'last_login', c.last_login),
    'application', case when app.id is null then null else jsonb_build_object('ref_code', app.ref_code, 'mct_number', case when full_pii then app.mct_number else null end,
       'department', app.department, 'submitted_at', app.created_at, 'reviewed_at', app.reviewed_at) end,
    'devices', (select coalesce(jsonb_agg(d order by d.last_seen desc), '[]'::jsonb) from (
        select device_id, (array_agg(app_version order by ts desc))[1] as app_version, min(ts) as first_seen, max(ts) as last_seen, count(*) as events
        from cq_usage_events where account_id = c.id and device_id is not null group by device_id) d),
    'recent_events', (select coalesce(jsonb_agg(e order by e.ts desc), '[]'::jsonb) from (
        select ts, feature, action, rule_id, outcome, app_version from cq_usage_events where account_id = c.id order by ts desc limit 60) e),
    'tamper_events', (select coalesce(jsonb_agg(e order by e.ts desc), '[]'::jsonb) from (
        select ts, feature, action, device_id, app_version from cq_usage_events
        where account_id = c.id and (feature in ('tamper','integrity') or action ilike '%tamper%') order by ts desc limit 20) e),
    'threads', (select coalesce(jsonb_agg(t order by t.last_message_at desc), '[]'::jsonb) from (
        select id, subject, status, priority, last_message_at from cq_support_threads where account_id = c.id order by last_message_at desc limit 20) t));
end $$;

create or replace function cq_hq_tester_set_status(p_token text, p_account_id uuid, p_status text, p_reason text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; c cq_accounts; n int;
begin
  a := cq_staff(p_token, array['beta_operator','product_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  if p_status not in ('verified','suspended') then return jsonb_build_object('ok', false, 'error', 'bad_value'); end if;
  if char_length(trim(coalesce(p_reason, ''))) < 5 then return jsonb_build_object('ok', false, 'error', 'reason_required'); end if;
  select * into c from cq_accounts where id = p_account_id;
  if not found or c.role <> 'clinician' then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  update cq_accounts set status = p_status where id = c.id;
  if p_status = 'suspended' then delete from cq_sessions where account_id = c.id; end if;   -- ends access immediately
  perform cq_log(a, 'tester_' || p_status, jsonb_build_object('account_id', c.id, 'reason', trim(p_reason)));
  return jsonb_build_object('ok', true);
end $$;

create or replace function cq_hq_beta_invites(p_token text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; full_pii boolean;
begin
  a := cq_staff(p_token, array['beta_operator','support','product_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  full_pii := a.role in ('master','beta_operator','support');
  return jsonb_build_object('ok', true, 'invites', (
    select coalesce(jsonb_agg(x order by x.created_at desc), '[]'::jsonb) from (
      select i.id, case when full_pii then i.email else cq_mask_email(i.email) end as email, i.created_at, i.expires_at, i.used_at,
             case when i.used_at is not null then 'redeemed' when i.expires_at <= now() then 'expired' else 'open' end as state,
             (select ap.ref_code from cq_beta_applications ap where lower(ap.email) = lower(i.email) order by ap.created_at desc limit 1) as ref_code
      from cq_invites i where i.role = 'clinician' order by i.created_at desc limit 500) x));
end $$;

create or replace function cq_hq_invite_action(p_token text, p_invite_id uuid, p_action text, p_days int default 14, p_reason text default null) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; i cq_invites;
begin
  a := cq_staff(p_token, array['beta_operator']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  select * into i from cq_invites where id = p_invite_id and role = 'clinician';
  if not found then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  if i.used_at is not null then return jsonb_build_object('ok', false, 'error', 'already_redeemed'); end if;
  if p_action = 'revoke' then
    if char_length(trim(coalesce(p_reason, ''))) < 5 then return jsonb_build_object('ok', false, 'error', 'reason_required'); end if;
    update cq_invites set expires_at = now() - interval '1 second' where id = i.id;
    update cq_beta_applications set otp_key = null where lower(email) = lower(i.email) and otp_key is not null;   -- do not keep a dead key readable
  elsif p_action = 'extend' then
    if p_days is null or p_days < 1 or p_days > 60 then return jsonb_build_object('ok', false, 'error', 'bad_value'); end if;
    update cq_invites set expires_at = greatest(expires_at, now()) + make_interval(days => p_days) where id = i.id;
  else
    return jsonb_build_object('ok', false, 'error', 'bad_value');
  end if;
  perform cq_log(a, 'invite_' || p_action, jsonb_build_object('invite_id', i.id, 'days', p_days, 'reason', p_reason));
  return jsonb_build_object('ok', true);
end $$;

-- Raw invite keys stay readable on the application row after issue so the operator can copy them. This clears
-- them once the invite is redeemed or expired. Call it from HQ, or schedule it with pg_cron.
create or replace function cq_hq_scrub_keys(p_token text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; n int;
begin
  a := cq_staff(p_token, array['beta_operator','security']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  update cq_beta_applications ap set otp_key = null
  where ap.otp_key is not null and exists (select 1 from cq_invites i where lower(i.email) = lower(ap.email) and (i.used_at is not null or i.expires_at <= now()))
    and not exists (select 1 from cq_invites i2 where lower(i2.email) = lower(ap.email) and i2.used_at is null and i2.expires_at > now());
  get diagnostics n = row_count;
  perform cq_log(a, 'scrub_keys', jsonb_build_object('cleared', n));
  return jsonb_build_object('ok', true, 'cleared', n);
end $$;

-- 6. Device fleet -------------------------------------------------------------------------------------------
-- Built only from usage events the app already sends (device_id, app_version, ts). A device that has never sent an
-- event does not appear. Tamper events are read from events whose feature is 'tamper' or 'integrity', or whose action
-- contains 'tamper': confirm the exact names Nia emits from a real device export.
create or replace function cq_hq_fleet(p_token text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; grace int; minv text;
begin
  a := cq_staff(p_token, array['network_maint','release_manager','analyst','security','product_manager','beta_operator']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  select offline_grace_days, min_app_version into grace, minv from cq_release_config where version = '*';
  grace := coalesce(grace, 30);
  return jsonb_build_object('ok', true, 'grace_days', grace, 'min_app_version', minv,
    'devices', (select coalesce(jsonb_agg(to_jsonb(d) order by d.last_seen desc), '[]'::jsonb) from (
        select e.device_id, (array_agg(e.app_version order by e.ts desc) filter (where e.app_version is not null))[1] as app_version,
               min(e.ts) as first_seen, max(e.ts) as last_seen, count(*) filter (where e.ts > now() - interval '30 days') as events_30d,
               count(distinct e.account_id) as accounts, (array_agg(c.facility order by e.ts desc))[1] as facility,
               extract(day from now() - max(e.ts))::int >= grace as stale,
               extract(day from now() - max(e.ts))::int as days_since
        from cq_usage_events e left join cq_accounts c on c.id = e.account_id where e.device_id is not null group by e.device_id
        order by max(e.ts) desc limit 500) d),
    'adoption', (select coalesce(jsonb_agg(x order by x.devices desc), '[]'::jsonb) from (
        select v as app_version, count(*) as devices from (
          select (array_agg(app_version order by ts desc) filter (where app_version is not null))[1] as v from cq_usage_events where device_id is not null group by device_id) t
        where v is not null group by v) x),
    'below_min', case when minv is null then null else (select count(*) from (
          select (array_agg(app_version order by ts desc) filter (where app_version is not null))[1] as v from cq_usage_events where device_id is not null group by device_id) t
          where v is not null and cq_ver_num(v) < cq_ver_num(minv)) end,
    'tamper_30d', (select coalesce(jsonb_agg(t order by t.ts desc), '[]'::jsonb) from (
        select ts, device_id, app_version, feature, action from cq_usage_events
        where ts > now() - interval '30 days' and (feature in ('tamper','integrity') or action ilike '%tamper%') order by ts desc limit 50) t),
    'daily_14d', (select coalesce(jsonb_agg(d order by d.day), '[]'::jsonb) from (
        select (ts at time zone 'UTC')::date as day, count(distinct device_id) as devices, count(*) as events from cq_usage_events
        where ts > now() - interval '14 days' group by 1) d));
end $$;

-- 7. Audit search and chain verification ------------------------------------------------------------------
create or replace function cq_hq_audit_search(p_token text, p_action text default null, p_actor text default null, p_since timestamptz default null, p_limit int default 100, p_offset int default 0) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; total bigint;
begin
  a := cq_staff(p_token, array['security']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  select count(*) into total from cq_audit au left join cq_accounts ac on ac.id = au.actor
    where (p_action is null or au.action = p_action) and (p_actor is null or p_actor = '' or ac.email ilike '%' || p_actor || '%') and (p_since is null or au.at >= p_since);
  return jsonb_build_object('ok', true, 'total', total,
    'actions', (select coalesce(jsonb_agg(distinct action order by action), '[]'::jsonb) from cq_audit where action is not null),
    'rows', (select coalesce(jsonb_agg(to_jsonb(x) order by x.id desc), '[]'::jsonb) from (
      select au.id, au.at, au.action, au.role, ac.email as actor_email, au.detail, au.row_hash
      from cq_audit au left join cq_accounts ac on ac.id = au.actor
      where (p_action is null or au.action = p_action) and (p_actor is null or p_actor = '' or ac.email ilike '%' || p_actor || '%') and (p_since is null or au.at >= p_since)
      order by au.id desc limit least(greatest(p_limit, 1), 500) offset greatest(p_offset, 0)) x));
end $$;

-- Checks (a) every row points at the previous row's hash (a deleted or inserted row breaks this) and
-- (b) every stored hash matches a recomputation. (b) depends on the database time zone setting being the same as
-- when the row was written, so a (b)-only failure is reported separately from a (a) failure.
create or replace function cq_hq_audit_verify(p_token text, p_limit int default 5000) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; link_breaks bigint[]; hash_mismatch bigint[]; n int;
begin
  a := cq_staff(p_token, array['security']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  with r as (select id, actor, action, detail, at, prev_hash, row_hash, lag(row_hash) over (order by id) as expect_prev
             from (select * from cq_audit where row_hash is not null order by id desc limit least(greatest(p_limit, 10), 20000)) s)
  select count(*),
         coalesce(array_agg(id) filter (where expect_prev is not null and prev_hash is distinct from expect_prev), '{}'),
         coalesce(array_agg(id) filter (where row_hash <> encode(digest(coalesce(prev_hash,'') || id::text || coalesce(actor::text,'') || coalesce(action,'') || coalesce(detail::text,'') || at::text, 'sha256'), 'hex')), '{}')
    into n, link_breaks, hash_mismatch from r;
  perform cq_log(a, 'audit_verify', jsonb_build_object('checked', n, 'link_breaks', coalesce(array_length(link_breaks, 1), 0), 'hash_mismatch', coalesce(array_length(hash_mismatch, 1), 0)));
  return jsonb_build_object('ok', true, 'checked', n, 'chain_intact', coalesce(array_length(link_breaks, 1), 0) = 0,
    'link_breaks', to_jsonb(link_breaks), 'hash_mismatches', to_jsonb(hash_mismatch));
end $$;

-- 8. Grants (token-checked RPCs, same pattern as 0001-0005) -----------------------------------------------
grant execute on function
  cq_support_open(text, text, text, text, text, text), cq_support_send(text, uuid, text), cq_support_my_threads(text), cq_support_thread(text, uuid),
  cq_hq_support_list(text, text), cq_hq_support_thread(text, uuid), cq_hq_support_reply(text, uuid, text), cq_hq_support_update(text, uuid, jsonb),
  cq_hq_support_redact(text, bigint), cq_hq_canned_list(text), cq_hq_canned_save(text, uuid, text, text, text), cq_hq_canned_delete(text, uuid),
  cq_hq_beta_overview(text), cq_hq_beta_testers(text, text, int), cq_hq_beta_tester_detail(text, uuid), cq_hq_tester_set_status(text, uuid, text, text),
  cq_hq_beta_invites(text), cq_hq_invite_action(text, uuid, text, int, text), cq_hq_scrub_keys(text), cq_hq_fleet(text),
  cq_hq_audit_search(text, text, text, timestamptz, int, int), cq_hq_audit_verify(text, int)
  to anon, authenticated;

commit;
