-- smoke_0007.sql: behaviour test for 0007 on a scratch PostgreSQL (NOT for production data).
-- Needs roles anon/authenticated and migrations 0001-0007. Creates test rows with a 'zz_' prefix, then removes them.
\set ON_ERROR_STOP on
create or replace function zz_assert(c boolean, msg text) returns void language plpgsql as $$
begin if c is not true then raise exception 'ASSERT FAILED: %', msg; end if; end $$;
grant execute on function zz_assert(boolean, text) to anon;
create or replace function zz_id(e text) returns uuid language sql security definer as $$ select id from cq_accounts where email = e $$;
grant execute on function zz_id(text) to anon;

-- clean any leftovers from an aborted earlier run
delete from cq_support_threads where account_id in (select id from cq_accounts where email like 'zz\_%');
delete from cq_usage_events where device_id like 'zz\_%';
delete from cq_beta_applications where ref_code = 'CQ-BETA-ZZ0001';
delete from cq_invites where email like 'zz\_%';
delete from cq_rate_limit where k like 'sup:%';

-- seed (as owner) -----------------------------------------------------------------------------------------
insert into cq_accounts(email, pw_hash, role, name, facility, cadre) values
 ('zz_master@t.test','x','master','ZZ Master',null,null),
 ('zz_bo@t.test','x','beta_operator','ZZ BetaOp',null,null),
 ('zz_sup@t.test','x','support','ZZ Support',null,null),
 ('zz_an@t.test','x','analyst','ZZ Analyst',null,null),
 ('zz_sec@t.test','x','security','ZZ Security',null,null),
 ('zz_c1@t.test','x','clinician','ZZ Clin One','Facility A','Clinical Officer'),
 ('zz_c2@t.test','x','clinician','ZZ Clin Two','Facility B','Nurse')
on conflict (email) do update set status='verified';
insert into cq_sessions(token_hash, account_id)
 select encode(digest('tok_' || split_part(email,'@',1),'sha256'),'hex'), id from cq_accounts where email like 'zz\_%'
 on conflict (token_hash) do update set expires_at = now() + interval '1 day';
insert into cq_usage_events(account_id, device_id, app_version, ts, feature, action, rule_id, outcome)
 select id, 'zz_dev1', '1.47.2', now() - interval '1 day', 'clerk', 'rule_shown', 'R1', 'followed' from cq_accounts where email='zz_c1@t.test';
insert into cq_usage_events(account_id, device_id, app_version, ts, feature, action, rule_id, outcome)
 select id, 'zz_dev1', '1.47.2', now() - interval '2 hours', 'clerk', 'rule_shown', 'R2', 'overruled' from cq_accounts where email='zz_c1@t.test';
insert into cq_usage_events(account_id, device_id, app_version, ts, feature, action)
 select id, 'zz_dev1', '1.47.2', now() - interval '1 hour', 'integrity', 'clock_rollback' from cq_accounts where email='zz_c1@t.test';
insert into cq_usage_events(account_id, device_id, app_version, ts, feature, action)
 select id, 'zz_dev2', '1.30.0', now() - interval '45 days', 'clerk', 'open' from cq_accounts where email='zz_c2@t.test';
insert into cq_beta_applications(ref_code, name, email, cadre, facility, status, reviewed_at, otp_key)
 values ('CQ-BETA-ZZ0001','ZZ Clin One','zz_c1@t.test','Clinical Officer','Facility A','approved', now(), 'zzrawkey1');
insert into cq_invites(email, key_hash, used_at) values ('zz_c1@t.test','h1', now());

set role anon;
-- grants: internal helpers are not callable by anon -------------------------------------------------------
do $$ begin
  begin perform cq_log(null::cq_accounts, 'forged', '{}'::jsonb); raise exception 'cq_log callable by anon';
  exception when insufficient_privilege then null; end;
  begin perform cq_rl('x', 1, interval '1 hour'); raise exception 'cq_rl callable by anon';
  exception when insufficient_privilege then null; end;
  begin perform cq_staff('tok_zz_master', array['support']); raise exception 'cq_staff callable by anon';
  exception when insufficient_privilege then null; end;
end $$;

-- authorization ---------------------------------------------------------------------------------------------
select zz_assert(cq_hq_beta_overview('nope')->>'error' = 'forbidden', 'bad token is forbidden');
select zz_assert(cq_hq_beta_overview('tok_zz_c1')->>'error' = 'forbidden', 'clinician cannot read beta overview');
select zz_assert(cq_hq_audit_search('tok_zz_sup')->>'error' = 'forbidden', 'support cannot read audit');
select zz_assert(cq_hq_fleet('tok_zz_sup')->>'error' = 'forbidden', 'support cannot read fleet');
select zz_assert((cq_hq_beta_overview('tok_zz_bo')->>'ok')::boolean, 'beta operator reads overview');

-- dashboard numbers come from real rows ---------------------------------------------------------------------
select zz_assert((cq_hq_beta_overview('tok_zz_an')->'testers'->>'total')::int >= 2, 'testers counted');
select zz_assert((cq_hq_beta_overview('tok_zz_an')->'outcomes_30d'->>'followed')::int >= 1, 'outcomes counted');
select zz_assert((select count(*) from jsonb_array_elements(cq_hq_beta_testers('tok_zz_bo','ZZ Clin One')->'testers')) = 1, 'search narrows testers');
select zz_assert((cq_hq_beta_testers('tok_zz_bo','ZZ Clin One')->'testers'->0->>'tamper_events')::int = 1, 'tamper event counted');
select zz_assert((cq_hq_beta_testers('tok_zz_bo','ZZ Clin One')->'testers'->0->>'devices')::int = 1, 'device counted');
-- masking: analyst sees masked email, beta operator sees full
select zz_assert(cq_hq_beta_testers('tok_zz_an','ZZ Clin One')->'testers'->0->>'email' like 'z%*%@t.test', 'analyst sees masked email');
select zz_assert(cq_hq_beta_testers('tok_zz_bo','ZZ Clin One')->'testers'->0->>'email' = 'zz_c1@t.test', 'beta operator sees email');

-- fleet ------------------------------------------------------------------------------------------------------
select zz_assert((select bool_or((d->>'stale')::boolean) from jsonb_array_elements(cq_hq_fleet('tok_zz_an')->'devices') d where d->>'device_id' = 'zz_dev2'), 'old device is stale');
select zz_assert((select not bool_or((d->>'stale')::boolean) from jsonb_array_elements(cq_hq_fleet('tok_zz_an')->'devices') d where d->>'device_id' = 'zz_dev1'), 'recent device is not stale');
select zz_assert(jsonb_array_length(cq_hq_fleet('tok_zz_an')->'tamper_30d') >= 1, 'tamper feed lists the integrity event');

-- support: clinician -> staff -> clinician -------------------------------------------------------------------
create temp table zz_t(id uuid);
insert into zz_t select (cq_support_open('tok_zz_c1', 'Model download stalled', 'model_download', 'Stuck at 64 percent', 'zz_dev1', '1.47.2')->>'thread_id')::uuid;
select zz_assert((select count(*) from zz_t where id is not null) = 1, 'thread opened');
select zz_assert(cq_support_open('tok_zz_c1', 'x', 'other', 'hi')->>'error' = 'bad_subject', 'short subject rejected');
select zz_assert(cq_support_thread('tok_zz_c2', (select id from zz_t))->>'error' = 'not_found', 'other clinician cannot read the thread');
select zz_assert(cq_support_send('tok_zz_c2', (select id from zz_t), 'hi')->>'error' = 'not_found', 'other clinician cannot post to the thread');
select zz_assert((cq_hq_support_list('tok_zz_sup')->'counts'->>'open')::int >= 1, 'staff sees open thread');
select zz_assert((cq_hq_support_reply('tok_zz_sup', (select id from zz_t), 'Tap Retry on the Setup screen.')->>'ok')::boolean, 'staff reply');
select zz_assert((select (t->>'unread')::boolean from jsonb_array_elements(cq_support_my_threads('tok_zz_c1')->'threads') t limit 1), 'clinician sees unread reply');
select zz_assert(jsonb_array_length(cq_support_thread('tok_zz_c1', (select id from zz_t))->'messages') = 2, 'clinician reads 2 messages');
select zz_assert(not (select (t->>'unread')::boolean from jsonb_array_elements(cq_support_my_threads('tok_zz_c1')->'threads') t limit 1), 'reading clears unread');
select zz_assert((cq_support_send('tok_zz_c1', (select id from zz_t), 'Worked, thanks')->>'ok')::boolean, 'clinician follow-up');
select zz_assert((cq_hq_support_thread('tok_zz_sup', (select id from zz_t))->'thread'->>'status') = 'open', 'follow-up reopens thread');
select zz_assert((cq_hq_support_update('tok_zz_sup', (select id from zz_t), '{"status":"resolved","priority":"high"}')->>'ok')::boolean, 'staff resolves');
select zz_assert(cq_hq_support_update('tok_zz_sup', (select id from zz_t), '{"status":"bogus"}')->>'error' = 'bad_value', 'bad status rejected');
select zz_assert(cq_hq_support_update('tok_zz_sup', (select id from zz_t), '{"role":"master"}')->>'error' = 'bad_key', 'unknown key rejected');
select zz_assert((cq_hq_support_redact('tok_zz_sup', (select (m->>'id')::bigint from jsonb_array_elements(cq_hq_support_thread('tok_zz_sup', (select id from zz_t))->'messages') m order by (m->>'id')::bigint desc limit 1))->>'ok')::boolean, 'redact message');
select zz_assert(cq_hq_support_reply('tok_zz_c1', (select id from zz_t), 'x')->>'error' = 'forbidden', 'clinician cannot use staff reply');

-- tester + invite management ---------------------------------------------------------------------------------
select zz_assert(cq_hq_tester_set_status('tok_zz_bo', zz_id('zz_c2@t.test'), 'suspended', 'no')->>'error' = 'reason_required', 'reason required');
select zz_assert(cq_hq_tester_set_status('tok_zz_sup', zz_id('zz_c2@t.test'), 'suspended', 'device cloned')->>'error' = 'forbidden', 'support cannot suspend');
select zz_assert(cq_hq_tester_set_status('tok_zz_bo', zz_id('zz_bo@t.test'), 'suspended', 'should not work')->>'error' = 'not_found', 'cannot suspend staff');
select zz_assert((cq_hq_tester_set_status('tok_zz_bo', zz_id('zz_c2@t.test'), 'suspended', 'device cloned')->>'ok')::boolean, 'suspend tester');
select zz_assert(cq_support_my_threads('tok_zz_c2')->>'error' = 'unauthorized', 'suspended tester session is dead');
select zz_assert((cq_hq_scrub_keys('tok_zz_bo')->>'cleared')::int >= 1, 'scrub clears redeemed key');

-- audit ------------------------------------------------------------------------------------------------------
select zz_assert((cq_hq_audit_search('tok_zz_sec', 'support_reply')->>'total')::int >= 1, 'audit search by action');
select zz_assert((cq_hq_audit_search('tok_zz_sec', null, 'zz_sup')->>'total')::int >= 1, 'audit search by actor');
select zz_assert((cq_hq_audit_verify('tok_zz_sec')->>'chain_intact')::boolean, 'audit chain intact');
select zz_assert(jsonb_array_length(cq_hq_audit_verify('tok_zz_sec')->'hash_mismatches') = 0, 'audit hashes recompute');

-- rate limit -------------------------------------------------------------------------------------------------
do $$ declare i int; r jsonb; begin
  for i in 1..6 loop r := cq_support_open('tok_zz_c1', 'Rate limit probe ' || i, 'other', 'x'); end loop;
  if r->>'error' is distinct from 'rate_limited' then raise exception 'ASSERT FAILED: open not rate limited (%)', r; end if;
end $$;

reset role;
-- audit is append-only
do $$ begin
  begin delete from cq_audit where action = 'support_reply'; raise exception 'ASSERT FAILED: audit delete allowed';
  exception when raise_exception then if sqlerrm like 'ASSERT%' then raise; end if; end;
end $$;
-- cleanup (the zz_ accounts stay: staff rows are referenced by the append-only audit log; scratch DB only)
delete from cq_support_threads where account_id in (select id from cq_accounts where email like 'zz\_%');
delete from cq_usage_events where device_id like 'zz\_%';
delete from cq_beta_applications where ref_code = 'CQ-BETA-ZZ0001';
delete from cq_invites where email like 'zz\_%';
delete from cq_rate_limit where k like 'sup:%';
update cq_accounts set status='verified' where email like 'zz\_%';
drop function zz_assert(boolean, text);
drop function zz_id(text);
\echo ALL 0007 SMOKE TESTS PASSED
