import React, { useCallback, useState } from 'react';

export const card: React.CSSProperties = { background: 'var(--bg-surface)', border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-md)', padding: 16 };
export const field: React.CSSProperties = {
  width: '100%', padding: '8px 10px', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-sm)',
  background: 'var(--bg-surface)', color: 'var(--text-primary)', fontSize: 13, boxSizing: 'border-box',
};
export const cap: React.CSSProperties = { fontSize: 12, color: 'var(--text-muted)', margin: '10px 0 4px', display: 'block' };
export const th: React.CSSProperties = { padding: '8px 10px', fontSize: 12, fontWeight: 600, color: 'var(--text-muted)', borderBottom: '1px solid var(--border-subtle)', textAlign: 'left', whiteSpace: 'nowrap' };
export const td: React.CSSProperties = { padding: '9px 10px', fontSize: 13, borderBottom: '1px solid var(--border-subtle)', verticalAlign: 'top' };

export const ago = (iso: string | null | undefined): string => {
  if (!iso) return 'never';
  const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 90) return 'just now';
  if (s < 5400) return `${Math.round(s / 60)} min ago`;
  if (s < 129600) return `${Math.round(s / 3600)} h ago`;
  return `${Math.round(s / 86400)} d ago`;
};
export const when = (iso: string | null | undefined) => (iso ? new Date(iso).toLocaleString() : 'never');
export const label = (t: string) => t.replace(/_/g, ' ');

export type Msg = { kind: 'ok' | 'err'; text: string } | null;

/** Runs an async action with a busy flag and an ok/error banner message. */
export function useRun() {
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<Msg>(null);
  const run = useCallback(async (fn: () => Promise<unknown>, ok?: string) => {
    setBusy(true);
    try { await fn(); if (ok) setMsg({ kind: 'ok', text: ok }); else setMsg(null); return true; }
    catch (e) { setMsg({ kind: 'err', text: e instanceof Error ? e.message : 'Request failed' }); return false; }
    finally { setBusy(false); }
  }, []);
  return { busy, msg, setMsg, run };
}

export const Banner: React.FC<{ msg: Msg }> = ({ msg }) => msg ? (
  <div role="status" style={{ ...card, padding: '10px 14px', fontSize: 13,
    borderColor: msg.kind === 'err' ? 'var(--danger-border)' : 'var(--border-default)',
    background: msg.kind === 'err' ? 'var(--danger-bg)' : 'var(--success-bg)' }}>{msg.text}</div>
) : null;

export const Empty: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <p style={{ fontSize: 13, color: 'var(--text-muted)', padding: '14px 4px' }}>{children}</p>
);

/** Tiny dependency-free bar row chart. Values are real counts; an all-zero series says so. */
export const Bars: React.FC<{ rows: Array<{ k: string; v: number }>; empty: string }> = ({ rows, empty }) => {
  const max = Math.max(0, ...rows.map(r => r.v));
  if (rows.length === 0 || max === 0) return <Empty>{empty}</Empty>;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      {rows.map(r => (
        <div key={r.k} style={{ display: 'grid', gridTemplateColumns: '120px 1fr 44px', alignItems: 'center', gap: 8, fontSize: 12 }}>
          <span style={{ color: 'var(--text-secondary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={r.k}>{r.k}</span>
          <span style={{ background: 'var(--bg-surface-hover)', borderRadius: 4, height: 10 }}>
            <span style={{ display: 'block', width: `${(r.v / max) * 100}%`, height: '100%', borderRadius: 4, background: 'var(--text-primary)' }} />
          </span>
          <span style={{ textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>{r.v}</span>
        </div>
      ))}
    </div>
  );
};
