import { supabase } from './supabase';

const MESSAGES: Record<string, string> = {
  forbidden: 'Your role cannot do this.',
  not_found: 'Not found.',
  bad_value: 'Invalid value.',
  bad_key: 'Unknown setting.',
  bad_body: 'Write a message of 1 to 2000 characters.',
  reason_required: 'A reason of at least 5 characters is required.',
  already_redeemed: 'This invite has already been redeemed.',
  rate_limited: 'Too many requests. Try again later.',
  unauthorized: 'Your session has ended. Sign in again.',
};
export class OpsError extends Error {
  code: string;
  constructor(code: string) { super(MESSAGES[code] ?? `Request failed (${code})`); this.code = code; }
}
async function call<T>(fn: string, args: Record<string, unknown>): Promise<T> {
  const { data, error } = await supabase.rpc(fn, args);
  if (error) throw new Error(error.message);
  if (!data || data.ok !== true) throw new OpsError(String(data?.error ?? 'unknown'));
  return data as T;
}

// ---- Beta operations -------------------------------------------------------------------------------------
export interface BetaOverview {
  applications: { pending: number; approved: number; rejected: number; oldest_pending_at: string | null; median_decision_hours: number | null };
  invites: { issued: number; redeemed: number; expired_unused: number; open: number };
  testers: { total: number; verified: number; suspended: number; pending: number; active_7d: number; never_opened: number };
  outcomes_30d: { followed: number; overruled: number; doubt: number };
  versions: Array<{ app_version: string; devices: number; accounts: number }>;
  by_cadre: Array<{ cadre: string; n: number }>;
  by_facility: Array<{ facility: string; n: number }>;
  daily_14d: Array<{ day: string; accounts: number; events: number }>;
  support: { open: number; pending: number; urgent: number };
}
export interface Tester {
  id: string; name: string | null; email: string; facility: string | null; cadre: string | null; status: 'pending' | 'verified' | 'suspended';
  created_at: string; last_login: string | null; last_event_at: string | null; app_version: string | null; devices: number;
  events_7d: number; events_total: number; followed: number; overruled: number; doubt: number; tamper_events: number; open_tickets: number;
}
export interface TesterDetail {
  account: { id: string; name: string | null; email: string; facility: string | null; cadre: string | null; status: string; created_at: string; last_login: string | null };
  application: null | { ref_code: string; mct_number: string | null; department: string | null; submitted_at: string; reviewed_at: string | null };
  devices: Array<{ device_id: string; app_version: string | null; first_seen: string; last_seen: string; events: number }>;
  recent_events: Array<{ ts: string; feature: string; action: string | null; rule_id: string | null; outcome: string | null; app_version: string | null }>;
  tamper_events: Array<{ ts: string; feature: string; action: string | null; device_id: string | null; app_version: string | null }>;
  threads: Array<{ id: string; subject: string; status: string; priority: string; last_message_at: string }>;
}
export interface InviteRow { id: string; email: string; created_at: string; expires_at: string; used_at: string | null; state: 'open' | 'redeemed' | 'expired'; ref_code: string | null }

export const betaOverview = (t: string) => call<{ ok: true } & BetaOverview>('cq_hq_beta_overview', { p_token: t });
export const listTesters = async (t: string, search?: string) =>
  (await call<{ testers: Tester[] }>('cq_hq_beta_testers', { p_token: t, p_search: search || null, p_limit: 200 })).testers;
export const testerDetail = (t: string, id: string) => call<{ ok: true } & TesterDetail>('cq_hq_beta_tester_detail', { p_token: t, p_account_id: id });
export const setTesterStatus = async (t: string, id: string, status: 'verified' | 'suspended', reason: string) => {
  await call('cq_hq_tester_set_status', { p_token: t, p_account_id: id, p_status: status, p_reason: reason });
};
export const listInvites = async (t: string) => (await call<{ invites: InviteRow[] }>('cq_hq_beta_invites', { p_token: t })).invites;
export const inviteAction = async (t: string, id: string, action: 'revoke' | 'extend', days: number, reason: string | null) => {
  await call('cq_hq_invite_action', { p_token: t, p_invite_id: id, p_action: action, p_days: days, p_reason: reason });
};
export const scrubKeys = async (t: string) => (await call<{ cleared: number }>('cq_hq_scrub_keys', { p_token: t })).cleared;

// ---- Support desk -----------------------------------------------------------------------------------------
export type ThreadStatus = 'open' | 'pending' | 'resolved';
export type Priority = 'low' | 'normal' | 'high' | 'urgent';
export interface ThreadRow {
  id: string; subject: string; category: string; status: ThreadStatus; priority: Priority; last_message_at: string; last_sender: 'clinician' | 'staff';
  created_at: string; app_version: string | null; assigned_to: string | null; assigned_name: string | null;
  clinician_name: string | null; facility: string | null; cadre: string | null; clinician_email: string; messages: number;
}
export interface SupportMessage { id: number; from: 'clinician' | 'staff'; body: string; redacted: boolean; at: string; sender: string | null }
export interface ThreadDetail {
  thread: { id: string; subject: string; category: string; status: ThreadStatus; priority: Priority; assigned_to: string | null; device_id: string | null; app_version: string | null; created_at: string };
  clinician: { account_id: string; name: string | null; facility: string | null; cadre: string | null; status: string; email: string; last_login: string | null };
  messages: SupportMessage[];
}
export interface Canned { id: string; title: string; body_en: string; body_sw: string | null }

export const supportList = (t: string, status?: ThreadStatus) =>
  call<{ counts: { open: number; pending: number; resolved: number; urgent: number }; threads: ThreadRow[] }>('cq_hq_support_list', { p_token: t, p_status: status ?? null });
export const supportThread = (t: string, id: string) => call<{ ok: true } & ThreadDetail>('cq_hq_support_thread', { p_token: t, p_thread_id: id });
export const supportReply = async (t: string, id: string, body: string) => { await call('cq_hq_support_reply', { p_token: t, p_thread_id: id, p_body: body }); };
export const supportUpdate = async (t: string, id: string, patch: Record<string, unknown>) => { await call('cq_hq_support_update', { p_token: t, p_thread_id: id, p_patch: patch }); };
export const supportRedact = async (t: string, messageId: number) => { await call('cq_hq_support_redact', { p_token: t, p_message_id: messageId }); };
export const cannedList = async (t: string) => (await call<{ replies: Canned[] }>('cq_hq_canned_list', { p_token: t })).replies;
export const cannedSave = async (t: string, id: string | null, title: string, en: string, sw: string) => {
  await call('cq_hq_canned_save', { p_token: t, p_id: id, p_title: title, p_body_en: en, p_body_sw: sw });
};
export const cannedDelete = async (t: string, id: string) => { await call('cq_hq_canned_delete', { p_token: t, p_id: id }); };

// ---- Fleet --------------------------------------------------------------------------------------------------
export interface FleetDevice { device_id: string; app_version: string | null; first_seen: string; last_seen: string; events_30d: number; accounts: number; facility: string | null; stale: boolean; days_since: number }
export interface Fleet {
  grace_days: number; min_app_version: string | null; below_min: number | null;
  devices: FleetDevice[]; adoption: Array<{ app_version: string; devices: number }>;
  tamper_30d: Array<{ ts: string; device_id: string | null; app_version: string | null; feature: string; action: string | null }>;
  daily_14d: Array<{ day: string; devices: number; events: number }>;
}
export const fleet = (t: string) => call<{ ok: true } & Fleet>('cq_hq_fleet', { p_token: t });

// ---- Audit --------------------------------------------------------------------------------------------------
export interface AuditRow { id: number; at: string; action: string | null; role: string | null; actor_email: string | null; detail: Record<string, unknown> | null; row_hash: string | null }
export const auditSearch = (t: string, f: { action?: string; actor?: string; since?: string; offset?: number }) =>
  call<{ total: number; actions: string[]; rows: AuditRow[] }>('cq_hq_audit_search', {
    p_token: t, p_action: f.action || null, p_actor: f.actor || null, p_since: f.since || null, p_limit: 100, p_offset: f.offset ?? 0 });
export const auditVerify = (t: string) =>
  call<{ checked: number; chain_intact: boolean; link_breaks: number[]; hash_mismatches: number[] }>('cq_hq_audit_verify', { p_token: t, p_limit: 5000 });
