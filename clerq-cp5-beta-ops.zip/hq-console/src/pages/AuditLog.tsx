import React, { useCallback, useEffect, useState } from 'react';
import { ScrollText, ShieldCheck, RefreshCw } from 'lucide-react';
import { useAuth } from '../lib/auth';
import * as O from '../lib/opsApi';
import { Banner, Empty, card, field, td, th, useRun, when } from '../components/ui';

export const AuditLog: React.FC = () => {
  const { token } = useAuth();
  const { busy, msg, setMsg, run } = useRun();
  const [action, setAction] = useState('');
  const [actor, setActor] = useState('');
  const [days, setDays] = useState('');
  const [offset, setOffset] = useState(0);
  const [data, setData] = useState<{ total: number; actions: string[]; rows: O.AuditRow[] } | null>(null);
  const [open, setOpen] = useState<number | null>(null);
  const [verdict, setVerdict] = useState<null | { checked: number; chain_intact: boolean; link_breaks: number[]; hash_mismatches: number[] }>(null);

  const load = useCallback(async () => {
    if (!token) return;
    const since = days ? new Date(Date.now() - Number(days) * 86400000).toISOString() : undefined;
    await run(async () => { setData(await O.auditSearch(token, { action, actor, since, offset })); });
  }, [token, action, actor, days, offset, run]);
  useEffect(() => { void load(); }, [load]);
  if (!token) return null;
  const t = token;

  const exportCsv = () => {
    if (!data) return;
    const q = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const lines = ['id,at,actor,role,action,detail,hash', ...data.rows.map(r => [r.id, r.at, r.actor_email, r.role, r.action, JSON.stringify(r.detail), r.row_hash].map(q).join(','))];
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([lines.join('\n')], { type: 'text/csv' }));
    a.download = `clerq-audit-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click(); URL.revokeObjectURL(a.href);
  };

  return (
    <div className="animate-fade-in" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}><ScrollText size={22} /><h1 style={{ fontSize: 24, fontWeight: 700, letterSpacing: '-0.02em' }}>Audit Log</h1></div>
          <p style={{ fontSize: 14, color: 'var(--text-secondary)', marginTop: 4 }}>Every staff action, in order. Rows cannot be edited or deleted, and each row carries a hash that links it to the one before.</p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn-secondary" disabled={busy} onClick={() => void run(async () => { setVerdict(await O.auditVerify(t)); })}><ShieldCheck size={14} /><span>Verify chain</span></button>
          <button className="btn-secondary" disabled={busy || !data} onClick={exportCsv}>Export this page (CSV)</button>
          <button className="btn-secondary" disabled={busy} onClick={() => { setVerdict(null); setMsg(null); void load(); }}><RefreshCw size={14} /><span>Refresh</span></button>
        </div>
      </div>
      <Banner msg={msg} />
      {verdict && (
        <div style={{ ...card, borderColor: verdict.chain_intact && verdict.hash_mismatches.length === 0 ? 'var(--border-default)' : 'var(--danger-border)', background: verdict.chain_intact && verdict.hash_mismatches.length === 0 ? 'var(--success-bg)' : 'var(--danger-bg)', fontSize: 13 }}>
          {verdict.chain_intact ? `Chain intact across the last ${verdict.checked} hashed rows.` : `Chain broken at row id${verdict.link_breaks.length > 1 ? 's' : ''} ${verdict.link_breaks.join(', ')}: a row may have been removed or inserted.`}
          {verdict.hash_mismatches.length > 0 && ` ${verdict.hash_mismatches.length} row hash${verdict.hash_mismatches.length > 1 ? 'es do' : ' does'} not recompute (ids ${verdict.hash_mismatches.slice(0, 10).join(', ')}). If the chain links are intact this can be a database time zone setting that differs from when the rows were written.`}
        </div>
      )}

      <div style={{ ...card, display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'end' }}>
        <div><span style={{ fontSize: 12, color: 'var(--text-muted)' }}>Action</span>
          <select style={{ ...field, width: 220 }} value={action} onChange={e => { setOffset(0); setAction(e.target.value); }}>
            <option value="">All actions</option>{(data?.actions ?? []).map(a => <option key={a} value={a}>{a}</option>)}
          </select></div>
        <div><span style={{ fontSize: 12, color: 'var(--text-muted)' }}>Actor email contains</span>
          <input style={{ ...field, width: 220 }} value={actor} onChange={e => { setOffset(0); setActor(e.target.value); }} /></div>
        <div><span style={{ fontSize: 12, color: 'var(--text-muted)' }}>Period</span>
          <select style={{ ...field, width: 150 }} value={days} onChange={e => { setOffset(0); setDays(e.target.value); }}>
            <option value="">All time</option><option value="1">Last 24 hours</option><option value="7">Last 7 days</option><option value="30">Last 30 days</option>
          </select></div>
      </div>

      <div style={card}>
        {!data || data.rows.length === 0 ? <Empty>0 audit rows match.</Empty> : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead><tr>{['#', 'When', 'Actor', 'Role', 'Action', 'Detail'].map(h => <th key={h} style={th}>{h}</th>)}</tr></thead>
              <tbody>{data.rows.map(r => (
                <tr key={r.id} onClick={() => setOpen(open === r.id ? null : r.id)} style={{ cursor: 'pointer' }}>
                  <td style={td}>{r.id}</td><td style={td}>{when(r.at)}</td><td style={td}>{r.actor_email ?? 'system'}</td><td style={td}>{r.role ?? ''}</td><td style={td}><code>{r.action}</code></td>
                  <td style={{ ...td, maxWidth: 380 }}>{open === r.id
                    ? <pre style={{ fontSize: 11, whiteSpace: 'pre-wrap', margin: 0 }}>{JSON.stringify(r.detail, null, 2)}{r.row_hash ? `\nhash ${r.row_hash}` : ''}</pre>
                    : <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{JSON.stringify(r.detail ?? {}).slice(0, 90)}</span>}</td>
                </tr>))}</tbody>
            </table>
          </div>
        )}
        {data && (
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 10, fontSize: 13 }}>
            <span>{data.total === 0 ? '0 rows' : `${offset + 1} to ${Math.min(offset + 100, data.total)} of ${data.total}`}</span>
            <span style={{ display: 'flex', gap: 6 }}>
              <button className="btn-secondary" disabled={busy || offset === 0} onClick={() => setOffset(Math.max(0, offset - 100))}>Newer</button>
              <button className="btn-secondary" disabled={busy || offset + 100 >= data.total} onClick={() => setOffset(offset + 100)}>Older</button>
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

export default AuditLog;
