import React, { useCallback, useEffect, useState } from 'react';
import { Users, RefreshCw, KeyRound, Eraser } from 'lucide-react';
import { useAuth } from '../lib/auth';
import * as O from '../lib/opsApi';
import { MetricCard } from '../components/MetricCard';
import { StatusBadge } from '../components/StatusBadge';
import { Banner, Bars, Empty, ago, card, cap, field, label, td, th, useRun, when } from '../components/ui';

type Tab = 'testers' | 'invites';

export const BetaDashboard: React.FC = () => {
  const { token, user } = useAuth();
  const role = user?.role ?? 'clinician';
  const canManage = role === 'master' || role === 'beta_operator' || role === 'product_manager';
  const canInvites = role === 'master' || role === 'beta_operator';
  const { busy, msg, run } = useRun();

  const [ov, setOv] = useState<O.BetaOverview | null>(null);
  const [tab, setTab] = useState<Tab>('testers');
  const [search, setSearch] = useState('');
  const [testers, setTesters] = useState<O.Tester[]>([]);
  const [invites, setInvites] = useState<O.InviteRow[]>([]);
  const [sel, setSel] = useState<string | null>(null);
  const [detail, setDetail] = useState<(O.TesterDetail & { ok: true }) | null>(null);
  const [reason, setReason] = useState('');

  const load = useCallback(async () => {
    if (!token) return;
    await run(async () => {
      const [o, t] = await Promise.all([O.betaOverview(token), O.listTesters(token, search)]);
      setOv(o); setTesters(t);
      if (role === 'master' || role === 'beta_operator' || role === 'support' || role === 'product_manager') setInvites(await O.listInvites(token));
    });
  }, [token, search, role, run]);
  useEffect(() => { void load(); }, [load]);
  useEffect(() => {
    if (!token || !sel) { setDetail(null); return; }
    void run(async () => { setDetail(await O.testerDetail(token, sel)); });
  }, [token, sel, run]);

  if (!token) return null;
  const t = token;
  const pct = (a: number, b: number) => (b > 0 ? `${Math.round((a / b) * 100)}%` : 'no data');
  const oc = ov?.outcomes_30d;
  const ocTotal = oc ? oc.followed + oc.overruled + oc.doubt : 0;

  return (
    <div className="animate-fade-in" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}><Users size={22} /><h1 style={{ fontSize: 24, fontWeight: 700, letterSpacing: '-0.02em' }}>Beta Dashboard</h1></div>
          <p style={{ fontSize: 14, color: 'var(--text-secondary)', marginTop: 4 }}>Who is in the beta, whether they are using Nia, and where they are stuck. Counts only: no patient data is stored or shown.</p>
        </div>
        <button className="btn-secondary" disabled={busy} onClick={() => void load()}><RefreshCw size={14} /><span>Refresh</span></button>
      </div>
      <Banner msg={msg} />

      {ov && (
        <>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(190px, 1fr))', gap: 14 }}>
            <MetricCard title="Applications waiting" value={ov.applications.pending}
              subtitle={ov.applications.oldest_pending_at ? `Oldest waiting ${ago(ov.applications.oldest_pending_at)}` : 'None waiting'} />
            <MetricCard title="Median time to decision" value={ov.applications.median_decision_hours == null ? 'no data' : `${ov.applications.median_decision_hours} h`} subtitle={`${ov.applications.approved} approved, ${ov.applications.rejected} rejected`} />
            <MetricCard title="Invites redeemed" value={`${ov.invites.redeemed} of ${ov.invites.issued}`} subtitle={`${ov.invites.open} open, ${ov.invites.expired_unused} expired unused`} />
            <MetricCard title="Active in last 7 days" value={ov.testers.active_7d} subtitle={`of ${ov.testers.verified} verified testers`} />
            <MetricCard title="Never opened Nia" value={ov.testers.never_opened} subtitle="Verified, but no usage event yet" />
            <MetricCard title="Open support threads" value={ov.support.open + ov.support.pending} subtitle={`${ov.support.urgent} urgent`} />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 14 }}>
            <div style={card}>
              <strong style={{ fontSize: 14 }}>Clinician decisions, last 30 days</strong>
              <div style={{ marginTop: 10 }}>
                <Bars empty="0 decisions recorded" rows={[{ k: 'Followed', v: oc?.followed ?? 0 }, { k: 'Overruled', v: oc?.overruled ?? 0 }, { k: 'Flagged doubt', v: oc?.doubt ?? 0 }]} />
              </div>
              {ocTotal > 0 && <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 8 }}>Followed rate {pct(oc!.followed, ocTotal)}. Overruled and doubt are signals to review the rule, not errors by the clinician.</p>}
            </div>
            <div style={card}>
              <strong style={{ fontSize: 14 }}>App versions in use (30 days)</strong>
              <div style={{ marginTop: 10 }}><Bars empty="0 devices reported" rows={ov.versions.map(v => ({ k: v.app_version, v: v.devices }))} /></div>
            </div>
            <div style={card}>
              <strong style={{ fontSize: 14 }}>Testers by cadre</strong>
              <div style={{ marginTop: 10 }}><Bars empty="0 testers" rows={ov.by_cadre.map(c => ({ k: c.cadre, v: c.n }))} /></div>
            </div>
            <div style={card}>
              <strong style={{ fontSize: 14 }}>Testers by facility (top 10)</strong>
              <div style={{ marginTop: 10 }}><Bars empty="0 testers" rows={ov.by_facility.map(c => ({ k: c.facility, v: c.n }))} /></div>
            </div>
            <div style={card}>
              <strong style={{ fontSize: 14 }}>Daily active testers, 14 days</strong>
              <div style={{ marginTop: 10 }}><Bars empty="0 events recorded" rows={ov.daily_14d.map(d => ({ k: d.day, v: d.accounts }))} /></div>
            </div>
          </div>
        </>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: sel ? 'minmax(0, 1.4fr) minmax(320px, 1fr)' : '1fr', gap: 16, alignItems: 'start' }}>
        <div style={card}>
          <div style={{ display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap', marginBottom: 10 }}>
            <button className={tab === 'testers' ? 'btn-primary' : 'btn-secondary'} onClick={() => setTab('testers')}>Testers</button>
            {invites.length > 0 || canInvites ? <button className={tab === 'invites' ? 'btn-primary' : 'btn-secondary'} onClick={() => setTab('invites')}>Invites</button> : null}
            <span style={{ flex: 1 }} />
            {tab === 'testers' && <input style={{ ...field, width: 220 }} placeholder="Search name, email, facility" value={search} onChange={e => setSearch(e.target.value)} />}
            {tab === 'invites' && canInvites && (
              <button className="btn-secondary" disabled={busy} title="Clears raw invite keys from applications whose invite is redeemed or expired"
                onClick={() => void run(async () => { const n = await O.scrubKeys(t); await load(); return n; }, 'Used and expired keys cleared')}><Eraser size={14} /><span>Clear used keys</span></button>
            )}
          </div>

          {tab === 'testers' && (testers.length === 0 ? <Empty>0 testers match.</Empty> : (
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead><tr>{['Tester', 'Facility', 'Status', 'Last used', 'Version', '7-day events', 'Followed / overruled / doubt', 'Flags'].map(h => <th key={h} style={th}>{h}</th>)}</tr></thead>
                <tbody>
                  {testers.map(x => (
                    <tr key={x.id} onClick={() => setSel(x.id)} style={{ cursor: 'pointer', background: sel === x.id ? 'var(--bg-surface-hover)' : undefined }}>
                      <td style={td}><div style={{ fontWeight: 600 }}>{x.name ?? 'No name'}</div><div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{x.email}</div></td>
                      <td style={td}>{x.facility ?? 'unknown'}<div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{x.cadre ?? ''}</div></td>
                      <td style={td}><StatusBadge status={x.status} size="sm" /></td>
                      <td style={td}>{ago(x.last_event_at)}</td>
                      <td style={td}>{x.app_version ?? 'none'}</td>
                      <td style={td}>{x.events_7d}</td>
                      <td style={td}>{x.followed} / {x.overruled} / {x.doubt}</td>
                      <td style={td}>
                        {x.tamper_events > 0 && <StatusBadge status="critical" size="sm" />}
                        {x.tamper_events > 0 && <span style={{ fontSize: 12, marginLeft: 6 }}>{x.tamper_events} integrity</span>}
                        {x.open_tickets > 0 && <div style={{ fontSize: 12 }}>{x.open_tickets} open ticket{x.open_tickets > 1 ? 's' : ''}</div>}
                        {x.tamper_events === 0 && x.open_tickets === 0 && <span style={{ color: 'var(--text-muted)' }}>none</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ))}

          {tab === 'invites' && (invites.length === 0 ? <Empty>0 invites issued.</Empty> : (
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead><tr>{['Email', 'Reference', 'Issued', 'Expires', 'State', ''].map(h => <th key={h} style={th}>{h}</th>)}</tr></thead>
                <tbody>
                  {invites.map(i => (
                    <tr key={i.id}>
                      <td style={td}>{i.email}</td><td style={td}>{i.ref_code ?? 'none'}</td>
                      <td style={td}>{ago(i.created_at)}</td><td style={td}>{i.state === 'redeemed' ? `redeemed ${ago(i.used_at)}` : when(i.expires_at)}</td>
                      <td style={td}><StatusBadge status={i.state === 'open' ? 'pending' : i.state === 'redeemed' ? 'verified' : 'suspended'} size="sm" /> <span style={{ fontSize: 12 }}>{i.state}</span></td>
                      <td style={td}>
                        {canInvites && i.state !== 'redeemed' && (
                          <div style={{ display: 'flex', gap: 6 }}>
                            <button className="btn-secondary" disabled={busy} onClick={() => void run(async () => { await O.inviteAction(t, i.id, 'extend', 14, null); await load(); }, 'Invite extended by 14 days')}>Extend 14 d</button>
                            {i.state === 'open' && <button className="btn-danger" disabled={busy} onClick={() => {
                              const why = window.prompt('Reason for revoking this invite (required):');
                              if (why) void run(async () => { await O.inviteAction(t, i.id, 'revoke', 0, why); await load(); }, 'Invite revoked');
                            }}>Revoke</button>}
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ))}
        </div>

        {sel && (
          <div style={card}>
            {!detail ? <Empty>Loading tester...</Empty> : (
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 16 }}>{detail.account.name ?? 'No name'}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{detail.account.email} - {detail.account.cadre ?? 'cadre unknown'} - {detail.account.facility ?? 'facility unknown'}</div>
                  </div>
                  <button className="btn-secondary" onClick={() => setSel(null)}>Close</button>
                </div>
                <p style={{ fontSize: 12, marginTop: 8 }}><StatusBadge status={detail.account.status} size="sm" /> Joined {when(detail.account.created_at)}. Last sign-in {ago(detail.account.last_login)}.</p>
                {detail.application && <p style={{ fontSize: 12, color: 'var(--text-secondary)' }}>Application {detail.application.ref_code}{detail.application.mct_number ? `, MCT ${detail.application.mct_number}` : ''}{detail.application.department ? `, ${detail.application.department}` : ''}.</p>}

                {detail.tamper_events.length > 0 && (
                  <div style={{ ...card, marginTop: 10, borderColor: 'var(--danger-border)', background: 'var(--danger-bg)' }}>
                    <strong style={{ fontSize: 13 }}>Integrity events</strong>
                    {detail.tamper_events.map((e, i) => <div key={i} style={{ fontSize: 12, marginTop: 4 }}>{when(e.ts)}: {e.feature}{e.action ? ` / ${e.action}` : ''} on {e.device_id ?? 'unknown device'}</div>)}
                  </div>
                )}

                <span style={cap}>Devices</span>
                {detail.devices.length === 0 ? <Empty>0 devices have reported.</Empty> : detail.devices.map(d => (
                  <div key={d.device_id} style={{ fontSize: 12, padding: '4px 0' }}><code>{d.device_id}</code> - v{d.app_version ?? '?'} - {d.events} events - last seen {ago(d.last_seen)}</div>
                ))}

                <span style={cap}>Recent activity</span>
                {detail.recent_events.length === 0 ? <Empty>0 events recorded.</Empty> : (
                  <div style={{ maxHeight: 220, overflowY: 'auto' }}>
                    {detail.recent_events.map((e, i) => <div key={i} style={{ fontSize: 12, padding: '3px 0', borderBottom: '1px solid var(--border-subtle)' }}>
                      {ago(e.ts)} - {e.feature}{e.action ? ` / ${e.action}` : ''}{e.rule_id ? ` - ${e.rule_id}` : ''}{e.outcome ? ` - ${e.outcome}` : ''}</div>)}
                  </div>
                )}

                <span style={cap}>Support threads</span>
                {detail.threads.length === 0 ? <Empty>0 threads.</Empty> : detail.threads.map(th2 => <div key={th2.id} style={{ fontSize: 12, padding: '3px 0' }}>{th2.subject} - {label(th2.status)} - {ago(th2.last_message_at)}</div>)}

                {canManage && (
                  <div style={{ marginTop: 14, borderTop: '1px solid var(--border-subtle)', paddingTop: 12 }}>
                    <span style={cap}>{detail.account.status === 'suspended' ? 'Reason for reinstating' : 'Reason for suspending (required, logged)'}</span>
                    <input style={field} value={reason} onChange={e => setReason(e.target.value)} placeholder="At least 5 characters" />
                    <div style={{ marginTop: 8 }}>
                      {detail.account.status === 'suspended'
                        ? <button className="btn-primary" disabled={busy || reason.trim().length < 5}
                            onClick={() => void run(async () => { await O.setTesterStatus(t, detail.account.id, 'verified', reason); setReason(''); await load(); setDetail(await O.testerDetail(t, detail.account.id)); }, 'Tester reinstated')}><KeyRound size={14} /><span>Reinstate</span></button>
                        : <button className="btn-danger" disabled={busy || reason.trim().length < 5}
                            onClick={() => { if (window.confirm('Suspend this tester? Their signed-in sessions end immediately.')) void run(async () => { await O.setTesterStatus(t, detail.account.id, 'suspended', reason); setReason(''); await load(); setDetail(await O.testerDetail(t, detail.account.id)); }, 'Tester suspended'); }}><span>Suspend access</span></button>}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default BetaDashboard;
