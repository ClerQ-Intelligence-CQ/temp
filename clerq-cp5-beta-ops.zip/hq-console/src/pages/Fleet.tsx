import React, { useCallback, useEffect, useState } from 'react';
import { Smartphone, RefreshCw } from 'lucide-react';
import { useAuth } from '../lib/auth';
import * as O from '../lib/opsApi';
import { MetricCard } from '../components/MetricCard';
import { StatusBadge } from '../components/StatusBadge';
import { Banner, Bars, Empty, ago, card, td, th, useRun, when } from '../components/ui';

export const Fleet: React.FC = () => {
  const { token } = useAuth();
  const { busy, msg, run } = useRun();
  const [f, setF] = useState<(O.Fleet & { ok: true }) | null>(null);
  const [staleOnly, setStaleOnly] = useState(false);

  const load = useCallback(async () => { if (token) await run(async () => { setF(await O.fleet(token)); }); }, [token, run]);
  useEffect(() => { void load(); }, [load]);
  if (!token) return null;

  const devices = f?.devices ?? [];
  const shown = staleOnly ? devices.filter(d => d.stale) : devices;
  const stale = devices.filter(d => d.stale).length;
  const active7 = devices.filter(d => d.days_since <= 7).length;

  return (
    <div className="animate-fade-in" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}><Smartphone size={22} /><h1 style={{ fontSize: 24, fontWeight: 700, letterSpacing: '-0.02em' }}>Device Fleet</h1></div>
          <p style={{ fontSize: 14, color: 'var(--text-secondary)', marginTop: 4 }}>Phones that have reported at least one usage event. A phone that has never connected does not appear here.</p>
        </div>
        <button className="btn-secondary" disabled={busy} onClick={() => void load()}><RefreshCw size={14} /><span>Refresh</span></button>
      </div>
      <Banner msg={msg} />
      {f && (
        <>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 14 }}>
            <MetricCard title="Devices reporting" value={devices.length} subtitle={devices.length === 500 ? 'Showing the 500 most recent' : undefined} />
            <MetricCard title="Seen in last 7 days" value={active7} />
            <MetricCard title={`Past offline grace (${f.grace_days} d)`} value={stale} subtitle="These phones will lock until they reconnect" />
            <MetricCard title="Below minimum version" value={f.below_min == null ? 'not set' : f.below_min} subtitle={f.min_app_version ? `Minimum is ${f.min_app_version}` : 'No minimum version is configured'} />
            <MetricCard title="Integrity events, 30 days" value={f.tamper_30d.length} />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 14 }}>
            <div style={card}><strong style={{ fontSize: 14 }}>Version adoption (by latest report)</strong><div style={{ marginTop: 10 }}><Bars empty="0 devices reported" rows={f.adoption.map(a => ({ k: a.app_version, v: a.devices }))} /></div></div>
            <div style={card}><strong style={{ fontSize: 14 }}>Devices reporting per day, 14 days</strong><div style={{ marginTop: 10 }}><Bars empty="0 events recorded" rows={f.daily_14d.map(d => ({ k: d.day, v: d.devices }))} /></div></div>
          </div>

          <div style={card}>
            <strong style={{ fontSize: 14 }}>Integrity events, last 30 days</strong>
            <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '4px 0 8px' }}>Events whose feature is "tamper" or "integrity". Root and debug checks are best-effort on the phone; clock rollback and model tampering are reliable.</p>
            {f.tamper_30d.length === 0 ? <Empty>0 integrity events recorded.</Empty> : f.tamper_30d.map((e, i) => (
              <div key={i} style={{ fontSize: 13, padding: '5px 0', borderTop: '1px solid var(--border-subtle)' }}>{when(e.ts)} - {e.feature}{e.action ? ` / ${e.action}` : ''} - device <code>{e.device_id ?? 'unknown'}</code> - v{e.app_version ?? '?'}</div>
            ))}
          </div>

          <div style={card}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
              <strong style={{ fontSize: 14 }}>Devices</strong>
              <label style={{ fontSize: 13, display: 'flex', gap: 6 }}><input type="checkbox" checked={staleOnly} onChange={e => setStaleOnly(e.target.checked)} /> Only phones past offline grace</label>
            </div>
            {shown.length === 0 ? <Empty>0 devices match.</Empty> : (
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead><tr>{['Device', 'Version', 'Facility', 'Accounts', 'First seen', 'Last seen', '30-day events', 'State'].map(h => <th key={h} style={th}>{h}</th>)}</tr></thead>
                  <tbody>{shown.map(d => (
                    <tr key={d.device_id}>
                      <td style={td}><code>{d.device_id}</code></td><td style={td}>{d.app_version ?? 'unknown'}</td><td style={td}>{d.facility ?? 'unknown'}</td><td style={td}>{d.accounts}</td>
                      <td style={td}>{when(d.first_seen)}</td><td style={td}>{ago(d.last_seen)}</td><td style={td}>{d.events_30d}</td>
                      <td style={td}>{d.stale ? <StatusBadge status="locked" size="sm" /> : <StatusBadge status="active" size="sm" />} <span style={{ fontSize: 12 }}>{d.stale ? `silent ${d.days_since} d` : 'in grace'}</span></td>
                    </tr>))}</tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default Fleet;
