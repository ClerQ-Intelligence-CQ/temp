import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Headphones, Send, RefreshCw, ShieldAlert, EyeOff, Plus, Trash2 } from 'lucide-react';
import { useAuth } from '../lib/auth';
import * as O from '../lib/opsApi';
import { StatusBadge } from '../components/StatusBadge';
import { Banner, Empty, ago, card, cap, field, label, useRun, when } from '../components/ui';

const FILTERS: Array<{ id: O.ThreadStatus | 'all'; label: string }> = [
  { id: 'open', label: 'Needs reply' }, { id: 'pending', label: 'Waiting on clinician' }, { id: 'resolved', label: 'Resolved' }, { id: 'all', label: 'All' },
];
const PRIORITIES: O.Priority[] = ['low', 'normal', 'high', 'urgent'];

export const Support: React.FC = () => {
  const { token, user } = useAuth();
  const role = user?.role ?? 'clinician';
  const canRedact = ['master', 'support', 'beta_operator', 'product_manager'].includes(role);
  const { busy, msg, run } = useRun();

  const [filter, setFilter] = useState<O.ThreadStatus | 'all'>('open');
  const [counts, setCounts] = useState({ open: 0, pending: 0, resolved: 0, urgent: 0 });
  const [threads, setThreads] = useState<O.ThreadRow[]>([]);
  const [sel, setSel] = useState<string | null>(null);
  const [detail, setDetail] = useState<(O.ThreadDetail & { ok: true }) | null>(null);
  const [draft, setDraft] = useState('');
  const [canned, setCanned] = useState<O.Canned[]>([]);
  const [lang, setLang] = useState<'en' | 'sw'>('en');
  const [editing, setEditing] = useState<{ id: string | null; title: string; en: string; sw: string } | null>(null);
  const bottom = useRef<HTMLDivElement>(null);

  const loadList = useCallback(async () => {
    if (!token) return;
    try {
      const r = await O.supportList(token, filter === 'all' ? undefined : filter);
      setCounts(r.counts); setThreads(r.threads);
    } catch { /* the banner is set by explicit actions; background polls stay quiet */ }
  }, [token, filter]);
  const loadThread = useCallback(async (id: string) => { if (token) setDetail(await O.supportThread(token, id)); }, [token]);

  useEffect(() => { void run(async () => { await loadList(); if (token) setCanned(await O.cannedList(token)); }); }, [loadList, token, run]);
  useEffect(() => { if (sel) void run(() => loadThread(sel)); else setDetail(null); }, [sel, loadThread, run]);
  useEffect(() => {   // light polling so new clinician messages show without a refresh
    const h = window.setInterval(() => { void loadList(); if (sel) void loadThread(sel).catch(() => undefined); }, 30000);
    return () => window.clearInterval(h);
  }, [loadList, loadThread, sel]);
  useEffect(() => { bottom.current?.scrollIntoView({ block: 'end' }); }, [detail?.messages.length]);

  if (!token) return null;
  const t = token;
  const refreshAll = async () => { await loadList(); if (sel) await loadThread(sel); };

  return (
    <div className="animate-fade-in" style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}><Headphones size={22} /><h1 style={{ fontSize: 24, fontWeight: 700, letterSpacing: '-0.02em' }}>Support Desk</h1></div>
          <p style={{ fontSize: 14, color: 'var(--text-secondary)', marginTop: 4 }}>Messages from signed-in testers, sent from inside Nia. Every reply, status change and redaction is logged.</p>
        </div>
        <button className="btn-secondary" disabled={busy} onClick={() => void run(refreshAll)}><RefreshCw size={14} /><span>Refresh</span></button>
      </div>
      <div style={{ ...card, padding: '10px 14px', fontSize: 13, display: 'flex', gap: 8, alignItems: 'center' }}>
        <ShieldAlert size={16} /> Never ask for or paste patient names or identifiers here. If a clinician sends them, redact the message.
      </div>
      <Banner msg={msg} />

      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(260px, 340px) minmax(0, 1fr)', gap: 16, alignItems: 'start' }}>
        <div style={card}>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 10 }}>
            {FILTERS.map(f => (
              <button key={f.id} className={filter === f.id ? 'btn-primary' : 'btn-secondary'} onClick={() => setFilter(f.id)}>
                {f.label}{f.id !== 'all' ? ` (${counts[f.id]})` : ''}
              </button>
            ))}
          </div>
          {counts.urgent > 0 && <p style={{ fontSize: 12, color: 'var(--danger)', marginBottom: 8 }}>{counts.urgent} urgent thread{counts.urgent > 1 ? 's' : ''} unresolved</p>}
          {threads.length === 0 ? <Empty>0 threads here.</Empty> : threads.map(x => (
            <button key={x.id} onClick={() => setSel(x.id)} style={{ display: 'block', width: '100%', textAlign: 'left', padding: '10px 12px', marginBottom: 6, cursor: 'pointer',
              borderRadius: 'var(--radius-sm)', border: `1px solid ${x.id === sel ? 'var(--text-primary)' : 'var(--border-subtle)'}`, background: 'var(--bg-surface)', color: 'var(--text-primary)' }}>
              <span style={{ display: 'flex', justifyContent: 'space-between', gap: 8, fontWeight: 600, fontSize: 13 }}>
                <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{x.subject}</span>
                {x.priority !== 'normal' && <StatusBadge status={x.priority === 'urgent' ? 'critical' : x.priority === 'high' ? 'warn' : 'info'} size="sm" />}
              </span>
              <span style={{ display: 'block', fontSize: 12, color: 'var(--text-muted)' }}>{x.clinician_name ?? 'No name'}{x.facility ? `, ${x.facility}` : ''}</span>
              <span style={{ display: 'block', fontSize: 12, color: 'var(--text-muted)' }}>
                {label(x.status)} - {x.messages} message{x.messages === 1 ? '' : 's'} - {ago(x.last_message_at)}{x.assigned_name ? ` - ${x.assigned_name}` : ''}
                {x.status === 'open' && x.last_sender === 'clinician' ? ' - awaiting reply' : ''}
              </span>
            </button>
          ))}
        </div>

        <div style={card}>
          {!detail ? <Empty>{sel ? 'Loading thread...' : 'Select a thread.'}</Empty> : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 16 }}>{detail.thread.subject}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                    {detail.clinician.name ?? 'No name'} - {detail.clinician.cadre ?? 'cadre unknown'} - {detail.clinician.facility ?? 'facility unknown'} - {detail.clinician.email}
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                    {label(detail.thread.category)} - app {detail.thread.app_version ?? 'unknown'} - device {detail.thread.device_id ?? 'unknown'} - opened {when(detail.thread.created_at)}
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
                  <select style={{ ...field, width: 110 }} value={detail.thread.priority} disabled={busy}
                    onChange={e => void run(async () => { await O.supportUpdate(t, detail.thread.id, { priority: e.target.value }); await refreshAll(); })}>
                    {PRIORITIES.map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                  <button className="btn-secondary" disabled={busy} onClick={() => void run(async () => { await O.supportUpdate(t, detail.thread.id, { assign_to_me: true }); await refreshAll(); }, 'Assigned to you')}>Assign to me</button>
                  {detail.thread.status === 'resolved'
                    ? <button className="btn-secondary" disabled={busy} onClick={() => void run(async () => { await O.supportUpdate(t, detail.thread.id, { status: 'open' }); await refreshAll(); }, 'Thread reopened')}>Reopen</button>
                    : <button className="btn-primary" disabled={busy} onClick={() => void run(async () => { await O.supportUpdate(t, detail.thread.id, { status: 'resolved' }); await refreshAll(); }, 'Thread resolved')}>Resolve</button>}
                </div>
              </div>

              <div style={{ maxHeight: 380, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 8, padding: '8px 0', borderTop: '1px solid var(--border-subtle)', borderBottom: '1px solid var(--border-subtle)' }}>
                {detail.messages.map(m => (
                  <div key={m.id} style={{ alignSelf: m.from === 'staff' ? 'flex-end' : 'flex-start', maxWidth: '80%' }}>
                    <div style={{ fontSize: 11, color: 'var(--text-muted)', textAlign: m.from === 'staff' ? 'right' : 'left' }}>{m.sender ?? (m.from === 'staff' ? 'ClerQ Support' : 'Clinician')} - {when(m.at)}</div>
                    <div style={{ padding: '8px 12px', borderRadius: 'var(--radius-md)', fontSize: 13, whiteSpace: 'pre-wrap', fontStyle: m.redacted ? 'italic' : 'normal',
                      background: m.from === 'staff' ? 'var(--text-primary)' : 'var(--bg-surface-hover)', color: m.from === 'staff' ? 'var(--text-inverse)' : 'var(--text-primary)' }}>{m.body}</div>
                    {canRedact && !m.redacted && m.from === 'clinician' && (
                      <button className="btn-secondary" style={{ marginTop: 4, fontSize: 11, padding: '2px 8px' }} disabled={busy}
                        onClick={() => { if (window.confirm('Remove this message text for everyone? This cannot be undone.')) void run(async () => { await O.supportRedact(t, m.id); await refreshAll(); }, 'Message removed'); }}><EyeOff size={12} /><span>Redact</span></button>
                    )}
                  </div>
                ))}
                <div ref={bottom} />
              </div>

              <div style={{ display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
                <select style={{ ...field, width: 220 }} value="" onChange={e => {
                  const c = canned.find(x => x.id === e.target.value);
                  if (c) setDraft(prev => (prev ? prev + '\n' : '') + (lang === 'sw' && c.body_sw ? c.body_sw : c.body_en));
                }}>
                  <option value="">Insert saved reply...</option>
                  {canned.map(c => <option key={c.id} value={c.id}>{c.title}{lang === 'sw' && !c.body_sw ? ' (English only)' : ''}</option>)}
                </select>
                <select style={{ ...field, width: 110 }} value={lang} onChange={e => setLang(e.target.value as 'en' | 'sw')}><option value="en">English</option><option value="sw">Swahili</option></select>
              </div>
              <textarea style={{ ...field, minHeight: 84 }} placeholder="Write a reply" maxLength={2000} value={draft} onChange={e => setDraft(e.target.value)} />
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{draft.length} / 2000. Sending marks the thread as waiting on the clinician.</span>
                <button className="btn-primary" disabled={busy || draft.trim().length === 0}
                  onClick={() => void run(async () => { await O.supportReply(t, detail.thread.id, draft); setDraft(''); await refreshAll(); }, 'Reply sent')}><Send size={14} /><span>Send reply</span></button>
              </div>
            </div>
          )}
        </div>
      </div>

      <div style={card}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <strong style={{ fontSize: 14 }}>Saved replies</strong>
          {canRedact && <button className="btn-secondary" onClick={() => setEditing({ id: null, title: '', en: '', sw: '' })}><Plus size={14} /><span>New reply</span></button>}
        </div>
        <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 4 }}>Swahili text should be reviewed by a clinician before it is saved. Replies without Swahili fall back to English.</p>
        {canned.length === 0 ? <Empty>0 saved replies.</Empty> : canned.map(c => (
          <div key={c.id} style={{ display: 'flex', justifyContent: 'space-between', gap: 10, padding: '8px 0', borderTop: '1px solid var(--border-subtle)' }}>
            <div><div style={{ fontWeight: 600, fontSize: 13 }}>{c.title}</div><div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{c.body_en}</div></div>
            {canRedact && <div style={{ display: 'flex', gap: 6 }}>
              <button className="btn-secondary" onClick={() => setEditing({ id: c.id, title: c.title, en: c.body_en, sw: c.body_sw ?? '' })}>Edit</button>
              <button className="btn-danger" aria-label="Delete saved reply" disabled={busy} onClick={() => { if (window.confirm(`Delete "${c.title}"?`)) void run(async () => { await O.cannedDelete(t, c.id); setCanned(await O.cannedList(t)); }, 'Saved reply deleted'); }}><Trash2 size={14} /></button>
            </div>}
          </div>
        ))}
        {editing && (
          <div style={{ marginTop: 12, borderTop: '1px solid var(--border-subtle)', paddingTop: 10 }}>
            <span style={cap}>Title</span><input style={field} value={editing.title} onChange={e => setEditing({ ...editing, title: e.target.value })} />
            <span style={cap}>English</span><textarea style={{ ...field, minHeight: 64 }} value={editing.en} onChange={e => setEditing({ ...editing, en: e.target.value })} />
            <span style={cap}>Swahili (optional)</span><textarea style={{ ...field, minHeight: 64 }} value={editing.sw} onChange={e => setEditing({ ...editing, sw: e.target.value })} />
            <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
              <button className="btn-primary" disabled={busy || editing.title.trim().length < 2 || !editing.en.trim()}
                onClick={() => void run(async () => { await O.cannedSave(t, editing.id, editing.title, editing.en, editing.sw); setEditing(null); setCanned(await O.cannedList(t)); }, 'Saved reply stored')}>Save</button>
              <button className="btn-secondary" onClick={() => setEditing(null)}>Cancel</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Support;
