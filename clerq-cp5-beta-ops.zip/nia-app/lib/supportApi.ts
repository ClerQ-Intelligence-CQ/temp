// Nia (ClerQApp) support chat client. Plain fetch, no new dependencies.
// Pass the Supabase URL and anon key from constants/cloud.ts, and the signed-in session token you already hold.
// Rules: never put patient names or identifiers in a message. Show that warning above the input.
// Errors come back as codes: unauthorized, rate_limited, bad_subject, bad_body, not_found.
export interface CloudConfig { url: string; anonKey: string }
export type SupportCategory = 'install' | 'model_download' | 'login' | 'clinical_content' | 'crash' | 'feedback' | 'other';
export interface MyThread { id: string; subject: string; category: SupportCategory; status: 'open' | 'pending' | 'resolved'; last_message_at: string; unread: boolean }
export interface ChatMessage { id: number; from: 'clinician' | 'staff'; body: string; at: string }
export interface ChatThread { thread: { id: string; subject: string; category: SupportCategory; status: string }; messages: ChatMessage[] }

export class SupportError extends Error { constructor(public code: string) { super(code); } }

async function rpc<T>(cfg: CloudConfig, fn: string, args: Record<string, unknown>): Promise<T> {
  const res = await fetch(`${cfg.url}/rest/v1/rpc/${fn}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', apikey: cfg.anonKey, authorization: `Bearer ${cfg.anonKey}` },
    body: JSON.stringify(args),
  });
  const data = await res.json().catch(() => null);
  if (!res.ok || !data) throw new SupportError('network');
  if (data.ok !== true) throw new SupportError(String(data.error ?? 'unknown'));
  return data as T;
}

export const openThread = async (cfg: CloudConfig, token: string, subject: string, category: SupportCategory, body: string, deviceId?: string, appVersion?: string) =>
  (await rpc<{ thread_id: string }>(cfg, 'cq_support_open', { p_token: token, p_subject: subject, p_category: category, p_body: body, p_device_id: deviceId ?? null, p_app_version: appVersion ?? null })).thread_id;
export const sendMessage = async (cfg: CloudConfig, token: string, threadId: string, body: string) => { await rpc(cfg, 'cq_support_send', { p_token: token, p_thread_id: threadId, p_body: body }); };
export const myThreads = async (cfg: CloudConfig, token: string) => (await rpc<{ threads: MyThread[] }>(cfg, 'cq_support_my_threads', { p_token: token })).threads;
export const getThread = (cfg: CloudConfig, token: string, threadId: string) => rpc<{ ok: true } & ChatThread>(cfg, 'cq_support_thread', { p_token: token, p_thread_id: threadId });
/** For a tab badge: how many threads have a staff reply the clinician has not read yet. */
export const unreadCount = async (cfg: CloudConfig, token: string) => (await myThreads(cfg, token)).filter(t => t.unread).length;
