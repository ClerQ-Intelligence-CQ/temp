# CP6 notes: Release Manager, public site, lockdown

Read this before applying anything. Nothing here has run against a real database, and the console was not compiled.

## What was checked, and what was not

| Part | Checked | Not checked |
|---|---|---|
| Site scripts (intro, pill, catalog, product page) | Ran in headless Chromium against a mocked catalog: intro plays and clears, skip works, once per session, reduced motion skips it, pill hidden when no beta is open, new product from the catalog gets a tab and a Contact button, HTML in catalog text is escaped, fallback file used when the backend is unreachable | Real Supabase, real phones, performance budget (LCP, bundle size), Swahili text, the 3D scene (this sandbox cannot load Three.js, so the new generic-shape branch in product-scene.js never ran) |
| HQ Release Manager page | Syntax and names checked with stub types | Not built or typechecked against real React and lucide types (no node_modules, no network). Run `npm install && npx tsc --noEmit && npm run build` first. Not opened in a browser |
| 0008 and 0009 SQL | Read through twice | Never executed. No Postgres in this sandbox. `backend/tests/smoke_0008.sql` is written for you to run; expect small first-run fixes |

## Do these first (security)

1. **Master password is in your public repo.** `hq-console/src/pages/Login.tsx` had a "Fill Master Operator Credentials" button with the email and password in the code, and `README.md` printed them. This patch removes both, but the password is already in git history and on whatever is deployed. Change the master password now and treat the old one as public.
2. **Your whole repo is being served.** Netlify publishes `.`, so `/schema/*.sql`, `/hq-console/src/*`, `/HANDOFF_INSTRUCTIONS.md` and the README are downloadable today. `_redirects` in this patch hides them with `404!` rules, but the proper fix is to move `hq-console`, `schema`, and the docs out of the website repo (or publish only a `public/` folder).
3. Also still outstanding from earlier checkpoints: revoke the Expo token and change the keystore passwords (both are in the Nia doc), and run 0005 together with 0007, never 0005 alone.

## Backend (0008, 0009)

Order: 0005, 0006, 0007, 0008, 0009. Run on staging first.

- **Staged rollout**: steps 1, 5, 25, 50, 100, upward only. A build needs a SHA-256 to go live. Halt, resume and rollback need a reason and are never blocked by a freeze window.
- **Rollback** withdraws the build (rollout 0). The previous live build for that product, channel and platform keeps being offered. If there is none, phones are offered nothing. It does not downgrade phones that already installed the bad build.
- **Phone update offer**: new call `cq_get_update(app_version, device_id)`. A device falls into a fixed bucket 0 to 99 from a hash of its id, so it stays consistent as the rollout widens. `cq_get_config` is not touched. Nia must call the new function (see `nia-app/lib/updateApi.ts`) and must verify the SHA-256 of what it downloads.
- **Kill switch**: a lock without data wipe is one person and immediate (reversible). A lock with data wipe needs a different person to approve, then a countdown of 5 to 1440 minutes that either person can cancel. The requester can never approve their own request, master included. Pending requests expire after 24 hours.
  - **This is my decision, not yours.** The spec asks for two people on a wipe. I did not require two people for a plain lock, because in an incident speed matters and a lock can be lifted. If you want two people for every lock, change the `if wipe_ then` branch in `cq_hq_kill_request`.
  - You need two different people with the release_manager or master role. With one person, wipe requests cannot be approved.
  - Wipe is irreversible: Nia keeps clinical data only on the phone. The console says so.
- **A bypass was closed.** `cq_hq_set_config` (0002) let a master set `locked` and `wipe_on_lock` directly, skipping the two-person rule. 0008 redefines it so those two fields are refused (`use_kill_switch`). Everything else it did still works.
- **Countdown execution**: if the `pg_cron` extension is enabled, 0008 schedules `cq_apply_due_kills()` every minute. If not, the console shows a "Run now" button once the countdown ends. Without pg_cron an approved wipe does nothing until someone presses it.
- **Minimum version guard**: `cq_hq_rel_set_policy` refuses a minimum app version higher than every stable build live at 100 percent, so you cannot lock out all phones with nothing to update to.
- **Model registry**: register a file (HTTPS address, SHA-256, size), then Activate for a version. HQ does not fetch the file or check the hash. A wrong hash means phones fail to install the model.
- **0009 seeds the four products** that were hardcoded on the site (nia-cds closed beta with an open beta program, the others alpha with it closed). The stages are placeholders: set the real ones in Product Studio. The pages are inserted as already published (migration owner), which skips the clinical-approval step once. Review them. 0009 also replaces `cq_get_catalog` to return each product's beta flag and newest live build.

## HQ console

- `Releases.tsx` replaces the old Release Control page: Builds and rollout, Kill switch, Model files, Policy and freezes. Risky actions open a dialog that asks for a reason, and a lock on all versions or a wipe approval asks you to type a word.
- Nav item renamed Release Manager and limited to release_manager, product_manager, network_maint, analyst, security (master sees all). Analysts and others can view but not act.
- Build upload is not done: you host the file elsewhere and paste its address and hash.
- Auto-halt on a crash threshold is not done: Nia sends no crash reports yet.

## Public site

- `/hq/` page deleted (see DELETE.txt) and every footer link to it removed. `/hq` and `/hq/*` now return 404.
- Catalog: the product page reads `cq_get_catalog`, keeps the last good copy in the browser, and falls back to `data/catalog-fallback.json`. When it is showing a saved copy it says so on the page.
- **Page blocks are thin.** Studio blocks have only a title and body. The site maps: hero block to heading and description, stat strip to the engine line, safety statement to a notice. Feature cards come from a feature grid block whose body has one feature per line: `TAG | Title :: Description` (tag optional). Studio does not explain this format yet.
- Buttons follow the stage: a product with an open beta shows "Apply for Clinical Beta Evaluation"; others show "Contact us"; retired products show a disabled button. Applications are not tied to a product yet (the apply function has no product field).
- Intro: about 3.7 s, 2D canvas, skip button, once per session, hidden for reduced motion, skipped when no product is flagged "show in orbit" or the catalog does not load within 1.5 s. Product logos fall back to the first letter because the catalog `logo` field is empty for all four products. I used plain JavaScript, not GSAP.
- Beta pill: shows only when the catalog says a beta is open. Menu: "I have a key" and "Request access". They reuse the existing key door and 3-step form on /product/.
- **Scroll choreography (new):** a Products section on the homepage. Product marks sit on a ring; when the section scrolls into view they move into cards one after another and each card's text fades in. The layout comes from a catalog setting named `home_arrangement` (`grid`, `staggered` or `rail`, default grid). Studio has no control for it yet: add the row `home_arrangement` to `cq_site_settings` by hand, or build the control. Click goes to `/product/#product=<slug>`. The shared-element transition uses cross-page view transitions, which only some browsers support; elsewhere you just get the normal page change, and I could not see that animation in a headless browser. Reduced motion shows the cards at once. Built with plain JavaScript, no GSAP.
- Studio now explains the feature-grid line format (`TAG | Title :: Description`) and the stat strip under those blocks (`hq-console-ProductStudio.diff`).
- Copy: "offline" in the homepage description, the problem section and the first product feature tag is now "offline-capable", per your own rule. I left "Lucy runs with full offline capability" and "offline execution" because they describe what the app does, but check them against your claims.
- **Not done, and why:** signed download portal (C9; needs file storage and a signing service you have not chosen), auto-halt on crash threshold (Nia sends no crash reports), Swahili catalog text (needs clinician-reviewed translations; the loader already asks for it), the Dispatches rename and Research merge (a structure decision for you), a Studio control for the home arrangement, and tying beta applications to a product.
- Existing issue, not mine: at phone width (390 px) the homepage already scrolls sideways (it is 590 px wide on your original repo too). I did not chase it.
