ClerQ checkpoint 6: Release Manager, catalog-driven site, /hq/ lockdown
Read NOTES.md first. Apply order for SQL: 0005, 0006, 0007, 0008, 0009 (staging first).

backend/schema/0008_release_manager.sql   builds, rollout, halt/resume/rollback, update offer, models, policy, freezes, kill switch
backend/schema/0009_seed_catalog.sql      seeds the four products, adds beta flag and newest build to cq_get_catalog
backend/tests/smoke_0008.sql              behaviour test to run on a scratch Postgres
hq-console/src/pages/Releases.tsx         new Release Manager page (replaces the old one)
hq-console/src/lib/releaseApi.ts          API client with readable error messages
hq-console/src/components/Layout.tsx      nav role restriction (diff: hq-console-Layout.diff)
hq-console/src/pages/Login.tsx            master credentials autofill removed (diff: hq-console-Login.diff)
nia-app/lib/updateApi.ts                  phone-side update check
hq-console/src/pages/ProductStudio.tsx    block hints for the line format (diff: hq-console-ProductStudio.diff)
site/                                     website files to copy over the repo root (see DELETE.txt for the file to remove)
