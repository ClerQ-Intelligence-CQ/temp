-- 0008_release_manager.sql
-- Release Manager: builds, staged rollout, halt/resume/rollback, update offer for phones, model artifact registry,
-- release policy (min version, grace days, lock message), freeze windows, kill switch with two-person approval.
-- Run after 0005, 0006 and 0007. NOT executed against any database yet: run on staging first and fix forward.
-- Design notes:
--  * Phones keep using cq_get_config (unchanged). The kill switch works by writing cq_release_config, which they already honour.
--  * New phone-facing call is additive: cq_get_update(app_version, device_id). cq_get_config is not touched.
--  * A lock WITHOUT data wipe is one person and immediate (it is reversible). A lock WITH data wipe needs a second person
--    and a countdown, because wiped on-device data cannot be recovered (Nia keeps no patient data on a server).
begin;

-- 1. Columns and tables ------------------------------------------------------------------------------------
alter table cq_product_releases
  add column if not exists live_at timestamptz,
  add column if not exists halted_at timestamptz, add column if not exists halt_reason text,
  add column if not exists rolled_back_at timestamptz, add column if not exists rollback_reason text,
  add column if not exists updated_at timestamptz not null default now();
create unique index if not exists cq_rel_unique on cq_product_releases(product_id, channel, platform, version_name);

create table if not exists cq_model_artifacts (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('lucy','voice')),
  name text not null, url text not null check (url ~ '^https://'),
  sha256 text not null check (sha256 ~ '^[0-9a-f]{64}$'), bytes bigint not null check (bytes > 0),
  min_app_version text, max_app_version text, notes text,
  created_by uuid references cq_accounts(id), created_at timestamptz not null default now(),
  unique (kind, name)
);
create table if not exists cq_release_freezes (
  id uuid primary key default gen_random_uuid(),
  starts_at timestamptz not null, ends_at timestamptz not null check (ends_at > starts_at),
  reason text not null, created_by uuid references cq_accounts(id), created_at timestamptz not null default now()
);
create table if not exists cq_kill_requests (
  id uuid primary key default gen_random_uuid(),
  version text not null,                                   -- '*' = every version, or an exact app version
  wipe boolean not null default false,
  lock_message text, reason text not null check (char_length(reason) >= 5),
  countdown_minutes int not null default 0 check (countdown_minutes between 0 and 1440),
  status text not null default 'pending' check (status in ('pending','approved','executed','cancelled','expired')),
  requested_by uuid not null references cq_accounts(id), requested_at timestamptz not null default now(),
  approved_by uuid references cq_accounts(id), approved_at timestamptz, execute_after timestamptz,
  executed_at timestamptz, cancelled_by uuid references cq_accounts(id), cancelled_at timestamptz, cancel_reason text
);
alter table cq_model_artifacts enable row level security;
alter table cq_release_freezes enable row level security;
alter table cq_kill_requests enable row level security;

-- 2. Internal helpers (not callable through the API) -----------------------------------------------------------
-- Writes a kill/lock into cq_release_config. A new exact-version row starts as a copy of '*' so it keeps the model links.
create or replace function cq_apply_lock(a cq_accounts, p_version text, p_wipe boolean, p_message text) returns void
language plpgsql security definer set search_path = public, extensions as $$
begin
  insert into cq_release_config(version, lucy_model_name, lucy_model_url, lucy_model_sha256, lucy_model_bytes,
         voice_model_name, voice_model_url, voice_model_sha256, voice_model_bytes, min_app_version, offline_grace_days)
    select p_version, lucy_model_name, lucy_model_url, lucy_model_sha256, lucy_model_bytes,
           voice_model_name, voice_model_url, voice_model_sha256, voice_model_bytes, min_app_version, offline_grace_days
    from cq_release_config where version = '*'
  on conflict (version) do nothing;
  insert into cq_release_config(version) values (p_version) on conflict (version) do nothing;  -- only if no '*' row existed
  update cq_release_config set locked = true, wipe_on_lock = p_wipe,
         lock_message = coalesce(nullif(p_message, ''), lock_message), updated_by = a.id, updated_at = now()
   where version = p_version;
end $$;

create or replace function cq_in_freeze() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from cq_release_freezes where now() between starts_at and ends_at) $$;

-- Marks stale pending/approved requests as expired. Pending lasts 24 h; an approved request that was never executed lasts 24 h past its time.
create or replace function cq_expire_kills() returns void language sql security definer set search_path = public as $$
  update cq_kill_requests set status = 'expired'
   where (status = 'pending' and requested_at < now() - interval '24 hours')
      or (status = 'approved' and execute_after < now() - interval '24 hours') $$;

revoke execute on function cq_apply_lock(cq_accounts, text, boolean, text), cq_in_freeze(), cq_expire_kills() from public, anon, authenticated;

-- 3. Overview (one call for the whole screen) ---------------------------------------------------------------------
create or replace function cq_hq_release_overview(p_token text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts;
begin
  a := cq_staff(p_token, array['release_manager','product_manager','network_maint','analyst','security']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  perform cq_expire_kills();
  return jsonb_build_object('ok', true, 'viewer', jsonb_build_object('id', a.id, 'role', a.role), 'frozen', cq_in_freeze(),
    'products', (select coalesce(jsonb_agg(jsonb_build_object('slug', p.slug, 'name', p.name_en, 'stage', p.stage) order by p.card_order), '[]') from cq_products p),
    'releases', (select coalesce(jsonb_agg(to_jsonb(r) order by r.created_at desc), '[]') from (
        select r.id, p.slug, r.channel, r.version_name, r.platform, r.file_path, r.sha256, r.size_bytes, r.min_os, r.notes_en, r.notes_sw,
               r.rollout_pct, r.status, r.live_at, r.halted_at, r.halt_reason, r.rolled_back_at, r.rollback_reason, r.created_at
        from cq_product_releases r join cq_products p on p.id = r.product_id order by r.created_at desc limit 200) r),
    'models', (select coalesce(jsonb_agg(to_jsonb(m) - 'created_by' order by m.created_at desc), '[]') from cq_model_artifacts m),
    'config', (select coalesce(jsonb_agg(to_jsonb(c) - 'updated_by' order by c.version), '[]') from cq_release_config c),
    'freezes', (select coalesce(jsonb_agg(to_jsonb(f) - 'created_by' order by f.starts_at desc), '[]')
                from (select * from cq_release_freezes where ends_at > now() - interval '30 days' order by starts_at desc limit 50) f),
    'kills', (select coalesce(jsonb_agg(x order by x.requested_at desc), '[]') from (
        select k.id, k.version, k.wipe, k.lock_message, k.reason, k.countdown_minutes, k.status, k.requested_at, k.approved_at, k.execute_after,
               k.executed_at, k.cancelled_at, k.cancel_reason, k.requested_by, k.approved_by,
               coalesce(rq.name, rq.role) as requested_by_name, coalesce(ap.name, ap.role) as approved_by_name
        from cq_kill_requests k join cq_accounts rq on rq.id = k.requested_by left join cq_accounts ap on ap.id = k.approved_by
        order by k.requested_at desc limit 30) x));
end $$;

-- 4. Builds and staged rollout ------------------------------------------------------------------------------------------
create or replace function cq_hq_rel_create(p_token text, p_slug text, p_channel text, p_version text, p_platform text, p_file_path text,
  p_sha256 text, p_size_bytes bigint, p_min_os text, p_notes_en text, p_notes_sw text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; pid uuid; rid uuid;
begin
  a := cq_staff(p_token, array['release_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  if p_channel not in ('alpha','beta','stable') then return jsonb_build_object('ok', false, 'error', 'bad_channel'); end if;
  if p_version is null or p_version !~ '^[0-9]+\.[0-9]+\.[0-9]+([-.][0-9A-Za-z.]+)?$' then return jsonb_build_object('ok', false, 'error', 'bad_version'); end if;
  if coalesce(p_platform, 'android') not in ('android','ios','web') then return jsonb_build_object('ok', false, 'error', 'bad_platform'); end if;
  if p_sha256 is not null and p_sha256 !~ '^[0-9a-f]{64}$' then return jsonb_build_object('ok', false, 'error', 'bad_sha256'); end if;
  if p_size_bytes is not null and p_size_bytes <= 0 then return jsonb_build_object('ok', false, 'error', 'bad_size'); end if;
  select id into pid from cq_products where slug = p_slug;
  if pid is null then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  begin
    insert into cq_product_releases(product_id, channel, version_name, platform, file_path, sha256, size_bytes, min_os, notes_en, notes_sw, created_by)
    values (pid, p_channel, p_version, coalesce(p_platform,'android'), nullif(p_file_path,''), p_sha256, p_size_bytes, nullif(p_min_os,''),
            left(p_notes_en, 4000), left(p_notes_sw, 4000), a.id) returning id into rid;
  exception when unique_violation then return jsonb_build_object('ok', false, 'error', 'duplicate_build');
  end;
  perform cq_log(a, 'rel_create', jsonb_build_object('slug', p_slug, 'channel', p_channel, 'version', p_version, 'sha256', p_sha256));
  return jsonb_build_object('ok', true, 'id', rid);
end $$;

-- Raise the rollout to 1, 5, 25, 50 or 100. Only upwards. First raise makes the build live. Needs a SHA-256. Blocked in a freeze window.
create or replace function cq_hq_rel_set_rollout(p_token text, p_release_id uuid, p_pct int) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; r cq_product_releases; slug_ text;
begin
  a := cq_staff(p_token, array['release_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  if p_pct is null or p_pct not in (1,5,25,50,100) then return jsonb_build_object('ok', false, 'error', 'bad_pct'); end if;
  select * into r from cq_product_releases where id = p_release_id for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  if r.status in ('halted','rolled_back') then return jsonb_build_object('ok', false, 'error', 'not_live'); end if;
  if r.sha256 is null then return jsonb_build_object('ok', false, 'error', 'needs_sha256'); end if;
  if p_pct <= r.rollout_pct then return jsonb_build_object('ok', false, 'error', 'only_upwards'); end if;
  if cq_in_freeze() then return jsonb_build_object('ok', false, 'error', 'freeze_window'); end if;
  update cq_product_releases set rollout_pct = p_pct, status = 'live', live_at = coalesce(live_at, now()), updated_at = now() where id = r.id;
  select slug into slug_ from cq_products where id = r.product_id;
  perform cq_log(a, 'rel_rollout', jsonb_build_object('slug', slug_, 'version', r.version_name, 'channel', r.channel, 'from', r.rollout_pct, 'to', p_pct));
  return jsonb_build_object('ok', true);
end $$;

-- Halt, resume and rollback are never blocked by a freeze: they are the safety valves.
create or replace function cq_hq_rel_halt(p_token text, p_release_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; r cq_product_releases; slug_ text;
begin
  a := cq_staff(p_token, array['release_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  if p_reason is null or char_length(trim(p_reason)) < 5 then return jsonb_build_object('ok', false, 'error', 'reason_required'); end if;
  select * into r from cq_product_releases where id = p_release_id for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  if r.status <> 'live' then return jsonb_build_object('ok', false, 'error', 'not_live'); end if;
  update cq_product_releases set status = 'halted', halted_at = now(), halt_reason = left(trim(p_reason), 500), updated_at = now() where id = r.id;
  select slug into slug_ from cq_products where id = r.product_id;
  perform cq_log(a, 'rel_halt', jsonb_build_object('slug', slug_, 'version', r.version_name, 'at_pct', r.rollout_pct, 'reason', left(p_reason, 200)));
  return jsonb_build_object('ok', true);
end $$;

create or replace function cq_hq_rel_resume(p_token text, p_release_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; r cq_product_releases; slug_ text;
begin
  a := cq_staff(p_token, array['release_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  if p_reason is null or char_length(trim(p_reason)) < 5 then return jsonb_build_object('ok', false, 'error', 'reason_required'); end if;
  select * into r from cq_product_releases where id = p_release_id for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  if r.status <> 'halted' then return jsonb_build_object('ok', false, 'error', 'not_halted'); end if;
  update cq_product_releases set status = 'live', halted_at = null, updated_at = now() where id = r.id;
  select slug into slug_ from cq_products where id = r.product_id;
  perform cq_log(a, 'rel_resume', jsonb_build_object('slug', slug_, 'version', r.version_name, 'reason', left(p_reason, 200)));
  return jsonb_build_object('ok', true);
end $$;

-- Rollback withdraws this build (rollout 0). The previous live build for the same product, channel and platform keeps serving.
-- If there is none, the result says so: phones simply stop being offered an update.
create or replace function cq_hq_rel_rollback(p_token text, p_release_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; r cq_product_releases; slug_ text; fb record;
begin
  a := cq_staff(p_token, array['release_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  if p_reason is null or char_length(trim(p_reason)) < 5 then return jsonb_build_object('ok', false, 'error', 'reason_required'); end if;
  select * into r from cq_product_releases where id = p_release_id for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  if r.status not in ('live','halted') then return jsonb_build_object('ok', false, 'error', 'not_live'); end if;
  update cq_product_releases set status = 'rolled_back', rollout_pct = 0, rolled_back_at = now(), rollback_reason = left(trim(p_reason), 500), updated_at = now() where id = r.id;
  select slug into slug_ from cq_products where id = r.product_id;
  select version_name, rollout_pct into fb from cq_product_releases
    where product_id = r.product_id and channel = r.channel and platform = r.platform and id <> r.id and status = 'live' and live_at is not null
    order by live_at desc limit 1;
  perform cq_log(a, 'rel_rollback', jsonb_build_object('slug', slug_, 'version', r.version_name, 'channel', r.channel, 'reason', left(p_reason, 200), 'fallback', fb.version_name));
  return jsonb_build_object('ok', true, 'fallback_version', fb.version_name, 'fallback_pct', fb.rollout_pct);
end $$;

-- 5. Phone-facing update offer (additive; cq_get_config is untouched) -----------------------------------------------------
-- A device is placed in a stable bucket 0..99 from its id. It is offered the newest live build whose rollout covers its bucket.
create or replace function cq_get_update(p_app_version text, p_device_id text, p_slug text default 'nia-cds', p_channel text default 'stable', p_platform text default 'android') returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare bucket int; r record;
begin
  if not cq_rl('upd:ip:' || cq_client_ip(), 600, interval '1 hour') then return jsonb_build_object('ok', false, 'error', 'rate_limited'); end if;
  if p_device_id is null or char_length(p_device_id) < 6 or char_length(p_device_id) > 100 or p_channel not in ('alpha','beta','stable') then
    return jsonb_build_object('ok', false, 'error', 'bad_request'); end if;
  bucket := abs(('x' || substr(encode(digest(p_device_id, 'sha256'), 'hex'), 1, 7))::bit(28)::int) % 100;
  select r2.version_name, r2.sha256, r2.size_bytes, r2.min_os, r2.notes_en, r2.notes_sw, r2.file_path, r2.rollout_pct into r
    from cq_product_releases r2 join cq_products p on p.id = r2.product_id
   where p.slug = p_slug and r2.channel = p_channel and r2.platform = p_platform and r2.status = 'live' and r2.sha256 is not null
     and bucket < r2.rollout_pct and cq_ver_num(r2.version_name) > cq_ver_num(coalesce(p_app_version, '0.0.0'))
   order by cq_ver_num(r2.version_name) desc limit 1;
  if r.version_name is null then return jsonb_build_object('ok', true, 'update', null); end if;
  return jsonb_build_object('ok', true, 'update', jsonb_build_object('version', r.version_name, 'sha256', r.sha256, 'size_bytes', r.size_bytes,
    'min_os', r.min_os, 'notes_en', r.notes_en, 'notes_sw', r.notes_sw, 'file_path', r.file_path));
end $$;

-- 6. Policy (C4): minimum version, grace days, lock message. Locking itself is only through the kill switch. -------------------------
create or replace function cq_hq_rel_set_policy(p_token text, p_version text, p_min_app_version text, p_offline_grace_days int, p_lock_message text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; newest text;
begin
  a := cq_staff(p_token, array['release_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  if not exists (select 1 from cq_release_config where version = p_version) then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  if p_offline_grace_days is not null and p_offline_grace_days not between 1 and 365 then return jsonb_build_object('ok', false, 'error', 'bad_value'); end if;
  if p_min_app_version is not null and p_min_app_version <> '' then
    if p_min_app_version !~ '^[0-9]+\.[0-9]+\.[0-9]+$' then return jsonb_build_object('ok', false, 'error', 'bad_version'); end if;
    -- Refuse a minimum above every live stable build: that would lock out all phones with nothing to update to.
    select version_name into newest from cq_product_releases where channel = 'stable' and status = 'live' and rollout_pct = 100
      order by cq_ver_num(version_name) desc limit 1;
    if newest is null or cq_ver_num(p_min_app_version) > cq_ver_num(newest) then return jsonb_build_object('ok', false, 'error', 'min_above_live'); end if;
  end if;
  update cq_release_config set
    min_app_version = case when p_min_app_version is null then min_app_version else nullif(p_min_app_version, '') end,
    offline_grace_days = coalesce(p_offline_grace_days, offline_grace_days),
    lock_message = case when p_lock_message is null then lock_message else left(nullif(trim(p_lock_message), ''), 300) end,
    updated_by = a.id, updated_at = now()
  where version = p_version;
  perform cq_log(a, 'rel_policy', jsonb_build_object('version', p_version, 'min_app_version', p_min_app_version, 'grace_days', p_offline_grace_days));
  return jsonb_build_object('ok', true);
end $$;

-- 7. Model artifact registry (C6) -------------------------------------------------------------------------------------------------
create or replace function cq_hq_model_register(p_token text, p_kind text, p_name text, p_url text, p_sha256 text, p_bytes bigint,
  p_min_app text, p_max_app text, p_notes text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; mid uuid;
begin
  a := cq_staff(p_token, array['release_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  if p_kind not in ('lucy','voice') or coalesce(trim(p_name), '') = '' then return jsonb_build_object('ok', false, 'error', 'bad_value'); end if;
  if p_url is null or p_url !~ '^https://' then return jsonb_build_object('ok', false, 'error', 'bad_url'); end if;
  if p_sha256 is null or p_sha256 !~ '^[0-9a-f]{64}$' then return jsonb_build_object('ok', false, 'error', 'bad_sha256'); end if;
  if p_bytes is null or p_bytes <= 0 then return jsonb_build_object('ok', false, 'error', 'bad_size'); end if;
  begin
    insert into cq_model_artifacts(kind, name, url, sha256, bytes, min_app_version, max_app_version, notes, created_by)
    values (p_kind, trim(p_name), p_url, p_sha256, p_bytes, nullif(p_min_app,''), nullif(p_max_app,''), left(p_notes, 1000), a.id) returning id into mid;
  exception when unique_violation then return jsonb_build_object('ok', false, 'error', 'duplicate_model'); end;
  perform cq_log(a, 'model_register', jsonb_build_object('kind', p_kind, 'name', p_name, 'sha256', p_sha256));
  return jsonb_build_object('ok', true, 'id', mid);
end $$;

-- Point a config row at a registered model. This is what phones download next, so it is audited with the hash.
create or replace function cq_hq_model_activate(p_token text, p_model_id uuid, p_version text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; m cq_model_artifacts;
begin
  a := cq_staff(p_token, array['release_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  select * into m from cq_model_artifacts where id = p_model_id;
  if not found or not exists (select 1 from cq_release_config where version = p_version) then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  if m.kind = 'lucy' then
    update cq_release_config set lucy_model_name = m.name, lucy_model_url = m.url, lucy_model_sha256 = m.sha256, lucy_model_bytes = m.bytes, updated_by = a.id, updated_at = now() where version = p_version;
  else
    update cq_release_config set voice_model_name = m.name, voice_model_url = m.url, voice_model_sha256 = m.sha256, voice_model_bytes = m.bytes, updated_by = a.id, updated_at = now() where version = p_version;
  end if;
  perform cq_log(a, 'model_activate', jsonb_build_object('version', p_version, 'kind', m.kind, 'name', m.name, 'sha256', m.sha256));
  return jsonb_build_object('ok', true);
end $$;

-- 8. Freeze windows (C7) ----------------------------------------------------------------------------------------------------------
create or replace function cq_hq_freeze_add(p_token text, p_starts timestamptz, p_ends timestamptz, p_reason text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts;
begin
  a := cq_staff(p_token, array['release_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  if p_starts is null or p_ends is null or p_ends <= p_starts or p_ends > p_starts + interval '60 days' then return jsonb_build_object('ok', false, 'error', 'bad_value'); end if;
  if p_reason is null or char_length(trim(p_reason)) < 3 then return jsonb_build_object('ok', false, 'error', 'reason_required'); end if;
  insert into cq_release_freezes(starts_at, ends_at, reason, created_by) values (p_starts, p_ends, left(trim(p_reason), 300), a.id);
  perform cq_log(a, 'freeze_add', jsonb_build_object('starts', p_starts, 'ends', p_ends, 'reason', left(p_reason, 200)));
  return jsonb_build_object('ok', true);
end $$;

create or replace function cq_hq_freeze_remove(p_token text, p_id uuid) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts;
begin
  a := cq_staff(p_token, array['release_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  delete from cq_release_freezes where id = p_id;
  if not found then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  perform cq_log(a, 'freeze_remove', jsonb_build_object('id', p_id));
  return jsonb_build_object('ok', true);
end $$;

-- 9. Kill switch (C5) ---------------------------------------------------------------------------------------------------------------------
-- No wipe: one person, takes effect now. Wipe: needs a different person to approve, then a countdown (at least 5 minutes) that either may cancel.
create or replace function cq_hq_kill_request(p_token text, p_version text, p_wipe boolean, p_message text, p_reason text, p_countdown_min int) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; kid uuid; wipe_ boolean := coalesce(p_wipe, false);
begin
  a := cq_staff(p_token, array['release_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  if not cq_rl('kill:' || a.id::text, 10, interval '1 hour') then return jsonb_build_object('ok', false, 'error', 'rate_limited'); end if;
  if p_reason is null or char_length(trim(p_reason)) < 5 then return jsonb_build_object('ok', false, 'error', 'reason_required'); end if;
  if p_version is null or (p_version <> '*' and p_version !~ '^[0-9]+\.[0-9]+\.[0-9]+$') then return jsonb_build_object('ok', false, 'error', 'bad_version'); end if;
  perform cq_expire_kills();
  if exists (select 1 from cq_kill_requests where version = p_version and status in ('pending','approved')) then
    return jsonb_build_object('ok', false, 'error', 'request_open'); end if;
  if wipe_ then
    if coalesce(p_countdown_min, 0) < 5 or p_countdown_min > 1440 then return jsonb_build_object('ok', false, 'error', 'bad_countdown'); end if;
    insert into cq_kill_requests(version, wipe, lock_message, reason, countdown_minutes, requested_by)
      values (p_version, true, left(p_message, 300), left(trim(p_reason), 500), p_countdown_min, a.id) returning id into kid;
    perform cq_log(a, 'kill_request', jsonb_build_object('id', kid, 'version', p_version, 'wipe', true, 'countdown_min', p_countdown_min, 'reason', left(p_reason, 200)));
    return jsonb_build_object('ok', true, 'id', kid, 'status', 'pending');
  end if;
  insert into cq_kill_requests(version, wipe, lock_message, reason, countdown_minutes, requested_by, status, approved_by, approved_at, execute_after, executed_at)
    values (p_version, false, left(p_message, 300), left(trim(p_reason), 500), 0, a.id, 'executed', null, null, now(), now()) returning id into kid;
  perform cq_apply_lock(a, p_version, false, p_message);
  perform cq_log(a, 'kill_lock', jsonb_build_object('id', kid, 'version', p_version, 'wipe', false, 'reason', left(p_reason, 200)));
  return jsonb_build_object('ok', true, 'id', kid, 'status', 'executed');
end $$;

create or replace function cq_hq_kill_approve(p_token text, p_id uuid) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; k cq_kill_requests;
begin
  a := cq_staff(p_token, array['release_manager']);   -- master is allowed by cq_staff default
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  perform cq_expire_kills();
  select * into k from cq_kill_requests where id = p_id for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  if k.status <> 'pending' then return jsonb_build_object('ok', false, 'error', 'not_pending'); end if;
  if k.requested_by = a.id then return jsonb_build_object('ok', false, 'error', 'same_person'); end if;
  update cq_kill_requests set status = 'approved', approved_by = a.id, approved_at = now(),
         execute_after = now() + make_interval(mins => k.countdown_minutes) where id = k.id;
  perform cq_log(a, 'kill_approve', jsonb_build_object('id', k.id, 'version', k.version, 'wipe', k.wipe, 'requested_by', k.requested_by));
  return jsonb_build_object('ok', true, 'execute_after', now() + make_interval(mins => k.countdown_minutes));
end $$;

-- Runs once the countdown has passed. Either person (or any release manager) may press it; the console offers it, and the optional job below calls it.
create or replace function cq_hq_kill_execute(p_token text, p_id uuid) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; k cq_kill_requests;
begin
  a := cq_staff(p_token, array['release_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  perform cq_expire_kills();
  select * into k from cq_kill_requests where id = p_id for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  if k.status <> 'approved' then return jsonb_build_object('ok', false, 'error', 'not_approved'); end if;
  if now() < k.execute_after then return jsonb_build_object('ok', false, 'error', 'countdown_running', 'execute_after', k.execute_after); end if;
  perform cq_apply_lock(a, k.version, k.wipe, k.lock_message);
  update cq_kill_requests set status = 'executed', executed_at = now() where id = k.id;
  perform cq_log(a, 'kill_execute', jsonb_build_object('id', k.id, 'version', k.version, 'wipe', k.wipe));
  return jsonb_build_object('ok', true);
end $$;

create or replace function cq_hq_kill_cancel(p_token text, p_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts; k cq_kill_requests;
begin
  a := cq_staff(p_token, array['release_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  if p_reason is null or char_length(trim(p_reason)) < 5 then return jsonb_build_object('ok', false, 'error', 'reason_required'); end if;
  select * into k from cq_kill_requests where id = p_id for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  if k.status not in ('pending','approved') then return jsonb_build_object('ok', false, 'error', 'not_cancellable'); end if;
  update cq_kill_requests set status = 'cancelled', cancelled_by = a.id, cancelled_at = now(), cancel_reason = left(trim(p_reason), 500) where id = k.id;
  perform cq_log(a, 'kill_cancel', jsonb_build_object('id', k.id, 'version', k.version, 'reason', left(p_reason, 200)));
  return jsonb_build_object('ok', true);
end $$;

-- Lift a lock. Data already wiped from phones is not restored by this.
create or replace function cq_hq_unlock(p_token text, p_version text, p_reason text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts;
begin
  a := cq_staff(p_token, array['release_manager']);
  if a.id is null then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  if p_reason is null or char_length(trim(p_reason)) < 5 then return jsonb_build_object('ok', false, 'error', 'reason_required'); end if;
  update cq_release_config set locked = false, wipe_on_lock = false, updated_by = a.id, updated_at = now() where version = p_version and locked;
  if not found then return jsonb_build_object('ok', false, 'error', 'not_locked'); end if;
  perform cq_log(a, 'unlock', jsonb_build_object('version', p_version, 'reason', left(p_reason, 200)));
  return jsonb_build_object('ok', true);
end $$;

-- 10. Optional: apply approved kills automatically once their countdown ends (needs the pg_cron extension, which Supabase offers) ----------------
-- Runs as the database owner, so it does not use a token; it only executes requests that two people already approved.
create or replace function cq_apply_due_kills() returns int language plpgsql security definer set search_path = public, extensions as $$
declare k cq_kill_requests; n int := 0; sys cq_accounts;
begin
  perform cq_expire_kills();
  for k in select * from cq_kill_requests where status = 'approved' and now() >= execute_after for update skip locked loop
    select * into sys from cq_accounts where id = k.approved_by;
    perform cq_apply_lock(sys, k.version, k.wipe, k.lock_message);
    update cq_kill_requests set status = 'executed', executed_at = now() where id = k.id;
    insert into cq_audit(actor, role, action, detail) values (k.approved_by, 'system', 'kill_execute', jsonb_build_object('id', k.id, 'version', k.version, 'wipe', k.wipe, 'by', 'scheduler'));
    n := n + 1;
  end loop;
  return n;
end $$;
revoke execute on function cq_apply_due_kills() from public, anon, authenticated;
do $$ begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    perform cron.schedule('cq_apply_due_kills', '* * * * *', 'select cq_apply_due_kills()');
  end if;
end $$;

-- 10b. Close a bypass: cq_hq_set_config (0002) let a master set locked / wipe_on_lock directly, skipping two-person approval.
-- Same function, same arguments; it now refuses patches that touch those two fields. Locking goes through cq_hq_kill_request.
create or replace function cq_hq_set_config(p_token text, p_version text, p_patch jsonb) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare a cq_accounts;
begin
  a := cq_session_account(p_token);
  if a.id is null or a.role <> 'master' then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  if p_patch ? 'locked' or p_patch ? 'wipe_on_lock' then return jsonb_build_object('ok', false, 'error', 'use_kill_switch'); end if;
  insert into cq_release_config(version, lucy_model_name, lucy_model_url, lucy_model_sha256, lucy_model_bytes,
         voice_model_name, voice_model_url, voice_model_sha256, voice_model_bytes, min_app_version, offline_grace_days)
    select p_version, lucy_model_name, lucy_model_url, lucy_model_sha256, lucy_model_bytes,
           voice_model_name, voice_model_url, voice_model_sha256, voice_model_bytes, min_app_version, offline_grace_days
    from cq_release_config where version = '*' on conflict (version) do nothing;
  insert into cq_release_config(version) values (p_version) on conflict do nothing;
  update cq_release_config set
    lucy_model_name = coalesce(p_patch->>'lucy_model_name', lucy_model_name),
    lucy_model_url = coalesce(p_patch->>'lucy_model_url', lucy_model_url),
    lucy_model_sha256 = coalesce(p_patch->>'lucy_model_sha256', lucy_model_sha256),
    lucy_model_bytes = coalesce((p_patch->>'lucy_model_bytes')::bigint, lucy_model_bytes),
    voice_model_name = coalesce(p_patch->>'voice_model_name', voice_model_name),
    voice_model_url = coalesce(p_patch->>'voice_model_url', voice_model_url),
    voice_model_sha256 = coalesce(p_patch->>'voice_model_sha256', voice_model_sha256),
    voice_model_bytes = coalesce((p_patch->>'voice_model_bytes')::bigint, voice_model_bytes),
    min_app_version = coalesce(p_patch->>'min_app_version', min_app_version),
    lock_message = coalesce(p_patch->>'lock_message', lock_message),
    offline_grace_days = coalesce((p_patch->>'offline_grace_days')::int, offline_grace_days),
    updated_by = a.id, updated_at = now()
  where version = p_version;
  perform cq_log(a, 'set_config', jsonb_build_object('version', p_version, 'patch', p_patch));
  return jsonb_build_object('ok', true);
end $$;

-- 11. Grants ----------------------------------------------------------------------------------------------------------------------------------
grant execute on function
  cq_hq_release_overview(text), cq_hq_rel_create(text, text, text, text, text, text, text, bigint, text, text, text),
  cq_hq_rel_set_rollout(text, uuid, int), cq_hq_rel_halt(text, uuid, text), cq_hq_rel_resume(text, uuid, text), cq_hq_rel_rollback(text, uuid, text),
  cq_get_update(text, text, text, text, text), cq_hq_rel_set_policy(text, text, text, int, text),
  cq_hq_model_register(text, text, text, text, text, bigint, text, text, text), cq_hq_model_activate(text, uuid, text),
  cq_hq_freeze_add(text, timestamptz, timestamptz, text), cq_hq_freeze_remove(text, uuid),
  cq_hq_kill_request(text, text, boolean, text, text, int), cq_hq_kill_approve(text, uuid), cq_hq_kill_execute(text, uuid),
  cq_hq_kill_cancel(text, uuid, text), cq_hq_unlock(text, text, text)
  to anon, authenticated;

commit;
