-- smoke_0008.sql: behaviour test for 0008 (and the 0009 catalog function) on a scratch PostgreSQL. NOT for production data.
-- Needs roles anon/authenticated and migrations 0001-0009. Creates rows prefixed zz_, then removes them.
-- Written without a database to run it on: expect to fix small mistakes on the first run.
\set ON_ERROR_STOP on
create or replace function zz_assert(c boolean, msg text) returns void language plpgsql as $$
begin if c is not true then raise exception 'ASSERT FAILED: %', msg; end if; end $$;
grant execute on function zz_assert(boolean, text) to anon;
create or replace function zz_err(j jsonb) returns text language sql immutable as $$ select coalesce(j->>'error', 'ok') $$;
grant execute on function zz_err(jsonb) to anon;
create or replace function zz_rid(v text) returns uuid language sql security definer as $$
  select r.id from cq_product_releases r join cq_products p on p.id = r.product_id where p.slug = 'zz-prod' and r.version_name = v limit 1 $$;
grant execute on function zz_rid(text) to anon;
create or replace function zz_kid(v text) returns uuid language sql security definer as $$
  select id from cq_kill_requests where version = v order by requested_at desc limit 1 $$;
grant execute on function zz_kid(text) to anon;

-- clean leftovers ------------------------------------------------------------------------------------------------------
delete from cq_kill_requests where version in ('9.9.9','9.9.8');
delete from cq_release_config where version in ('9.9.9','9.9.8');
delete from cq_release_freezes where reason like 'zz%';
delete from cq_model_artifacts where name like 'zz-%';
delete from cq_products where slug = 'zz-prod';
delete from cq_rate_limit where k like 'kill:%' or k like 'upd:%';

-- seed (owner) ---------------------------------------------------------------------------------------------------------
insert into cq_accounts(email, pw_hash, role, name) values
 ('zz_master@t.test','x','master','ZZ Master'), ('zz_rm1@t.test','x','release_manager','ZZ RM One'),
 ('zz_rm2@t.test','x','release_manager','ZZ RM Two'), ('zz_an@t.test','x','analyst','ZZ Analyst'), ('zz_sup@t.test','x','support','ZZ Support')
 on conflict (email) do update set status = 'verified';
insert into cq_sessions(token_hash, account_id)
  select encode(digest('tok_' || split_part(email,'@',1),'sha256'),'hex'), id from cq_accounts where email like 'zz\_%'
  on conflict (token_hash) do update set expires_at = now() + interval '1 day';
insert into cq_release_config(version, offline_grace_days) values ('*', 30) on conflict (version) do nothing;
insert into cq_products(slug, name_en, stage) values ('zz-prod', 'ZZ Product', 'closed_beta');

set role anon;
do $$ declare j jsonb; rid uuid; n int; hits int := 0; d text; begin
  -- permissions -----------------------------------------------------------------------------------------------------------
  perform zz_assert(zz_err(cq_hq_release_overview('tok_zz_sup')) = 'forbidden', 'support cannot see releases');
  perform zz_assert(zz_err(cq_hq_release_overview('tok_zz_an')) = 'ok', 'analyst can view');
  perform zz_assert(zz_err(cq_hq_rel_create('tok_zz_an','zz-prod','stable','1.0.0','android',null,null,null,null,null,null)) = 'forbidden', 'analyst cannot create');
  perform zz_assert(zz_err(cq_hq_release_overview('nonsense')) = 'forbidden', 'bad token');

  -- builds ------------------------------------------------------------------------------------------------------------------
  perform zz_assert(zz_err(cq_hq_rel_create('tok_zz_rm1','zz-prod','stable','1.0','android',null,null,null,null,null,null)) = 'bad_version', 'version format');
  perform zz_assert(zz_err(cq_hq_rel_create('tok_zz_rm1','zz-prod','stable','1.0.0','android',null,'XYZ',null,null,null,null)) = 'bad_sha256', 'sha format');
  perform zz_assert(zz_err(cq_hq_rel_create('tok_zz_rm1','nope','stable','1.0.0','android',null,null,null,null,null,null)) = 'not_found', 'unknown product');
  perform zz_assert(zz_err(cq_hq_rel_create('tok_zz_rm1','zz-prod','stable','0.9.0','android','/b/0.9.0.apk',repeat('a',64),1000,null,null,null)) = 'ok', 'create 0.9.0');
  perform zz_assert(zz_err(cq_hq_rel_create('tok_zz_rm1','zz-prod','stable','0.9.0','android',null,null,null,null,null,null)) = 'duplicate_build', 'duplicate build');
  perform zz_assert(zz_err(cq_hq_rel_create('tok_zz_rm1','zz-prod','stable','1.0.0','android',null,null,null,null,null,null)) = 'ok', 'create 1.0.0 without hash');
  perform zz_assert(zz_err(cq_hq_rel_create('tok_zz_rm1','zz-prod','stable','1.1.0','android','/b/1.1.0.apk',repeat('b',64),2000,null,null,null)) = 'ok', 'create 1.1.0');

  -- rollout -----------------------------------------------------------------------------------------------------------------
  perform zz_assert(zz_err(cq_hq_rel_set_rollout('tok_zz_rm1', zz_rid('1.0.0'), 5)) = 'needs_sha256', 'no hash, no go-live');
  perform zz_assert(zz_err(cq_hq_rel_set_rollout('tok_zz_rm1', zz_rid('0.9.0'), 7)) = 'bad_pct', 'bad step');
  perform zz_assert(zz_err(cq_hq_rel_set_rollout('tok_zz_rm1', zz_rid('0.9.0'), 100)) = 'ok', '0.9.0 to 100');
  perform zz_assert(zz_err(cq_hq_rel_set_rollout('tok_zz_rm1', zz_rid('0.9.0'), 50)) = 'only_upwards', 'no decrease');
  perform zz_assert(zz_err(cq_hq_rel_set_rollout('tok_zz_rm1', zz_rid('1.1.0'), 5)) = 'ok', '1.1.0 to 5');

  -- phone update offer ----------------------------------------------------------------------------------------------------------
  j := cq_get_update('0.9.0', 'zz_device_000001');
  perform zz_assert(j->>'ok' = 'true', 'update call ok');
  for n in 1..200 loop
    j := cq_get_update('0.9.0', 'zz_dev_' || n || '_abcdef');
    if j->'update' is not null and j->'update' <> 'null'::jsonb then hits := hits + 1; end if;
  end loop;
  perform zz_assert(hits between 1 and 30, 'about 5 percent of 200 devices are offered 1.1.0 (got ' || hits || ')');
  perform zz_assert(coalesce(cq_get_update('1.1.0', 'zz_device_000001')->'update', 'null'::jsonb) = 'null'::jsonb, 'already current: no offer');
  perform zz_assert(cq_get_update('0.9.0', 'ab')->>'error' = 'bad_request', 'short device id rejected');

  -- freeze --------------------------------------------------------------------------------------------------------------------------
  perform zz_assert(zz_err(cq_hq_freeze_add('tok_zz_rm1', now() - interval '1 hour', now() + interval '1 hour', 'zz freeze')) = 'ok', 'add freeze');
  perform zz_assert(zz_err(cq_hq_rel_set_rollout('tok_zz_rm1', zz_rid('1.1.0'), 25)) = 'freeze_window', 'freeze blocks raise');
  perform zz_assert(zz_err(cq_hq_rel_halt('tok_zz_rm1', zz_rid('1.1.0'), 'zz halt in freeze')) = 'ok', 'halt works in freeze');
  perform zz_assert(zz_err(cq_hq_rel_set_rollout('tok_zz_rm1', zz_rid('1.1.0'), 25)) = 'not_live', 'halted build cannot be raised');
  perform zz_assert(zz_err(cq_hq_rel_resume('tok_zz_rm1', zz_rid('1.1.0'), 'zz resume')) = 'ok', 'resume');
  for d in select (x->>'id') from jsonb_array_elements(cq_hq_release_overview('tok_zz_rm1')->'freezes') x where x->>'reason' like 'zz%' loop
    perform zz_assert(zz_err(cq_hq_freeze_remove('tok_zz_rm1', d::uuid)) = 'ok', 'remove freeze'); end loop;
  perform zz_assert(zz_err(cq_hq_rel_halt('tok_zz_rm1', zz_rid('1.1.0'), 'x')) = 'reason_required', 'reason length');

  -- rollback keeps the previous live build serving -----------------------------------------------------------------------------------
  perform zz_assert(zz_err(cq_hq_rel_set_rollout('tok_zz_rm1', zz_rid('1.1.0'), 100)) = 'ok', '1.1.0 to 100');
  j := cq_hq_rel_rollback('tok_zz_rm1', zz_rid('1.1.0'), 'zz bad build');
  perform zz_assert(j->>'ok' = 'true' and j->>'fallback_version' = '0.9.0', 'rollback names fallback 0.9.0, got ' || coalesce(j->>'fallback_version','null'));
  perform zz_assert(zz_err(cq_hq_rel_halt('tok_zz_rm1', zz_rid('1.1.0'), 'zz again')) = 'not_live', 'rolled back is final');

  -- policy -----------------------------------------------------------------------------------------------------------------------------
  perform zz_assert(zz_err(cq_hq_rel_set_policy('tok_zz_rm1', '*', '5.0.0', null, null)) = 'min_above_live', 'minimum above live build is refused');
  perform zz_assert(zz_err(cq_hq_rel_set_policy('tok_zz_rm1', '*', '0.9.0', 45, 'zz message')) = 'ok', 'policy saved');
  perform zz_assert(zz_err(cq_hq_rel_set_policy('tok_zz_rm1', '*', null, 0, null)) = 'bad_value', 'grace range');
  perform zz_assert(zz_err(cq_hq_rel_set_policy('tok_zz_rm1', '*', '', null, null)) = 'ok', 'minimum can be cleared');

  -- models -------------------------------------------------------------------------------------------------------------------------------
  perform zz_assert(zz_err(cq_hq_model_register('tok_zz_rm1','lucy','zz-lucy','http://x',repeat('c',64),10,null,null,null)) = 'bad_url', 'https only');
  perform zz_assert(zz_err(cq_hq_model_register('tok_zz_rm1','lucy','zz-lucy','https://x/m.gguf',repeat('c',64),10,null,null,null)) = 'ok', 'register model');
  perform zz_assert(zz_err(cq_hq_model_register('tok_zz_rm1','lucy','zz-lucy','https://x/m.gguf',repeat('c',64),10,null,null,null)) = 'duplicate_model', 'duplicate model');
  select id into rid from cq_model_artifacts where name = 'zz-lucy';
  perform zz_assert(zz_err(cq_hq_model_activate('tok_zz_rm1', rid, '*')) = 'ok', 'activate model');
end $$;

-- the activation really changed the config phones read (owner view)
reset role;
select zz_assert((select lucy_model_sha256 from cq_release_config where version = '*') = repeat('c',64), 'config now serves the registered model');
set role anon;

-- kill switch --------------------------------------------------------------------------------------------------------------------------------
do $$ declare j jsonb; kid uuid; begin
  perform zz_assert(zz_err(cq_hq_kill_request('tok_zz_rm1','9.9.9',false,'m','no',0)) = 'reason_required', 'reason needed');
  perform zz_assert(zz_err(cq_hq_kill_request('tok_zz_rm1','abc',false,'m','a good reason',0)) = 'bad_version', 'version format');
  perform zz_assert(zz_err(cq_hq_kill_request('tok_zz_an','9.9.9',false,'m','a good reason',0)) = 'forbidden', 'analyst cannot lock');
  -- lock without wipe: one person, immediate
  j := cq_hq_kill_request('tok_zz_rm1','9.9.9',false,'Update now','zz compromised build',0);
  perform zz_assert(j->>'status' = 'executed', 'plain lock executes at once');
  -- wipe: needs a second person and a countdown
  perform zz_assert(zz_err(cq_hq_kill_request('tok_zz_rm1','9.9.8',true,'m','zz lost device',2)) = 'bad_countdown', 'wipe countdown at least 5');
  j := cq_hq_kill_request('tok_zz_rm1','9.9.8',true,'Wiped','zz lost device',5);
  perform zz_assert(j->>'status' = 'pending', 'wipe request is pending');
  perform zz_assert(zz_err(cq_hq_kill_request('tok_zz_rm2','9.9.8',true,'m','zz duplicate',5)) = 'request_open', 'one open request per version');
  kid := zz_kid('9.9.8');
  perform zz_assert(zz_err(cq_hq_kill_approve('tok_zz_rm1', kid)) = 'same_person', 'requester cannot approve');
  perform zz_assert(zz_err(cq_hq_kill_execute('tok_zz_rm2', kid)) = 'not_approved', 'cannot run before approval');
  perform zz_assert(zz_err(cq_hq_kill_approve('tok_zz_an', kid)) = 'forbidden', 'analyst cannot approve');
  perform zz_assert(zz_err(cq_hq_kill_approve('tok_zz_rm2', kid)) = 'ok', 'second person approves');
  perform zz_assert(zz_err(cq_hq_kill_execute('tok_zz_rm2', kid)) = 'countdown_running', 'countdown protects');
end $$;
reset role;
select zz_assert((select locked and not wipe_on_lock from cq_release_config where version = '9.9.9'), 'plain lock written, no wipe');
select zz_assert((select lucy_model_sha256 from cq_release_config where version = '9.9.9') = repeat('c',64), 'new version row copied the model links from *');
select zz_assert(not (select locked from cq_release_config where version = '9.9.8'), 'wipe not applied before the countdown ends');
update cq_kill_requests set execute_after = now() - interval '1 minute' where version = '9.9.8';
set role anon;
do $$ declare kid uuid := zz_kid('9.9.8'); begin
  perform zz_assert(zz_err(cq_hq_kill_execute('tok_zz_master', kid)) = 'ok', 'execute after countdown');
  perform zz_assert(zz_err(cq_hq_kill_cancel('tok_zz_rm1', kid, 'too late')) = 'not_cancellable', 'executed request cannot be cancelled');
  perform zz_assert(zz_err(cq_hq_unlock('tok_zz_rm2', '9.9.8', 'zz found the phone')) = 'ok', 'unlock');
  perform zz_assert(zz_err(cq_hq_unlock('tok_zz_rm2', '9.9.8', 'zz again')) = 'not_locked', 'unlock twice');
  -- the old bypass is closed
  perform zz_assert(zz_err(cq_hq_set_config('tok_zz_master', '9.9.8', '{"locked": true}'::jsonb)) = 'use_kill_switch', 'set_config cannot lock');
  perform zz_assert(zz_err(cq_hq_set_config('tok_zz_master', '9.9.8', '{"wipe_on_lock": true}'::jsonb)) = 'use_kill_switch', 'set_config cannot wipe');
  perform zz_assert(zz_err(cq_hq_set_config('tok_zz_master', '9.9.8', '{"offline_grace_days": 20}'::jsonb)) = 'ok', 'set_config still works for other fields');
  -- cancel path
  perform zz_assert(zz_err(cq_hq_kill_request('tok_zz_rm1','9.9.8',true,'m','zz second attempt',5)) = 'ok', 'new wipe request');
  perform zz_assert(zz_err(cq_hq_kill_cancel('tok_zz_rm2', zz_kid('9.9.8'), 'zz changed mind')) = 'ok', 'cancel pending');
end $$;

-- grants and audit -------------------------------------------------------------------------------------------------------------------------------------
do $$ begin
  begin perform cq_apply_lock(null::cq_accounts, '*', true, 'x'); raise exception 'cq_apply_lock callable by anon';
  exception when insufficient_privilege then null; end;
  begin perform cq_apply_due_kills(); raise exception 'cq_apply_due_kills callable by anon';
  exception when insufficient_privilege then null; end;
  begin perform cq_expire_kills(); raise exception 'cq_expire_kills callable by anon';
  exception when insufficient_privilege then null; end;
  begin perform count(*) from cq_kill_requests; raise exception 'kill requests readable by anon';
  exception when insufficient_privilege then null; end;
end $$;
reset role;
select zz_assert((select count(*) from cq_audit where action in ('kill_request','kill_approve','kill_execute','kill_lock','unlock','rel_rollback','rel_rollout','model_activate')) >= 8, 'actions are in the audit log');
set role anon;
select zz_assert((cq_hq_audit_verify('tok_zz_master')->>'chain_intact')::boolean, 'audit chain still verifies');
reset role;

-- clean up -------------------------------------------------------------------------------------------------------------------------------------------
delete from cq_kill_requests where version in ('9.9.9','9.9.8');
delete from cq_release_config where version in ('9.9.9','9.9.8');
delete from cq_release_freezes where reason like 'zz%';
delete from cq_model_artifacts where name like 'zz-%';
delete from cq_products where slug = 'zz-prod';
update cq_release_config set lucy_model_sha256 = null where version = '*' and lucy_model_sha256 = repeat('c',64);
\echo smoke_0008 passed
