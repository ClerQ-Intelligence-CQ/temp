import { supabase } from './supabase';

const MESSAGES: Record<string, string> = {
  forbidden: 'Your role cannot do this.', not_found: 'Not found.', bad_value: 'Invalid value.', bad_version: 'Version must look like 1.2.3.',
  bad_channel: 'Unknown channel.', bad_platform: 'Unknown platform.', bad_sha256: 'SHA-256 must be 64 lowercase hex characters.', bad_size: 'Size must be a positive number of bytes.',
  bad_url: 'URL must start with https://', bad_pct: 'Rollout must be 1, 5, 25, 50 or 100.', bad_countdown: 'A data wipe needs a countdown of 5 to 1440 minutes.',
  duplicate_build: 'That version already exists for this product, channel and platform.', duplicate_model: 'A model with that name is already registered.',
  needs_sha256: 'This build has no SHA-256, so it cannot go live.', only_upwards: 'Rollout can only go up. Halt or roll back instead.',
  not_live: 'This build is not live.', not_halted: 'This build is not halted.', freeze_window: 'A release freeze is active. Halt and rollback still work.',
  reason_required: 'A reason of at least 5 characters is required.', same_person: 'A different person must approve this. You requested it.',
  not_pending: 'This request is no longer waiting for approval.', not_approved: 'This request has not been approved.',
  countdown_running: 'The countdown has not finished yet.', not_cancellable: 'This request can no longer be cancelled.', request_open: 'There is already an open kill request for that version.',
  not_locked: 'That version is not locked.', min_above_live: 'The minimum version is higher than every build that is live at 100 percent. Phones would be locked out with nothing to update to.',
  use_kill_switch: 'Locking is only done through the kill switch.', rate_limited: 'Too many requests. Try again later.', unauthorized: 'Your session has ended. Sign in again.',
};
export class RelError extends Error { code: string; constructor(code: string) { super(MESSAGES[code] ?? `Request failed (${code})`); this.code = code; } }

async function call<T>(fn: string, args: Record<string, unknown>): Promise<T> {
  const { data, error } = await supabase.rpc(fn, args);
  if (error) throw new Error(error.message);
  if (!data || data.ok !== true) throw new RelError(String(data?.error ?? 'unknown'));
  return data as T;
}

export type Channel = 'alpha' | 'beta' | 'stable';
export type ReleaseStatus = 'draft' | 'live' | 'halted' | 'rolled_back';
export interface Release {
  id: string; slug: string; channel: Channel; version_name: string; platform: string; file_path: string | null; sha256: string | null; size_bytes: number | null;
  min_os: string | null; notes_en: string | null; notes_sw: string | null; rollout_pct: number; status: ReleaseStatus; live_at: string | null;
  halted_at: string | null; halt_reason: string | null; rolled_back_at: string | null; rollback_reason: string | null; created_at: string;
}
export interface ModelArtifact { id: string; kind: 'lucy' | 'voice'; name: string; url: string; sha256: string; bytes: number; min_app_version: string | null; max_app_version: string | null; notes: string | null; created_at: string }
export interface ConfigRow {
  version: string; lucy_model_name: string | null; lucy_model_sha256: string | null; voice_model_name: string | null; voice_model_sha256: string | null;
  min_app_version: string | null; locked: boolean; lock_message: string | null; wipe_on_lock: boolean; offline_grace_days: number; updated_at: string | null;
}
export interface Freeze { id: string; starts_at: string; ends_at: string; reason: string }
export type KillStatus = 'pending' | 'approved' | 'executed' | 'cancelled' | 'expired';
export interface KillRequest {
  id: string; version: string; wipe: boolean; lock_message: string | null; reason: string; countdown_minutes: number; status: KillStatus;
  requested_at: string; approved_at: string | null; execute_after: string | null; executed_at: string | null; cancelled_at: string | null; cancel_reason: string | null;
  requested_by: string; approved_by: string | null; requested_by_name: string | null; approved_by_name: string | null;
}
export interface ReleaseOverview {
  viewer: { id: string; role: string }; frozen: boolean; products: Array<{ slug: string; name: string; stage: string }>;
  releases: Release[]; models: ModelArtifact[]; config: ConfigRow[]; freezes: Freeze[]; kills: KillRequest[];
}

export const overview = (t: string) => call<{ ok: true } & ReleaseOverview>('cq_hq_release_overview', { p_token: t });
export const createBuild = async (t: string, b: { slug: string; channel: Channel; version: string; platform: string; file_path: string; sha256: string; size_bytes: number | null; min_os: string; notes_en: string; notes_sw: string }) => {
  await call('cq_hq_rel_create', { p_token: t, p_slug: b.slug, p_channel: b.channel, p_version: b.version, p_platform: b.platform, p_file_path: b.file_path || null,
    p_sha256: b.sha256 || null, p_size_bytes: b.size_bytes, p_min_os: b.min_os || null, p_notes_en: b.notes_en || null, p_notes_sw: b.notes_sw || null });
};
export const setRollout = async (t: string, id: string, pct: number) => { await call('cq_hq_rel_set_rollout', { p_token: t, p_release_id: id, p_pct: pct }); };
export const haltBuild = async (t: string, id: string, reason: string) => { await call('cq_hq_rel_halt', { p_token: t, p_release_id: id, p_reason: reason }); };
export const resumeBuild = async (t: string, id: string, reason: string) => { await call('cq_hq_rel_resume', { p_token: t, p_release_id: id, p_reason: reason }); };
export const rollbackBuild = (t: string, id: string, reason: string) => call<{ fallback_version: string | null; fallback_pct: number | null }>('cq_hq_rel_rollback', { p_token: t, p_release_id: id, p_reason: reason });
export const setPolicy = async (t: string, version: string, minApp: string | null, grace: number | null, msg: string | null) => {
  await call('cq_hq_rel_set_policy', { p_token: t, p_version: version, p_min_app_version: minApp, p_offline_grace_days: grace, p_lock_message: msg });
};
export const registerModel = async (t: string, m: { kind: 'lucy' | 'voice'; name: string; url: string; sha256: string; bytes: number; min_app: string; max_app: string; notes: string }) => {
  await call('cq_hq_model_register', { p_token: t, p_kind: m.kind, p_name: m.name, p_url: m.url, p_sha256: m.sha256, p_bytes: m.bytes, p_min_app: m.min_app || null, p_max_app: m.max_app || null, p_notes: m.notes || null });
};
export const activateModel = async (t: string, id: string, version: string) => { await call('cq_hq_model_activate', { p_token: t, p_model_id: id, p_version: version }); };
export const addFreeze = async (t: string, starts: string, ends: string, reason: string) => { await call('cq_hq_freeze_add', { p_token: t, p_starts: starts, p_ends: ends, p_reason: reason }); };
export const removeFreeze = async (t: string, id: string) => { await call('cq_hq_freeze_remove', { p_token: t, p_id: id }); };
export const killRequest = (t: string, version: string, wipe: boolean, message: string, reason: string, countdownMin: number) =>
  call<{ id: string; status: 'pending' | 'executed' }>('cq_hq_kill_request', { p_token: t, p_version: version, p_wipe: wipe, p_message: message || null, p_reason: reason, p_countdown_min: countdownMin });
export const killApprove = async (t: string, id: string) => { await call('cq_hq_kill_approve', { p_token: t, p_id: id }); };
export const killExecute = async (t: string, id: string) => { await call('cq_hq_kill_execute', { p_token: t, p_id: id }); };
export const killCancel = async (t: string, id: string, reason: string) => { await call('cq_hq_kill_cancel', { p_token: t, p_id: id, p_reason: reason }); };
export const unlock = async (t: string, version: string, reason: string) => { await call('cq_hq_unlock', { p_token: t, p_version: version, p_reason: reason }); };
