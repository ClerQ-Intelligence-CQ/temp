import React, { useCallback, useEffect, useState } from 'react';
import { ShieldAlert, RefreshCw, Octagon } from 'lucide-react';
import { useAuth } from '../lib/auth';
import * as R from '../lib/releaseApi';
import { MetricCard } from '../components/MetricCard';
import { StatusBadge } from '../components/StatusBadge';
import { Banner, Empty, ago, cap, card, field, td, th, useRun, when } from '../components/ui';

type Tab = 'builds' | 'kill' | 'models' | 'policy';
const STEPS = [1, 5, 25, 50, 100];
const mb = (n: number | null) => (n == null ? 'unknown' : `${(n / 1048576).toFixed(1)} MB`);
const short = (h: string | null) => (h ? `${h.slice(0, 10)}...${h.slice(-6)}` : 'missing');

/** A reason is always typed before a risky action. The action only runs after Confirm. */
interface Ask { title: string; detail?: string; confirm: string; danger?: boolean; needsReason?: boolean; typeToConfirm?: string; go: (reason: string) => Promise<unknown>; ok: string }

export const Releases: React.FC = () => {
  const { token } = useAuth();
  const { busy, msg, setMsg, run } = useRun();
  const [o, setO] = useState<(R.ReleaseOverview & { ok: true }) | null>(null);
  const [tab, setTab] = useState<Tab>('builds');
  const [ask, setAsk] = useState<Ask | null>(null);
  const [reason, setReason] = useState('');
  const [typed, setTyped] = useState('');
  const [now, setNow] = useState(Date.now());

  const load = useCallback(async () => { if (token) await run(async () => { setO(await R.overview(token)); }); }, [token, run]);
  useEffect(() => { void load(); }, [load]);
  useEffect(() => { const i = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(i); }, []);
  if (!token) return null;

  const role = o?.viewer.role ?? '';
  const canAct = role === 'release_manager' || role === 'master';
  const open = (a: Ask) => { setReason(''); setTyped(''); setAsk(a); };
  const doConfirm = async () => {
    if (!ask) return;
    const a = ask;
    const ok = await run(async () => { await a.go(reason.trim()); await load(); }, a.ok);
    if (ok) setAsk(null);
  };
  const reasonOk = !ask?.needsReason || reason.trim().length >= 5;
  const typedOk = !ask?.typeToConfirm || typed.trim() === ask.typeToConfirm;

  const liveCount = o?.releases.filter(r => r.status === 'live').length ?? 0;
  const halted = o?.releases.filter(r => r.status === 'halted').length ?? 0;
  const locked = o?.config.filter(c => c.locked) ?? [];
  const waiting = o?.kills.filter(k => k.status === 'pending').length ?? 0;

  return (
    <div className="animate-fade-in" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}><ShieldAlert size={22} /><h1 style={{ fontSize: 24, fontWeight: 700, letterSpacing: '-0.02em' }}>Release Manager</h1></div>
          <p style={{ fontSize: 14, color: 'var(--text-secondary)', marginTop: 4 }}>Builds, staged rollout, model files, release policy and the kill switch. Every action here is written to the audit log.</p>
        </div>
        <button className="btn-secondary" disabled={busy} onClick={() => void load()}><RefreshCw size={14} /><span>Refresh</span></button>
      </div>
      <Banner msg={msg} />
      {o && !canAct && <div style={{ ...card, fontSize: 13 }}>Your role can view this screen but cannot change releases.</div>}

      {o && (
        <>
          {o.frozen && <div style={{ ...card, borderColor: 'var(--warning)', fontSize: 13 }}><strong>Release freeze is active.</strong> Rollout increases are blocked. Halt, rollback and the kill switch still work.</div>}
          {locked.length > 0 && (
            <div style={{ ...card, borderColor: 'var(--danger-border)', background: 'var(--danger-bg)', fontSize: 13 }}>
              <strong>Locked now: {locked.map(c => (c.version === '*' ? 'all versions' : c.version) + (c.wipe_on_lock ? ' (with data wipe)' : '')).join(', ')}</strong>
            </div>
          )}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(190px, 1fr))', gap: 14 }}>
            <MetricCard title="Builds live" value={liveCount} />
            <MetricCard title="Builds halted" value={halted} />
            <MetricCard title="Locked versions" value={locked.length} />
            <MetricCard title="Kill requests waiting" value={waiting} subtitle={waiting ? 'A second person must approve' : undefined} />
          </div>

          <div role="tablist" style={{ display: 'flex', gap: 6, borderBottom: '1px solid var(--border-subtle)' }}>
            {([['builds', 'Builds and rollout'], ['kill', 'Kill switch'], ['models', 'Model files'], ['policy', 'Policy and freezes']] as Array<[Tab, string]>).map(([k, l]) => (
              <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)}
                style={{ padding: '9px 14px', fontSize: 13, fontWeight: tab === k ? 600 : 400, background: 'none', border: 'none', cursor: 'pointer',
                  color: tab === k ? 'var(--text-primary)' : 'var(--text-muted)', borderBottom: tab === k ? '2px solid var(--text-primary)' : '2px solid transparent' }}>{l}</button>
            ))}
          </div>

          {tab === 'builds' && <Builds o={o} token={token} canAct={canAct} busy={busy} run={run} load={load} open={open} />}
          {tab === 'kill' && <Kill o={o} token={token} canAct={canAct} busy={busy} run={run} load={load} open={open} now={now} />}
          {tab === 'models' && <Models o={o} token={token} canAct={canAct} busy={busy} run={run} load={load} />}
          {tab === 'policy' && <Policy o={o} token={token} canAct={canAct} busy={busy} run={run} load={load} open={open} />}
        </>
      )}

      {ask && (
        <div role="dialog" aria-modal="true" aria-label={ask.title} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 50, padding: 16 }}>
          <div style={{ ...card, width: 'min(480px, 100%)', display: 'flex', flexDirection: 'column', gap: 6 }}>
            <strong style={{ fontSize: 16 }}>{ask.title}</strong>
            {ask.detail && <p style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.5 }}>{ask.detail}</p>}
            {ask.needsReason && (<><label style={cap} htmlFor="why">Reason (at least 5 characters, saved in the audit log)</label>
              <textarea id="why" style={{ ...field, minHeight: 70 }} value={reason} onChange={e => setReason(e.target.value)} autoFocus /></>)}
            {ask.typeToConfirm && (<><label style={cap} htmlFor="tc">Type <code>{ask.typeToConfirm}</code> to confirm</label>
              <input id="tc" style={field} value={typed} onChange={e => setTyped(e.target.value)} /></>)}
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 12 }}>
              <button className="btn-secondary" onClick={() => setAsk(null)} disabled={busy}>Cancel</button>
              <button className={ask.danger ? 'btn-danger' : 'btn-primary'} disabled={busy || !reasonOk || !typedOk} onClick={() => void doConfirm()}>{ask.confirm}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

interface Common { o: R.ReleaseOverview; token: string; canAct: boolean; busy: boolean; run: (fn: () => Promise<unknown>, ok?: string) => Promise<boolean>; load: () => Promise<void> }

// ---- Builds and rollout --------------------------------------------------------------------------------------
const Builds: React.FC<Common & { open: (a: Ask) => void }> = ({ o, token, canAct, busy, run, load, open }) => {
  const [f, setF] = useState({ slug: o.products[0]?.slug ?? '', channel: 'stable' as R.Channel, version: '', platform: 'android', file_path: '', sha256: '', size: '', min_os: '', notes_en: '', notes_sw: '' });
  const set = (k: string, v: string) => setF(p => ({ ...p, [k]: v }));
  const [slugFilter, setSlugFilter] = useState('all');
  const rows = o.releases.filter(r => slugFilter === 'all' || r.slug === slugFilter);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={card}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
          <strong style={{ fontSize: 14 }}>Builds</strong>
          <select aria-label="Filter by product" style={{ ...field, width: 'auto' }} value={slugFilter} onChange={e => setSlugFilter(e.target.value)}>
            <option value="all">All products</option>{o.products.map(p => <option key={p.slug} value={p.slug}>{p.name}</option>)}
          </select>
        </div>
        {rows.length === 0 ? <Empty>0 builds registered. Add the first one below.</Empty> : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead><tr><th style={th}>Product</th><th style={th}>Channel</th><th style={th}>Version</th><th style={th}>Platform</th><th style={th}>SHA-256</th><th style={th}>Size</th><th style={th}>Rollout</th><th style={th}>Status</th>{canAct && <th style={th}>Actions</th>}</tr></thead>
              <tbody>
                {rows.map(r => {
                  const next = STEPS.find(s => s > r.rollout_pct);
                  return (
                    <tr key={r.id}>
                      <td style={td}>{r.slug}</td><td style={td}>{r.channel}</td><td style={td}><strong>{r.version_name}</strong></td><td style={td}>{r.platform}</td>
                      <td style={td} title={r.sha256 ?? ''}><code style={{ fontSize: 11 }}>{short(r.sha256)}</code></td><td style={td}>{mb(r.size_bytes)}</td>
                      <td style={td}>
                        <div style={{ display: 'flex', gap: 3 }} aria-label={`Rollout ${r.rollout_pct} percent`}>
                          {STEPS.map(s => <span key={s} title={`${s}%`} style={{ width: 14, height: 8, borderRadius: 2, background: r.rollout_pct >= s ? 'var(--text-primary)' : 'var(--bg-surface-hover)' }} />)}
                        </div>
                        <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{r.rollout_pct}%</span>
                      </td>
                      <td style={td}><StatusBadge status={r.status === 'live' ? 'active' : r.status === 'draft' ? 'pending' : 'suspended'} size="sm" /><div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 3 }}>{r.status.replace('_', ' ')}{r.halt_reason && r.status === 'halted' ? `: ${r.halt_reason}` : ''}{r.rollback_reason && r.status === 'rolled_back' ? `: ${r.rollback_reason}` : ''}</div></td>
                      {canAct && (
                        <td style={td}>
                          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                            {(r.status === 'draft' || r.status === 'live') && next && (
                              <button className="btn-primary" disabled={busy || !r.sha256} title={r.sha256 ? '' : 'Add a SHA-256 first'}
                                onClick={() => open({ title: `Raise ${r.version_name} to ${next}%`, detail: r.rollout_pct === 0 ? 'The build becomes live and phones in this bucket can be offered the update.' : `Currently ${r.rollout_pct}%.`, confirm: `Go to ${next}%`, ok: `Rollout is now ${next}%.`, go: () => R.setRollout(token, r.id, next) })}>
                                {r.status === 'draft' ? `Go live at ${next}%` : `Raise to ${next}%`}</button>)}
                            {r.status === 'live' && <button className="btn-secondary" disabled={busy} onClick={() => open({ title: `Halt ${r.version_name}`, detail: 'Phones stop being offered this build. Phones that already installed it are not affected.', confirm: 'Halt', needsReason: true, ok: 'Build halted.', go: x => R.haltBuild(token, r.id, x) })}>Halt</button>}
                            {r.status === 'halted' && <button className="btn-secondary" disabled={busy} onClick={() => open({ title: `Resume ${r.version_name}`, confirm: 'Resume', needsReason: true, ok: 'Build resumed.', go: x => R.resumeBuild(token, r.id, x) })}>Resume</button>}
                            {(r.status === 'live' || r.status === 'halted') && <button className="btn-danger" disabled={busy} onClick={() => open({ title: `Roll back ${r.version_name}`, detail: 'This build is withdrawn (rollout set to 0). The previous live build for the same product and channel keeps being offered. If there is none, phones are offered nothing.', confirm: 'Roll back', danger: true, needsReason: true, ok: 'Build rolled back.', go: x => R.rollbackBuild(token, r.id, x) })}>Roll back</button>}
                          </div>
                        </td>)}
                    </tr>);
                })}
              </tbody>
            </table>
          </div>)}
        <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 8 }}>Auto-halt on a crash threshold is not available: Nia does not send crash reports yet. Halt by hand when support or the fleet screen shows a problem.</p>
      </div>

      {canAct && (
        <form style={{ ...card, display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(190px, 1fr))', gap: 10 }} onSubmit={e => {
          e.preventDefault();
          void run(async () => {
            await R.createBuild(token, { slug: f.slug, channel: f.channel, version: f.version.trim(), platform: f.platform, file_path: f.file_path.trim(), sha256: f.sha256.trim().toLowerCase(), size_bytes: f.size ? Number(f.size) : null, min_os: f.min_os.trim(), notes_en: f.notes_en, notes_sw: f.notes_sw });
            setF(p => ({ ...p, version: '', file_path: '', sha256: '', size: '', notes_en: '', notes_sw: '' })); await load();
          }, 'Build registered as a draft.');
        }}>
          <strong style={{ fontSize: 14, gridColumn: '1 / -1' }}>Register a build</strong>
          <div><label style={cap} htmlFor="b-slug">Product</label><select id="b-slug" style={field} value={f.slug} onChange={e => set('slug', e.target.value)}>{o.products.map(p => <option key={p.slug} value={p.slug}>{p.name}</option>)}</select></div>
          <div><label style={cap} htmlFor="b-ch">Channel</label><select id="b-ch" style={field} value={f.channel} onChange={e => set('channel', e.target.value)}><option>alpha</option><option>beta</option><option>stable</option></select></div>
          <div><label style={cap} htmlFor="b-v">Version</label><input id="b-v" style={field} placeholder="1.47.2" value={f.version} onChange={e => set('version', e.target.value)} required /></div>
          <div><label style={cap} htmlFor="b-p">Platform</label><select id="b-p" style={field} value={f.platform} onChange={e => set('platform', e.target.value)}><option>android</option><option>ios</option><option>web</option></select></div>
          <div style={{ gridColumn: 'span 2' }}><label style={cap} htmlFor="b-f">File path or URL</label><input id="b-f" style={field} value={f.file_path} onChange={e => set('file_path', e.target.value)} /></div>
          <div style={{ gridColumn: 'span 2' }}><label style={cap} htmlFor="b-h">SHA-256 (64 hex characters)</label><input id="b-h" style={{ ...field, fontFamily: 'monospace' }} value={f.sha256} onChange={e => set('sha256', e.target.value)} /></div>
          <div><label style={cap} htmlFor="b-s">Size in bytes</label><input id="b-s" style={field} inputMode="numeric" value={f.size} onChange={e => set('size', e.target.value.replace(/\D/g, ''))} /></div>
          <div><label style={cap} htmlFor="b-o">Minimum OS</label><input id="b-o" style={field} placeholder="Android 8" value={f.min_os} onChange={e => set('min_os', e.target.value)} /></div>
          <div style={{ gridColumn: 'span 2' }}><label style={cap} htmlFor="b-ne">Release notes (English)</label><textarea id="b-ne" style={{ ...field, minHeight: 60 }} value={f.notes_en} onChange={e => set('notes_en', e.target.value)} /></div>
          <div style={{ gridColumn: 'span 2' }}><label style={cap} htmlFor="b-ns">Release notes (Swahili)</label><textarea id="b-ns" style={{ ...field, minHeight: 60 }} value={f.notes_sw} onChange={e => set('notes_sw', e.target.value)} /></div>
          <div style={{ gridColumn: '1 / -1' }}><button className="btn-primary" type="submit" disabled={busy || !f.slug}>Register draft</button>
            <span style={{ fontSize: 12, color: 'var(--text-muted)', marginLeft: 10 }}>The file is not uploaded from here. Host it first, then paste its address and hash. HQ does not check the hash against the file.</span></div>
        </form>)}
    </div>
  );
};

// ---- Kill switch -----------------------------------------------------------------------------------------------
const Kill: React.FC<Common & { open: (a: Ask) => void; now: number }> = ({ o, token, canAct, busy, run, load, open, now }) => {
  const [version, setVersion] = useState('*');
  const [wipe, setWipe] = useState(false);
  const [countdown, setCountdown] = useState(10);
  const [message, setMessage] = useState('');
  const [why, setWhy] = useState('');
  const versions = Array.from(new Set(['*', ...o.config.map(c => c.version)]));
  const label = version === '*' ? 'all versions' : version;
  const remain = (iso: string | null) => (iso ? Math.max(0, Math.ceil((new Date(iso).getTime() - now) / 1000)) : 0);
  const mmss = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {canAct && (
        <div style={{ ...card, borderColor: 'var(--danger-border)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}><Octagon size={18} color="var(--danger)" /><strong style={{ fontSize: 14 }}>Lock a version</strong></div>
          <p style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.5, marginTop: 6 }}>
            A lock stops the app on phones the next time they check in. A lock without data wipe takes effect at once and can be lifted. A lock with data wipe needs a different person to approve, then runs after a countdown you can cancel.
          </p>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 10 }}>
            <div><label style={cap} htmlFor="k-v">Version to lock</label><select id="k-v" style={field} value={version} onChange={e => setVersion(e.target.value)}>{versions.map(v => <option key={v} value={v}>{v === '*' ? 'All versions (*)' : v}</option>)}</select></div>
            <div style={{ gridColumn: 'span 2' }}><label style={cap} htmlFor="k-m">Message phones will show</label><input id="k-m" style={field} maxLength={300} value={message} onChange={e => setMessage(e.target.value)} /></div>
          </div>
          <label style={{ display: 'flex', gap: 8, alignItems: 'center', fontSize: 13, marginTop: 12 }}><input type="checkbox" checked={wipe} onChange={e => setWipe(e.target.checked)} />Also erase local data on the phone</label>
          {wipe && (
            <div style={{ marginTop: 8, padding: 10, border: '1px solid var(--danger-border)', background: 'var(--danger-bg)', borderRadius: 'var(--radius-sm)', fontSize: 13, lineHeight: 1.5 }}>
              Nia keeps clinical data only on the phone, so a wipe cannot be undone and nothing can be restored from a server. Use it only for a lost device or a confirmed compromise.
              <div style={{ marginTop: 8 }}><label style={{ fontSize: 12 }} htmlFor="k-c">Countdown after approval, in minutes (5 to 1440)</label>
                <input id="k-c" style={{ ...field, width: 120, marginLeft: 8, display: 'inline-block' }} inputMode="numeric" value={countdown} onChange={e => setCountdown(Number(e.target.value.replace(/\D/g, '')) || 0)} /></div>
            </div>)}
          <label style={cap} htmlFor="k-r">Reason (saved in the audit log)</label>
          <textarea id="k-r" style={{ ...field, minHeight: 60 }} value={why} onChange={e => setWhy(e.target.value)} />
          <div style={{ marginTop: 12 }}>
            <button className="btn-danger" disabled={busy || why.trim().length < 5 || (wipe && (countdown < 5 || countdown > 1440))}
              onClick={() => open({
                title: wipe ? `Request data-wipe lock for ${label}` : `Lock ${label} now`,
                detail: wipe ? 'This only creates a request. A different release manager or master must approve it, then it runs after the countdown.' : 'Phones on this version are locked at their next check-in. You can unlock it later.',
                confirm: wipe ? 'Send for approval' : 'Lock now', danger: true, typeToConfirm: version === '*' ? 'LOCK ALL' : undefined, ok: wipe ? 'Request created. A second person must approve it.' : 'Locked.',
                go: async () => { await R.killRequest(token, version, wipe, message, why.trim(), wipe ? countdown : 0); setWhy(''); setMessage(''); setWipe(false); },
              })}>{wipe ? 'Request data-wipe lock' : 'Lock now'}</button>
          </div>
        </div>)}

      <div style={card}>
        <strong style={{ fontSize: 14 }}>Currently locked</strong>
        {o.config.filter(c => c.locked).length === 0 ? <Empty>Nothing is locked.</Empty> : (
          <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: 6 }}>
            <thead><tr><th style={th}>Version</th><th style={th}>Data wipe</th><th style={th}>Message</th><th style={th}>Changed</th>{canAct && <th style={th} />}</tr></thead>
            <tbody>{o.config.filter(c => c.locked).map(c => (
              <tr key={c.version}><td style={td}>{c.version === '*' ? 'All versions' : c.version}</td><td style={td}>{c.wipe_on_lock ? 'Yes' : 'No'}</td><td style={td}>{c.lock_message ?? 'none'}</td><td style={td}>{ago(c.updated_at)}</td>
                {canAct && <td style={td}><button className="btn-secondary" disabled={busy} onClick={() => open({ title: `Unlock ${c.version === '*' ? 'all versions' : c.version}`, detail: c.wipe_on_lock ? 'Phones that already wiped their data do not get it back.' : undefined, confirm: 'Unlock', needsReason: true, ok: 'Unlocked.', go: x => R.unlock(token, c.version, x) })}>Unlock</button></td>}</tr>))}</tbody>
          </table>)}
      </div>

      <div style={card}>
        <strong style={{ fontSize: 14 }}>Requests</strong>
        {o.kills.length === 0 ? <Empty>0 kill requests recorded.</Empty> : (
          <div style={{ overflowX: 'auto' }}><table style={{ width: '100%', borderCollapse: 'collapse', marginTop: 6 }}>
            <thead><tr><th style={th}>When</th><th style={th}>Version</th><th style={th}>Type</th><th style={th}>Requested by</th><th style={th}>Approved by</th><th style={th}>Status</th><th style={th}>Reason</th>{canAct && <th style={th}>Actions</th>}</tr></thead>
            <tbody>{o.kills.map(k => {
              const left = remain(k.execute_after);
              const mine = k.requested_by === o.viewer.id;
              return (
                <tr key={k.id}>
                  <td style={td}>{when(k.requested_at)}</td><td style={td}>{k.version === '*' ? 'All' : k.version}</td><td style={td}>{k.wipe ? 'Lock and wipe' : 'Lock'}</td>
                  <td style={td}>{k.requested_by_name ?? 'unknown'}</td><td style={td}>{k.approved_by_name ?? (k.wipe ? 'waiting' : 'not needed')}</td>
                  <td style={td}>{k.status}{k.status === 'approved' && left > 0 ? ` (runs in ${mmss(left)})` : ''}{k.status === 'approved' && left === 0 ? ' (countdown finished)' : ''}</td>
                  <td style={{ ...td, maxWidth: 260 }}>{k.reason}{k.cancel_reason ? ` (cancelled: ${k.cancel_reason})` : ''}</td>
                  {canAct && (
                    <td style={td}><div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                      {k.status === 'pending' && <button className="btn-danger" disabled={busy || mine} title={mine ? 'You requested this. A different person must approve.' : ''}
                        onClick={() => open({ title: `Approve data-wipe lock for ${k.version === '*' ? 'all versions' : k.version}`, detail: `${k.countdown_minutes} minute countdown starts now. Local data on affected phones will be erased and cannot be recovered.`, confirm: 'Approve', danger: true, typeToConfirm: 'WIPE', ok: 'Approved. The countdown has started.', go: () => R.killApprove(token, k.id) })}>Approve</button>}
                      {k.status === 'approved' && <button className="btn-danger" disabled={busy || left > 0} onClick={() => open({ title: 'Run the lock now', confirm: 'Run', danger: true, ok: 'Lock applied.', go: () => R.killExecute(token, k.id) })}>Run now</button>}
                      {(k.status === 'pending' || k.status === 'approved') && <button className="btn-secondary" disabled={busy} onClick={() => open({ title: 'Cancel this request', confirm: 'Cancel request', needsReason: true, ok: 'Request cancelled.', go: x => R.killCancel(token, k.id, x) })}>Cancel</button>}
                    </div></td>)}
                </tr>);
            })}</tbody></table></div>)}
        <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 8 }}>Pending requests expire after 24 hours. An approved request runs on its own only if the database job described in the notes is enabled; otherwise press Run now once the countdown ends.</p>
      </div>
    </div>
  );
};

// ---- Model files -------------------------------------------------------------------------------------------------
const Models: React.FC<Common> = ({ o, token, canAct, busy, run, load }) => {
  const [f, setF] = useState({ kind: 'lucy' as 'lucy' | 'voice', name: '', url: '', sha256: '', bytes: '', min_app: '', max_app: '', notes: '' });
  const set = (k: string, v: string) => setF(p => ({ ...p, [k]: v }));
  const [target, setTarget] = useState('*');
  const active = (m: R.ModelArtifact) => o.config.filter(c => (m.kind === 'lucy' ? c.lucy_model_sha256 : c.voice_model_sha256) === m.sha256).map(c => (c.version === '*' ? 'default' : c.version));
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={card}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
          <strong style={{ fontSize: 14 }}>Registered models</strong>
          {canAct && <label style={{ fontSize: 12 }}>Activate for <select style={{ ...field, width: 'auto', marginLeft: 6 }} value={target} onChange={e => setTarget(e.target.value)}>{o.config.map(c => <option key={c.version} value={c.version}>{c.version === '*' ? 'default (*)' : c.version}</option>)}</select></label>}
        </div>
        {o.models.length === 0 ? <Empty>0 models registered. The models currently served come from the release configuration.</Empty> : (
          <div style={{ overflowX: 'auto' }}><table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead><tr><th style={th}>Kind</th><th style={th}>Name</th><th style={th}>SHA-256</th><th style={th}>Size</th><th style={th}>App versions</th><th style={th}>In use for</th>{canAct && <th style={th} />}</tr></thead>
            <tbody>{o.models.map(m => (
              <tr key={m.id}><td style={td}>{m.kind === 'lucy' ? 'Language model' : 'Voice model'}</td><td style={td}>{m.name}</td><td style={td}><code style={{ fontSize: 11 }}>{short(m.sha256)}</code></td><td style={td}>{mb(m.bytes)}</td>
                <td style={td}>{m.min_app_version ?? 'any'} to {m.max_app_version ?? 'any'}</td><td style={td}>{active(m).join(', ') || 'not in use'}</td>
                {canAct && <td style={td}><button className="btn-secondary" disabled={busy} onClick={() => void run(async () => { await R.activateModel(token, m.id, target); await load(); }, `Phones on ${target === '*' ? 'the default configuration' : target} will download this model next.`)}>Activate</button></td>}</tr>))}</tbody></table></div>)}
      </div>
      {canAct && (
        <form style={{ ...card, display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(190px, 1fr))', gap: 10 }} onSubmit={e => { e.preventDefault(); void run(async () => { await R.registerModel(token, { ...f, bytes: Number(f.bytes) }); setF(p => ({ ...p, name: '', url: '', sha256: '', bytes: '', notes: '' })); await load(); }, 'Model registered. Activate it to serve it.'); }}>
          <strong style={{ fontSize: 14, gridColumn: '1 / -1' }}>Register a model file</strong>
          <div><label style={cap} htmlFor="m-k">Kind</label><select id="m-k" style={field} value={f.kind} onChange={e => set('kind', e.target.value)}><option value="lucy">Language model</option><option value="voice">Voice model</option></select></div>
          <div><label style={cap} htmlFor="m-n">Name</label><input id="m-n" style={field} value={f.name} onChange={e => set('name', e.target.value)} required /></div>
          <div style={{ gridColumn: 'span 2' }}><label style={cap} htmlFor="m-u">HTTPS address</label><input id="m-u" style={field} value={f.url} onChange={e => set('url', e.target.value)} required /></div>
          <div style={{ gridColumn: 'span 2' }}><label style={cap} htmlFor="m-h">SHA-256</label><input id="m-h" style={{ ...field, fontFamily: 'monospace' }} value={f.sha256} onChange={e => set('sha256', e.target.value.toLowerCase())} required /></div>
          <div><label style={cap} htmlFor="m-b">Size in bytes</label><input id="m-b" style={field} inputMode="numeric" value={f.bytes} onChange={e => set('bytes', e.target.value.replace(/\D/g, ''))} required /></div>
          <div><label style={cap} htmlFor="m-a">Works from app version</label><input id="m-a" style={field} placeholder="optional" value={f.min_app} onChange={e => set('min_app', e.target.value)} /></div>
          <div><label style={cap} htmlFor="m-z">Works up to app version</label><input id="m-z" style={field} placeholder="optional" value={f.max_app} onChange={e => set('max_app', e.target.value)} /></div>
          <div style={{ gridColumn: '1 / -1' }}><button className="btn-primary" type="submit" disabled={busy}>Register model</button></div>
        </form>)}
    </div>
  );
};

// ---- Policy and freezes -----------------------------------------------------------------------------------------------
const Policy: React.FC<Common & { open: (a: Ask) => void }> = ({ o, token, canAct, busy, run, load, open }) => {
  const [ver, setVer] = useState('*');
  const cur = o.config.find(c => c.version === ver);
  const [minApp, setMinApp] = useState('');
  const [grace, setGrace] = useState('');
  const [msg, setMsg] = useState('');
  useEffect(() => { setMinApp(cur?.min_app_version ?? ''); setGrace(String(cur?.offline_grace_days ?? '')); setMsg(cur?.lock_message ?? ''); }, [ver, cur?.updated_at]);
  const [fz, setFz] = useState({ starts: '', ends: '', reason: '' });
  const toIso = (v: string) => (v ? new Date(v).toISOString() : '');
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={card}>
        <strong style={{ fontSize: 14 }}>Release policy</strong>
        <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 4 }}>Phones older than the minimum version are locked and shown the message. Phones that have not checked in for the grace period are locked until they reconnect.</p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(190px, 1fr))', gap: 10 }}>
          <div><label style={cap} htmlFor="p-v">Applies to</label><select id="p-v" style={field} value={ver} onChange={e => setVer(e.target.value)}>{o.config.map(c => <option key={c.version} value={c.version}>{c.version === '*' ? 'Default (*)' : c.version}</option>)}</select></div>
          <div><label style={cap} htmlFor="p-m">Minimum app version</label><input id="p-m" style={field} placeholder="none" value={minApp} onChange={e => setMinApp(e.target.value)} disabled={!canAct} /></div>
          <div><label style={cap} htmlFor="p-g">Offline grace (days, 1 to 365)</label><input id="p-g" style={field} inputMode="numeric" value={grace} onChange={e => setGrace(e.target.value.replace(/\D/g, ''))} disabled={!canAct} /></div>
          <div style={{ gridColumn: '1 / -1' }}><label style={cap} htmlFor="p-l">Lock message</label><input id="p-l" style={field} maxLength={300} value={msg} onChange={e => setMsg(e.target.value)} disabled={!canAct} /></div>
        </div>
        {canAct && <div style={{ marginTop: 12 }}><button className="btn-primary" disabled={busy} onClick={() => open({ title: 'Save release policy', detail: 'A minimum version locks every phone below it at its next check-in.', confirm: 'Save', ok: 'Policy saved.', go: () => R.setPolicy(token, ver, minApp.trim(), grace ? Number(grace) : null, msg).then(() => load()) })}>Save policy</button></div>}
      </div>

      <div style={card}>
        <strong style={{ fontSize: 14 }}>Freeze windows</strong>
        <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 4 }}>During a freeze, rollout cannot be raised. Halt, rollback and the kill switch stay available.</p>
        {o.freezes.length === 0 ? <Empty>0 freeze windows.</Empty> : (
          <table style={{ width: '100%', borderCollapse: 'collapse' }}><thead><tr><th style={th}>From</th><th style={th}>To</th><th style={th}>Reason</th>{canAct && <th style={th} />}</tr></thead>
            <tbody>{o.freezes.map(z => (<tr key={z.id}><td style={td}>{when(z.starts_at)}</td><td style={td}>{when(z.ends_at)}</td><td style={td}>{z.reason}</td>
              {canAct && <td style={td}><button className="btn-secondary" disabled={busy} onClick={() => void run(async () => { await R.removeFreeze(token, z.id); await load(); }, 'Freeze removed.')}>Remove</button></td>}</tr>))}</tbody></table>)}
        {canAct && (
          <form style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(190px, 1fr))', gap: 10, marginTop: 8 }} onSubmit={e => { e.preventDefault(); void run(async () => { await R.addFreeze(token, toIso(fz.starts), toIso(fz.ends), fz.reason); setFz({ starts: '', ends: '', reason: '' }); await load(); }, 'Freeze window added.'); }}>
            <div><label style={cap} htmlFor="z-s">Starts</label><input id="z-s" type="datetime-local" style={field} value={fz.starts} onChange={e => setFz(p => ({ ...p, starts: e.target.value }))} required /></div>
            <div><label style={cap} htmlFor="z-e">Ends</label><input id="z-e" type="datetime-local" style={field} value={fz.ends} onChange={e => setFz(p => ({ ...p, ends: e.target.value }))} required /></div>
            <div style={{ gridColumn: 'span 2' }}><label style={cap} htmlFor="z-r">Reason</label><input id="z-r" style={field} value={fz.reason} onChange={e => setFz(p => ({ ...p, reason: e.target.value }))} required /></div>
            <div style={{ gridColumn: '1 / -1' }}><button className="btn-primary" type="submit" disabled={busy}>Add freeze</button></div>
          </form>)}
      </div>
    </div>
  );
};
