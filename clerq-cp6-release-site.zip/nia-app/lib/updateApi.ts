// Nia (ClerQApp) update check. Plain fetch, no new dependencies. Needs migration 0008.
// Call it after the existing config check (cq_get_config), at most once per app start or per day.
// The offer already respects the staged rollout: a phone is placed in a fixed bucket from its device id,
// so the same phone gets a consistent answer as the rollout widens.
// ALWAYS compare the SHA-256 of the downloaded file with `sha256` before installing. The server cannot check the file for you.
// Use the same anonymous device_id you already send with usage events. Never send a patient or clinician identifier here.
export interface CloudConfig { url: string; anonKey: string }
export interface UpdateOffer { version: string; sha256: string; size_bytes: number | null; min_os: string | null; notes_en: string | null; notes_sw: string | null; file_path: string | null }

export async function checkForUpdate(cfg: CloudConfig, appVersion: string, deviceId: string, channel: 'alpha' | 'beta' | 'stable' = 'stable'): Promise<UpdateOffer | null> {
  const res = await fetch(`${cfg.url}/rest/v1/rpc/cq_get_update`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', apikey: cfg.anonKey, authorization: `Bearer ${cfg.anonKey}` },
    body: JSON.stringify({ p_app_version: appVersion, p_device_id: deviceId, p_slug: 'nia-cds', p_channel: channel, p_platform: 'android' }),
  });
  const data = await res.json().catch(() => null);
  if (!res.ok || !data || data.ok !== true) return null;   // an update check must never block the app: fail quiet
  return (data.update as UpdateOffer | null) ?? null;
}
