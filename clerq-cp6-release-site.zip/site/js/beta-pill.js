/* Beta pill: top right, appears only when HQ has a product with an open beta program (catalog.beta_open).
   Click opens a small chooser: "I have a key" or "Request access". Both paths use the existing flows on /product/. */
(function () {
  'use strict';
  var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var onProduct = /^\/product\/?$/.test(location.pathname);
  var T = { en: { pill: 'Join our beta', key: 'I have a key', req: 'Request access', label: 'Beta access options' },
            sw: { pill: 'Jiunge na beta', key: 'Nina ufunguo', req: 'Omba ufikiaji', label: 'Chaguzi za ufikiaji wa beta' } };
  function lang() { return localStorage.getItem('clerq-lang') === 'sw' ? 'sw' : 'en'; }

  function openRequest() {
    if (!onProduct) { location.href = '/product/#beta'; return; }
    var btn = document.getElementById('btn-open-beta-modal');
    if (!btn) return;
    var mode = btn.dataset.mode, dis = btn.disabled;
    btn.dataset.mode = 'beta'; btn.disabled = false; btn.click(); btn.dataset.mode = mode || ''; btn.disabled = dis;
  }
  function openKey() {
    if (!onProduct) { location.href = '/product/#verified'; return; }
    var portal = document.getElementById('verified-portal'), t = document.getElementById('btn-toggle-verified-door');
    if (portal && portal.style.display === 'none' && t) t.click();
    if (portal) portal.scrollIntoView({ behavior: reduced ? 'auto' : 'smooth' });
  }

  function build() {
    var s = document.createElement('style');
    s.textContent =
      '#beta-pill-wrap{position:fixed;top:76px;right:16px;z-index:90;opacity:0;transform:translateY(-6px);transition:opacity .5s ease,transform .5s ease;pointer-events:none}' +
      '#beta-pill-wrap.on{opacity:1;transform:none;pointer-events:auto}' +
      '#beta-pill{display:inline-flex;align-items:center;gap:8px;padding:8px 14px;border:1px solid var(--line,#E5E5E5);border-radius:999px;background:#fff;color:var(--ink,#0A0A0A);font:600 13px/1 inherit;font-family:inherit;cursor:pointer;box-shadow:0 2px 10px rgba(0,0,0,.06)}' +
      '#beta-pill:focus-visible,#beta-menu button:focus-visible{outline:2px solid var(--ink,#0A0A0A);outline-offset:2px}' +
      '#beta-pill i{width:8px;height:8px;border-radius:50%;background:#00D09C;display:inline-block}' +
      (reduced ? '' : '#beta-pill i{animation:bpulse 1.8s ease-out infinite}@keyframes bpulse{0%{box-shadow:0 0 0 0 rgba(0,208,156,.5)}100%{box-shadow:0 0 0 9px rgba(0,208,156,0)}}') +
      '#beta-menu{display:none;position:absolute;right:0;top:calc(100% + 8px);min-width:190px;padding:6px;background:#fff;border:1px solid var(--line,#E5E5E5);border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,.1)}' +
      '#beta-menu.open{display:block}#beta-menu button{display:block;width:100%;text-align:left;padding:10px 12px;background:none;border:0;border-radius:6px;font:500 14px inherit;font-family:inherit;color:var(--ink,#0A0A0A);cursor:pointer}' +
      '#beta-menu button:hover{background:#F8F9FA}@media (max-width:640px){#beta-pill-wrap{top:68px;right:10px}}';
    document.head.appendChild(s);
    var wrap = document.createElement('div'); wrap.id = 'beta-pill-wrap';
    wrap.innerHTML = '<button id="beta-pill" type="button" aria-haspopup="true" aria-expanded="false" aria-controls="beta-menu"><i aria-hidden="true"></i><span></span></button>' +
      '<div id="beta-menu" role="menu"><button type="button" role="menuitem" data-a="key"></button><button type="button" role="menuitem" data-a="req"></button></div>';
    document.body.appendChild(wrap);
    function words() { var t = T[lang()]; wrap.querySelector('#beta-pill span').textContent = t.pill; wrap.querySelector('[data-a=key]').textContent = t.key; wrap.querySelector('[data-a=req]').textContent = t.req; wrap.querySelector('#beta-menu').setAttribute('aria-label', t.label); }
    words();
    var pill = wrap.querySelector('#beta-pill'), menu = wrap.querySelector('#beta-menu');
    function close() { menu.classList.remove('open'); pill.setAttribute('aria-expanded', 'false'); }
    pill.addEventListener('click', function () { var o = menu.classList.toggle('open'); pill.setAttribute('aria-expanded', String(o)); });
    menu.addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; close(); (b.dataset.a === 'key' ? openKey : openRequest)(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { close(); pill.focus(); } });
    document.addEventListener('click', function (e) { if (!wrap.contains(e.target)) close(); if (e.target.closest && e.target.closest('#lang-toggle')) setTimeout(words, 0); });
    return wrap;
  }

  function show(wrap) {
    if (window.__clerqIntroRunning) { document.addEventListener('clerq:intro-done', function () { wrap.classList.add('on'); }, { once: true }); }
    else requestAnimationFrame(function () { wrap.classList.add('on'); });
  }

  if (!window.ClerQCatalog) return;
  window.ClerQCatalog.get(lang()).then(function (cat) {
    if (!cat.beta_open) return;
    show(build());
    if (onProduct && location.hash === '#beta') setTimeout(openRequest, 400);
  });
})();
