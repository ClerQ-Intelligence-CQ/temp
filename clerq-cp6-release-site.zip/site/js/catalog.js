/* ClerQ catalog loader.
   Reads published products from Supabase (cq_get_catalog) and falls back, in order, to the last good copy in
   localStorage, then to /data/catalog-fallback.json. Exposes window.ClerQCatalog.get(lang) -> Promise<catalog>.
   catalog.source is 'live', 'cache' or 'fallback' so pages can be honest about what they show. */
(function () {
  'use strict';
  var URL_ = 'https://lfbghuingwmmjrylwmdz.supabase.co/rest/v1/rpc/cq_get_catalog';
  // Public anon key: safe to ship in the browser. Access control is the database's job (RLS and RPC grants).
  var KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxmYmdodWluZ3dtbWpyeWx3bWR6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTMyNjMwMjQsImV4cCI6MjEwODgzOTAyNH0.m4UgRnWAa90VXOt3cS1NpNufCwp9aG7txWMPwvWD9-o';
  var CACHE = 'clerq-catalog-v1:';
  var inflight = {};

  function fetchWithTimeout(url, opts, ms) {
    var ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var t = setTimeout(function () { if (ctl) ctl.abort(); }, ms);
    if (ctl) opts.signal = ctl.signal;
    return fetch(url, opts).then(function (r) { clearTimeout(t); return r; }, function (e) { clearTimeout(t); throw e; });
  }
  function valid(c) { return c && Array.isArray(c.products); }
  function readCache(lang) { try { var v = JSON.parse(localStorage.getItem(CACHE + lang)); return valid(v && v.data) ? v.data : null; } catch (e) { return null; } }
  function writeCache(lang, data) { try { localStorage.setItem(CACHE + lang, JSON.stringify({ at: Date.now(), data: data })); } catch (e) { /* private mode or full: ignore */ } }

  function get(lang) {
    lang = lang === 'sw' ? 'sw' : 'en';
    if (inflight[lang]) return inflight[lang];
    inflight[lang] = fetchWithTimeout(URL_, {
      method: 'POST',
      headers: { apikey: KEY, Authorization: 'Bearer ' + KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify({ p_lang: lang })
    }, 4000)
      .then(function (r) { if (!r.ok) throw new Error('catalog ' + r.status); return r.json(); })
      .then(function (data) {
        if (!valid(data)) throw new Error('catalog shape');
        writeCache(lang, data); data.source = 'live'; return data;
      })
      .catch(function () {
        var c = readCache(lang);
        if (c) { c.source = 'cache'; return c; }
        return fetch('/data/catalog-fallback.json').then(function (r) { return r.json(); }).then(function (d) { d.source = 'fallback'; return d; })
          .catch(function () { return { source: 'none', beta_open: false, products: [], settings: {} }; });
      });
    return inflight[lang];
  }

  window.ClerQCatalog = { get: get };
})();
