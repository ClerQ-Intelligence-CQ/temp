/* Home intro (about 3.5 s): white screen, a revolving coin carrying the ClerQ logotype, N black comets curve in and settle on a ring,
   the coin locks, "N products live" appears, product marks fade into their circles, then the page shows.
   N = products flagged "show in orbit" in HQ, capped at 8. Plays once per browser session. 2D canvas only (no WebGL),
   so it also runs on low-end phones. Skipped for reduced motion, when N is 0, or when the catalog cannot be loaded in time. */
(function () {
  'use strict';
  var KEY = 'clerq-intro-seen';
  var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var root = document.documentElement;

  function done(ran) {
    root.classList.remove('intro-pending');
    document.body.style.overflow = '';
    var h = document.querySelector('.hero__content'); if (ran && h) h.classList.add('intro-rise');
    window.__clerqIntroRunning = false;
    document.dispatchEvent(new CustomEvent('clerq:intro-done'));
  }
  function seen() { try { return sessionStorage.getItem(KEY) === '1'; } catch (e) { return false; } }
  function mark() { try { sessionStorage.setItem(KEY, '1'); } catch (e) { /* ignore */ } }
  if (reduced || seen() || !window.ClerQCatalog) { done(false); return; }
  window.__clerqIntroRunning = true;

  var lang = localStorage.getItem('clerq-lang') === 'sw' ? 'sw' : 'en';
  var timeout = new Promise(function (r) { setTimeout(function () { r(null); }, 1500); });
  Promise.race([window.ClerQCatalog.get(lang), timeout]).then(function (cat) {
    var list = cat ? cat.products.filter(function (p) { return p.orbit && p.stage !== 'deprecated'; }).sort(function (a, b) { return a.orbit_order - b.orbit_order; }).slice(0, 8) : [];
    if (!list.length) { done(false); return; }
    mark(); play(list, lang);
  }).catch(function () { done(false); });

  function ease(t) { return 1 - Math.pow(1 - t, 3); }
  function clamp(x) { return Math.max(0, Math.min(1, x)); }

  function play(list, lang) {
    var N = list.length;
    var low = (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4) || (navigator.deviceMemory && navigator.deviceMemory <= 2);
    var dpr = Math.min(window.devicePixelRatio || 1, low ? 1 : 2);
    document.body.style.overflow = 'hidden';

    var el = document.createElement('div'); el.id = 'intro'; el.setAttribute('role', 'presentation');
    var skipLabel = lang === 'sw' ? 'Ruka' : 'Skip';
    el.innerHTML = '<canvas aria-hidden="true"></canvas><div class="coin" aria-hidden="true"><img src="/assets/logos/clerq-logotype.svg" alt=""></div><div class="count" aria-live="polite"></div><button class="skip" type="button">' + skipLabel + '</button>';
    document.body.appendChild(el);
    var cv = el.querySelector('canvas'), ctx = cv.getContext('2d'), coin = el.querySelector('.coin'), count = el.querySelector('.count');
    var W, H, cx, cy, R, chip;
    function size() {
      W = window.innerWidth; H = window.innerHeight; cv.width = W * dpr; cv.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      cx = W / 2; cy = H / 2; R = Math.min(W, H) * 0.32; chip = Math.max(44, Math.min(64, W * 0.1));
    }
    size(); window.addEventListener('resize', size);

    // Comets: random start angle off screen, settle at evenly spaced ring slots.
    var far = Math.hypot(window.innerWidth, window.innerHeight);
    var comets = list.map(function (p, i) {
      var a0 = Math.random() * Math.PI * 2, slot = -Math.PI / 2 + (i * 2 * Math.PI) / N;
      return { a0: a0, slot: slot, bend: (Math.random() < 0.5 ? -1 : 1) * (0.5 + Math.random() * 0.6), delay: i * 70, trail: [] };
    });
    var chips = list.map(function (p, i) {
      var c = document.createElement('div'); c.className = 'chip';
      c.style.setProperty('--glow', /^#[0-9a-f]{6}$/i.test(p.accent || '') ? p.accent : '#0A0A0A');
      if (p.logo && /^(\/|https:)/.test(p.logo)) { var im = document.createElement('img'); im.src = p.logo; im.alt = ''; c.appendChild(im); }
      else { var s = document.createElement('span'); s.textContent = (p.name || '?').charAt(0).toUpperCase(); c.appendChild(s); }
      c.setAttribute('title', p.name); el.appendChild(c); return c;
    });
    function placeChips() { chips.forEach(function (c, i) { var a = comets[i].slot; c.style.width = c.style.height = chip + 'px'; c.style.left = (cx + Math.cos(a) * R - chip / 2) + 'px'; c.style.top = (cy + Math.sin(a) * R - chip / 2) + 'px'; }); }

    var t0 = performance.now(), raf = 0, finished = false, lockedShown = false, chipsShown = false;
    var T_COIN = 600, T_COMET = 2200, T_LOCK = 3200, T_END = 3700;

    function pos(c, k) { // k 0..1 along the curved path from off screen to the slot
      var e = ease(k), r = far * 0.7 * (1 - e) + R * e;
      var start = c.a0, ang = start + (c.slot - start) * e + c.bend * Math.sin(Math.PI * e) * 0.6;
      return { x: cx + Math.cos(ang) * r, y: cy + Math.sin(ang) * r };
    }
    function frame(now) {
      if (finished) return;
      var t = now - t0; placeChips();
      ctx.clearRect(0, 0, W, H);
      // coin: fades in, spins, then locks facing front
      var fade = clamp(t / T_COIN), spin = t < T_COMET ? t / 260 : (T_COMET / 260) * (1 - clamp((t - T_COMET) / (T_LOCK - T_COMET))) ;
      var sx = t < T_COMET ? Math.max(0.14, Math.abs(Math.cos(spin))) : 1 - (1 - Math.max(0.14, Math.abs(Math.cos(spin)))) * (1 - clamp((t - T_COMET) / (T_LOCK - T_COMET)));
      coin.style.opacity = fade; coin.style.transform = 'scaleX(' + sx.toFixed(3) + ')';
      coin.style.setProperty('--sheen', (-120 + ((t / 9) % 260)).toFixed(1) + '%');
      // comets
      var steps = low ? 6 : 14;
      comets.forEach(function (c) {
        var k = clamp((t - T_COIN - c.delay) / (T_COMET - T_COIN - c.delay)); if (k <= 0) return;
        var p = pos(c, k), tr = [];
        for (var s = 0; s <= steps; s++) tr.push(pos(c, Math.max(0, k - (s / steps) * 0.16)));
        for (var s2 = steps; s2 > 0; s2--) { ctx.globalAlpha = (1 - s2 / steps) * 0.55 * (k < 1 ? 1 : 0.4); ctx.strokeStyle = '#0A0A0A'; ctx.lineWidth = 2.2 * (1 - s2 / steps) + 0.4; ctx.beginPath(); ctx.moveTo(tr[s2].x, tr[s2].y); ctx.lineTo(tr[s2 - 1].x, tr[s2 - 1].y); ctx.stroke(); }
        ctx.globalAlpha = k < 1 ? 1 : 0; ctx.fillStyle = '#0A0A0A'; ctx.beginPath(); ctx.arc(p.x, p.y, 4, 0, 6.2832); ctx.fill(); ctx.globalAlpha = 1;
      });
      // ring outlines appear as comets settle
      if (t > T_COMET - 300) { ctx.globalAlpha = clamp((t - (T_COMET - 300)) / 400) * 0.35; ctx.strokeStyle = '#0A0A0A'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(cx, cy, R, 0, 6.2832); ctx.stroke(); ctx.globalAlpha = 1; }
      if (t >= T_COMET && !lockedShown) { lockedShown = true; count.textContent = lang === 'sw' ? (N === 1 ? 'Bidhaa 1 inapatikana' : 'Bidhaa ' + N + ' zinapatikana') : (N === 1 ? '1 product live' : N + ' products live'); count.style.opacity = 1; }
      if (t >= T_COMET + 150 && !chipsShown) { chipsShown = true; chips.forEach(function (c, i) { setTimeout(function () { c.classList.add('on'); }, i * 60); }); }
      if (t >= T_END) { finish(); return; }
      raf = requestAnimationFrame(frame);
    }
    function finish() {
      if (finished) return; finished = true; cancelAnimationFrame(raf);
      window.removeEventListener('resize', size);
      root.classList.remove('intro-pending'); el.classList.add('out');
      setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); done(true); }, 460);
    }
    el.querySelector('.skip').addEventListener('click', finish);
    document.addEventListener('keydown', function esc(e) { if (e.key === 'Escape') { document.removeEventListener('keydown', esc); finish(); } });
    raf = requestAnimationFrame(function (n) { t0 = n; frame(n); });
  }
})();
