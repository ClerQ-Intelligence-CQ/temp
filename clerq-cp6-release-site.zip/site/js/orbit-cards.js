/* Homepage products section. Marks sit on a ring; when the section scrolls into view they move (FLIP: First, Last, Invert, Play)
   into cards, one after another, and each card's text fades in after it lands. Layout (grid, staggered, rail) comes from the
   catalog setting "home_arrangement" set in HQ; default grid. A click goes to the product page with a shared-element transition
   where the browser supports cross-page view transitions. Needs /js/catalog.js. */
(function () {
  'use strict';
  var stage = document.getElementById('oc-stage');
  if (!stage || !window.ClerQCatalog) return;
  var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var STAGE = { alpha: 'ALPHA', closed_beta: 'CLOSED BETA', open_beta: 'OPEN BETA', ga: 'AVAILABLE', deprecated: 'RETIRED' };
  var MORE = { en: 'Learn more', sw: 'Soma zaidi' };
  var morphed = false, items = [];
  function lang() { return localStorage.getItem('clerq-lang') === 'sw' ? 'sw' : 'en'; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  function ringSize() { return Math.max(300, Math.min(460, stage.clientWidth * 0.8)); }
  function placeRing() {
    var H = ringSize(), W = stage.clientWidth, R = Math.min(W, H) / 2 - 36, n = items.length;
    stage.style.height = H + 'px';
    items.forEach(function (li, i) {
      var a = -Math.PI / 2 + (i * 2 * Math.PI) / n;
      li.style.left = (W / 2 + Math.cos(a) * R - 28) + 'px'; li.style.top = (H / 2 + Math.sin(a) * R - 28) + 'px';
      li.style.width = '56px';
    });
  }

  function build(cat) {
    var arr = cat.settings && typeof cat.settings.home_arrangement === 'string' ? cat.settings.home_arrangement : 'grid';
    var list = cat.products.filter(function (p) { return p.orbit && p.stage !== 'concept'; }).sort(function (a, b) { return a.card_order - b.card_order; }).slice(0, 8);
    stage.innerHTML = ''; items = [];
    stage.className = 'oc-stage ' + (/^(grid|staggered|rail)$/.test(arr) ? 'arr-' + arr : 'arr-grid');
    var L = lang();
    list.forEach(function (p) {
      var li = document.createElement('li'); li.className = 'oc-item';
      var glow = /^#[0-9a-f]{6}$/i.test(p.accent || '') ? p.accent : '#0A0A0A';
      var mark = p.logo && /^(\/|https:)/.test(p.logo) ? '<img src="' + esc(p.logo) + '" alt="">' : '<span>' + esc((p.name || '?').charAt(0).toUpperCase()) + '</span>';
      li.innerHTML = '<a href="/product/#product=' + encodeURIComponent(p.slug) + '" data-slug="' + esc(p.slug) + '"><div class="oc-mark" style="--glow:' + glow + '" aria-hidden="true">' + mark + '</div>' +
        '<div class="oc-body"><strong>' + esc(p.name) + '</strong><span class="oc-tag">' + esc(p.tagline) + '</span><span class="oc-stagebadge">' + esc(STAGE[p.stage] || p.stage) + '</span><span class="oc-more">' + MORE[L] + ' →</span></div></a>';
      stage.appendChild(li); items.push(li);
    });
    document.getElementById('products-orbit').style.display = items.length ? '' : 'none';
    if (!items.length) return;
    if (reduced || morphed) { stage.classList.add('is-cards'); stage.style.height = ''; items.forEach(function (li) { li.style.left = li.style.top = li.style.width = ''; }); return; }
    placeRing(); stage.classList.add('pre'); watch();
  }

  function morph() {
    if (morphed) return; morphed = true; window.removeEventListener('resize', onResize);
    var first = items.map(function (li) { return li.getBoundingClientRect(); });
    var ringH = stage.getBoundingClientRect().height;
    items.forEach(function (li) { li.style.left = li.style.top = li.style.width = ''; });
    stage.style.height = ''; stage.classList.remove('pre'); stage.classList.add('is-cards');
    var last = items.map(function (li) { return li.getBoundingClientRect(); });
    var endH = stage.getBoundingClientRect().height;
    stage.style.height = ringH + 'px'; stage.offsetHeight;                    // start the height from the ring's height
    stage.style.transition = 'height .7s cubic-bezier(.2,.7,.2,1)'; stage.style.height = endH + 'px';
    items.forEach(function (li, i) {
      var dx = first[i].left - last[i].left, dy = first[i].top - last[i].top, d = i * 90;
      li.style.transition = 'none'; li.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
      li.querySelector('.oc-body').style.setProperty('--d', (d + 450) + 'ms');
      requestAnimationFrame(function () { requestAnimationFrame(function () {
        li.style.transition = 'transform .7s cubic-bezier(.2,.7,.2,1) ' + d + 'ms'; li.style.transform = '';
      }); });
    });
    setTimeout(function () { stage.style.height = ''; stage.style.transition = ''; items.forEach(function (li) { li.style.transition = ''; }); }, 1000 + items.length * 90);
  }

  var io = null;
  function watch() {
    if (!('IntersectionObserver' in window)) { morph(); return; }
    if (io) io.disconnect();
    io = new IntersectionObserver(function (es) { if (es[0].isIntersecting) { io.disconnect(); morph(); } }, { threshold: 0.45 });
    io.observe(stage); window.addEventListener('resize', onResize);
  }
  function onResize() { if (!morphed) placeRing(); }

  // Shared element: name the card being left so the product page can match it.
  stage.addEventListener('click', function (e) {
    var a = e.target.closest('a[data-slug]'); if (a) a.style.viewTransitionName = 'product-card-' + a.getAttribute('data-slug');
  });

  function start() { window.ClerQCatalog.get(lang()).then(build); }
  document.addEventListener('click', function (e) { if (e.target.closest && e.target.closest('#lang-toggle')) setTimeout(start, 0); });
  start();
})();
