/* Product page: builds the product tabs and stall content from the catalog (HQ > Product Studio).
   Needs /js/catalog.js. The inline script on the page still owns tab clicks, the 3D scene and the beta modal. */
(function () {
  'use strict';
  var STAGE = { alpha: 'ALPHA', closed_beta: 'CLOSED BETA', open_beta: 'OPEN BETA', ga: 'GENERALLY AVAILABLE', deprecated: 'RETIRED' };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function hexA(hex, a) {
    var m = /^#([0-9a-f]{6})$/i.exec(hex || '');
    if (!m) return 'rgba(10,10,10,' + a + ')';
    var n = parseInt(m[1], 16);
    return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
  function lang() { return localStorage.getItem('clerq-lang') === 'sw' ? 'sw' : 'en'; }
  function block(p, type) { var bs = (p.page && p.page.blocks) || []; return bs.filter(function (b) { return b.type === type; }); }

  // feature_grid body: one feature per line, "TAG | Title :: Description" (tag optional).
  function features(p) {
    var out = [];
    block(p, 'feature_grid').forEach(function (b) {
      String((b.props && b.props.body) || '').split('\n').forEach(function (line) {
        line = line.trim(); if (!line) return;
        var tag = '', rest = line, i = line.indexOf('|');
        if (i > -1) { tag = line.slice(0, i).trim(); rest = line.slice(i + 1).trim(); }
        var j = rest.indexOf('::');
        var title = j > -1 ? rest.slice(0, j).trim() : rest, desc = j > -1 ? rest.slice(j + 2).trim() : '';
        out.push({ tag: tag || String(out.length + 1).padStart(2, '0'), title: esc(title), desc: esc(desc), tagText: esc(tag || String(out.length + 1).padStart(2, '0')) });
      });
    });
    return out.map(function (f) { return { tag: f.tagText, title: f.title, desc: f.desc }; });  // escaped: the page inserts these with innerHTML
  }

  function entry(p) {
    var hero = block(p, 'hero')[0], stat = block(p, 'stat_strip')[0], safety = block(p, 'safety_statement')[0];
    var accent = /^#[0-9a-f]{6}$/i.test(p.accent || '') ? p.accent : '#0A0A0A';
    var cta, mode;
    if (p.stage === 'deprecated') { cta = 'This product has been retired'; mode = 'none'; }
    else if (p.beta_open) { cta = 'Apply for Clinical Beta Evaluation →'; mode = 'beta'; }
    else { cta = 'Contact us about ' + p.name + ' →'; mode = 'contact'; }
    var statTitle = stat && stat.props && stat.props.title ? stat.props.title : '';
    return {
      badge: (STAGE[p.stage] || p.stage || '').toUpperCase(), badgeColor: hexA(accent, 0.1), badgeTextColor: accent, badgeBorder: hexA(accent, 0.3),
      title: p.name + (p.tagline ? ': ' + p.tagline : ''),
      modelTag: stat && stat.props && stat.props.body ? (statTitle ? statTitle + ': ' : '') + stat.props.body : '',
      detailHeading: (hero && hero.props && hero.props.title) || p.name,
      description: (hero && hero.props && hero.props.body) || p.tagline || '',
      versionTag: p.release ? 'v' + p.release.version + ' (' + p.release.channel + ' channel)' : 'No public build yet',
      ctaText: cta, ctaMode: mode, safety: safety && safety.props ? safety.props.body || '' : '', features: features(p), accent: accent
    };
  }

  function render(cat) {
    var bar = document.getElementById('stall-nav-bar');
    if (!bar || !cat.products.length || typeof STALL_CATALOG === 'undefined') return;
    Object.keys(STALL_CATALOG).forEach(function (k) { delete STALL_CATALOG[k]; });
    window.ClerQStallAccent = {};
    bar.innerHTML = '';
    cat.products.forEach(function (p, i) {
      STALL_CATALOG[p.slug] = entry(p);
      window.ClerQStallAccent[p.slug] = STALL_CATALOG[p.slug].accent;
      var b = document.createElement('button');
      b.className = 'stall-tab'; b.setAttribute('data-product', p.slug); b.textContent = (i + 1) + '. ' + p.name;
      bar.appendChild(b);
    });
    var note = document.getElementById('catalog-source-note');
    if (!note) { note = document.createElement('p'); note.id = 'catalog-source-note'; note.style.cssText = 'font-size:12px;color:var(--muted);margin:8px 0 0;'; bar.parentNode.insertBefore(note, bar.nextSibling); }
    note.textContent = cat.source === 'live' ? '' : 'Showing a saved copy of the product list. It may be out of date.';
    var want = (location.hash.match(/product=([a-z0-9-]+)/) || [])[1];
    var tab = bar.querySelector('[data-product="' + (want && STALL_CATALOG[want] ? want : cat.products[0].slug) + '"]') || bar.firstChild;
    if (tab) tab.click();
    var d = STALL_CATALOG[tab.getAttribute('data-product')];
    showSafety(d);
  }

  function showSafety(d) {
    var el = document.getElementById('stall-safety'), desc = document.getElementById('stall-description');
    if (!desc) return;
    if (!el) { el = document.createElement('p'); el.id = 'stall-safety'; el.style.cssText = 'font-size:12px;line-height:1.6;color:var(--muted);border-left:2px solid var(--line);padding-left:10px;margin:0 0 var(--space-md);'; desc.parentNode.insertBefore(el, desc.nextSibling); }
    el.textContent = d && d.safety ? d.safety : ''; el.style.display = d && d.safety ? '' : 'none';
    var btn = document.getElementById('btn-open-beta-modal');
    if (btn && d) { btn.dataset.mode = d.ctaMode; btn.disabled = d.ctaMode === 'none'; }
  }

  // A tab click (handled by the inline script) also refreshes the safety line and the CTA mode.
  document.addEventListener('click', function (e) {
    var tab = e.target.closest && e.target.closest('.stall-tab');
    if (tab && typeof STALL_CATALOG !== 'undefined') setTimeout(function () { showSafety(STALL_CATALOG[tab.getAttribute('data-product')]); }, 0);
    var btn = e.target.closest && e.target.closest('#btn-open-beta-modal');
    if (btn && btn.dataset.mode === 'contact') { e.stopImmediatePropagation(); e.preventDefault(); location.href = '/contact/'; }
  }, true);

  // Shared-element target for the card clicked on the homepage (best effort: the browser decides if it can animate).
  (function () { var m = location.hash.match(/product=([a-z0-9-]+)/), v = document.querySelector('.stall-viewport'); if (m && v) v.style.viewTransitionName = 'product-card-' + m[1]; })();

  function start() { window.ClerQCatalog.get(lang()).then(render); }
  document.addEventListener('click', function (e) { if (e.target.closest && e.target.closest('#lang-toggle')) setTimeout(start, 0); });
  start();
})();
